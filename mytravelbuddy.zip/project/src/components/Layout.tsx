import React, { useState } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import ChatSupport from './features/ChatSupport';
import EmergencyButton from './features/EmergencyButton';
import LanguageSelector from './features/LanguageSelector';
import OfflineModal from './features/OfflineModal';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [showOfflineModal, setShowOfflineModal] = useState(false);
  
  const toggleOfflineModal = () => {
    setShowOfflineModal(!showOfflineModal);
  };
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar toggleOfflineModal={toggleOfflineModal} />
      <main className="flex-grow">
        {children}
      </main>
      <Footer />
      
      {/* Floating UI Elements */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-4">
        <ChatSupport />
        <EmergencyButton />
      </div>
      
      {/* Language Selector */}
      <div className="fixed top-20 right-6 z-30">
        <LanguageSelector />
      </div>
      
      {/* Offline Modal */}
      {showOfflineModal && (
        <OfflineModal onClose={() => setShowOfflineModal(false)} />
      )}
    </div>
  );
};

export default Layout;