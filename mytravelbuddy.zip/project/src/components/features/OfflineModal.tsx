import React from 'react';
import { Download, Wifi, WifiOff, CheckCircle } from 'lucide-react';

interface OfflineModalProps {
  onClose: () => void;
}

const OfflineModal: React.FC<OfflineModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md transform animate-fade-in">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-xl font-bold text-gray-900 flex items-center">
              <Download className="mr-2 text-primary-500" size={24} />
              Offline Mode
            </h3>
            <button 
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500"
            >
              <span className="sr-only">Close</span>
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <div className="mb-6">
            <p className="text-gray-600 mb-4">
              Download your travel plans for offline use. Access your itineraries, maps, and essential information even without an internet connection.
            </p>
            
            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <div className="flex items-center mb-2">
                <WifiOff className="text-gray-500 mr-2" size={18} />
                <span className="font-medium">Offline Features:</span>
              </div>
              <ul className="ml-6 space-y-1 text-sm text-gray-600">
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 mr-1 mt-0.5" size={14} />
                  <span>Saved itineraries and booking details</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 mr-1 mt-0.5" size={14} />
                  <span>Offline maps for your destinations</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 mr-1 mt-0.5" size={14} />
                  <span>Emergency contacts and local information</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 mr-1 mt-0.5" size={14} />
                  <span>Saved articles and travel guides</span>
                </li>
              </ul>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                className="flex-1 btn btn-primary flex items-center justify-center"
                onClick={() => {
                  // Here would be download functionality
                  setTimeout(onClose, 1000);
                }}
              >
                <Download className="mr-2" size={18} />
                Download Current Trip
              </button>
              
              <button
                className="flex-1 btn bg-gray-100 text-gray-700 hover:bg-gray-200 flex items-center justify-center"
                onClick={onClose}
              >
                <Wifi className="mr-2" size={18} />
                Stay Online
              </button>
            </div>
          </div>
          
          <p className="text-xs text-gray-500 text-center">
            Offline data may use up to 150MB of storage on your device
          </p>
        </div>
      </div>
    </div>
  );
};

export default OfflineModal;