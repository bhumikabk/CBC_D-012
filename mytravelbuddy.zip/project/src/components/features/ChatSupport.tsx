import React, { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';

const ChatSupport: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<{type: 'user' | 'bot', text: string}[]>([
    {type: 'bot', text: 'Hi! How can I help you with your travel plans today?'}
  ]);
  
  const toggleChat = () => {
    setIsOpen(!isOpen);
  };
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    // Add user message to chat
    setChatHistory([...chatHistory, {type: 'user', text: message}]);
    
    // Simulate bot response after a delay
    setTimeout(() => {
      const responses = [
        "I can help you find destinations based on your interests. What kind of trip are you planning?",
        "Would you like recommendations for accommodations or activities?",
        "Do you need help with your itinerary or booking information?",
        "I can suggest some hidden gems that tourists often miss. What region are you interested in?",
        "Is there anything specific about your travel plans you'd like assistance with?"
      ];
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      setChatHistory(prev => [...prev, {type: 'bot', text: randomResponse}]);
    }, 1000);
    
    // Clear input
    setMessage('');
  };
  
  return (
    <>
      <button 
        onClick={toggleChat}
        className={`rounded-full p-3 shadow-lg transition-all transform hover:scale-110 ${
          isOpen ? 'bg-red-500 rotate-90' : 'bg-primary-500'
        }`}
      >
        {isOpen ? <X size={24} className="text-white" /> : <MessageCircle size={24} className="text-white" />}
      </button>
      
      {isOpen && (
        <div className="fixed bottom-20 right-6 w-80 sm:w-96 bg-white rounded-lg shadow-xl z-50 overflow-hidden flex flex-col transform animate-fade-in">
          <div className="bg-primary-500 text-white p-4">
            <h3 className="font-bold">Travel Assistant</h3>
            <p className="text-sm opacity-90">We typically reply within minutes</p>
          </div>
          
          <div className="flex-1 p-4 h-96 overflow-y-auto flex flex-col space-y-3">
            {chatHistory.map((msg, i) => (
              <div 
                key={i} 
                className={`max-w-[80%] rounded-lg p-3 ${
                  msg.type === 'user' 
                    ? 'bg-primary-100 ml-auto' 
                    : 'bg-gray-100 mr-auto'
                }`}
              >
                {msg.text}
              </div>
            ))}
          </div>
          
          <form onSubmit={handleSendMessage} className="border-t border-gray-200 p-3 flex">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 border border-gray-300 rounded-l-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
            <button 
              type="submit"
              className="bg-primary-500 text-white rounded-r-lg px-4 flex items-center justify-center"
            >
              <Send size={20} />
            </button>
          </form>
        </div>
      )}
    </>
  );
};

export default ChatSupport;