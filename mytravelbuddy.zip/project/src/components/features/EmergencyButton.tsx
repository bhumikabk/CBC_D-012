import React, { useState } from 'react';
import { AlertTriangle, Phone, MapPin, X } from 'lucide-react';

const EmergencyButton: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  
  const toggleEmergency = () => {
    setIsOpen(!isOpen);
  };
  
  // Sample emergency services data
  const emergencyServices = [
    {
      type: 'Hospital',
      name: 'City General Hospital',
      phone: '+1 (555) 911-0001',
      distance: '2.4 km',
      address: '123 Healthcare Dr, City Center'
    },
    {
      type: 'Police',
      name: 'Downtown Police Station',
      phone: '+1 (555) 911-0002',
      distance: '1.8 km',
      address: '45 Safety Ave, City Center'
    },
    {
      type: 'Embassy',
      name: 'US Embassy',
      phone: '+1 (555) 911-0003',
      distance: '5.2 km',
      address: '78 Diplomat Blvd, Embassy District'
    },
    {
      type: 'Tourist Police',
      name: 'Tourist Police Office',
      phone: '+1 (555) 911-0004',
      distance: '3.1 km',
      address: '90 Visitor Way, Tourism Quarter'
    }
  ];
  
  return (
    <>
      <button 
        onClick={toggleEmergency}
        className={`rounded-full p-3 shadow-lg transition-all transform hover:scale-110 bg-red-500`}
        aria-label="Emergency SOS"
      >
        <AlertTriangle size={24} className="text-white" />
      </button>
      
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md transform animate-fade-in">
            <div className="bg-red-500 text-white p-4 rounded-t-lg flex justify-between items-center">
              <h3 className="font-bold text-xl">Emergency Assistance</h3>
              <button 
                onClick={toggleEmergency}
                className="text-white hover:text-red-100"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="p-6">
              <div className="mb-6">
                <p className="text-gray-700 mb-4">
                  Your current location: <span className="font-semibold">Downtown City Center</span>
                </p>
                <button className="w-full btn btn-primary bg-red-500 hover:bg-red-600 mb-2">
                  Call Emergency Services (911)
                </button>
                <p className="text-sm text-gray-500 text-center">
                  Local emergency number may vary by country
                </p>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-semibold text-lg border-b border-gray-200 pb-2">Nearby Services</h4>
                
                {emergencyServices.map((service, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50">
                    <div className="flex justify-between">
                      <span className="font-medium text-gray-900">{service.type}</span>
                      <span className="text-sm text-gray-500">{service.distance}</span>
                    </div>
                    <div className="mt-1 text-gray-700">{service.name}</div>
                    <div className="mt-2 flex justify-between">
                      <div className="flex items-center text-sm text-gray-600">
                        <MapPin size={16} className="mr-1" />
                        {service.address}
                      </div>
                      <a 
                        href={`tel:${service.phone}`} 
                        className="flex items-center text-primary-600 hover:text-primary-700"
                      >
                        <Phone size={16} className="mr-1" />
                        Call
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default EmergencyButton;