import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Map, Compass, Plane, Leaf, Camera, Users, Route, Award, FileText, Download } from 'lucide-react';

interface NavbarProps {
  toggleOfflineModal: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ toggleOfflineModal }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  
  // Navigation links with icons
  const navLinks = [
    { name: 'Itinerary Builder', path: '/itinerary-builder', icon: <Map size={18} /> },
    { name: 'Trending Spots', path: '/trending', icon: <Compass size={18} /> },
    { name: 'Hidden Gems', path: '/hidden-gems', icon: <Compass size={18} /> },
    { name: 'Booking', path: '/booking', icon: <Plane size={18} /> },
    { name: 'Eco Travel', path: '/eco-travel', icon: <Leaf size={18} /> },
    { name: 'Virtual Tours', path: '/virtual-tours', icon: <Camera size={18} /> },
    { name: 'Community', path: '/community', icon: <Users size={18} /> },
    { name: 'Road Trip', path: '/road-trip', icon: <Route size={18} /> },
    { name: 'Rewards', path: '/rewards', icon: <Award size={18} /> },
    { name: 'Travel Stories', path: '/travel-stories', icon: <FileText size={18} /> },
  ];
  
  // Handle scroll events
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  return (
    <nav className={`sticky top-0 z-50 w-full transition-all duration-300 ${
      isScrolled ? 'bg-white shadow-md' : 'bg-transparent'
    }`}>
      <div className="container-custom">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <Plane 
              size={28} 
              className="text-primary-500" 
              strokeWidth={2.5} 
            />
            <span className="text-xl font-bold font-display text-gray-900">
              MyTravelBuddy
            </span>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex md:items-center md:space-x-4">
            {navLinks.slice(0, 5).map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`flex items-center space-x-1 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  location.pathname === link.path
                    ? 'text-primary-600 bg-primary-50'
                    : 'text-gray-700 hover:text-primary-600 hover:bg-gray-50'
                }`}
              >
                {link.icon}
                <span>{link.name}</span>
              </Link>
            ))}
            
            {/* More Dropdown (for desktop) */}
            <div className="relative group">
              <button className="flex items-center space-x-1 px-3 py-2 text-sm font-medium rounded-md text-gray-700 hover:text-primary-600 hover:bg-gray-50">
                <span>More</span>
              </button>
              <div className="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white py-1 shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none hidden group-hover:block">
                {navLinks.slice(5).map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`flex items-center space-x-2 px-4 py-2 text-sm ${
                      location.pathname === link.path
                        ? 'text-primary-600 bg-primary-50'
                        : 'text-gray-700 hover:text-primary-600 hover:bg-gray-50'
                    }`}
                  >
                    {link.icon}
                    <span>{link.name}</span>
                  </Link>
                ))}
              </div>
            </div>
            
            {/* Offline Mode Button */}
            <button
              onClick={toggleOfflineModal}
              className="flex items-center space-x-1 px-3 py-2 text-sm font-medium rounded-md text-gray-700 hover:text-primary-600 hover:bg-gray-50"
            >
              <Download size={18} />
              <span>Offline</span>
            </button>
          </div>
          
          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 rounded-md text-gray-700 hover:text-primary-600 hover:bg-gray-50"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="container-custom py-3 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`flex items-center space-x-2 px-3 py-2 text-base font-medium rounded-md ${
                  location.pathname === link.path
                    ? 'text-primary-600 bg-primary-50'
                    : 'text-gray-700 hover:text-primary-600 hover:bg-gray-50'
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                {link.icon}
                <span>{link.name}</span>
              </Link>
            ))}
            <button
              onClick={() => {
                toggleOfflineModal();
                setIsMenuOpen(false);
              }}
              className="flex w-full items-center space-x-2 px-3 py-2 text-base font-medium rounded-md text-gray-700 hover:text-primary-600 hover:bg-gray-50"
            >
              <Download size={18} />
              <span>Offline Mode</span>
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;