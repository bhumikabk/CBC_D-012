import React from 'react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex justify-center items-center min-h-[60vh]">
      <div className="relative w-24 h-24">
        <div className="absolute inset-0 border-4 border-t-primary-500 border-r-primary-300 border-b-primary-200 border-l-primary-400 rounded-full animate-spin"></div>
        <div className="absolute inset-2 border-4 border-t-secondary-500 border-r-secondary-300 border-b-secondary-200 border-l-secondary-400 rounded-full animate-spin animation-delay-150"></div>
        <div className="absolute inset-4 border-4 border-t-accent-500 border-r-accent-300 border-b-accent-200 border-l-accent-400 rounded-full animate-spin animation-delay-300"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-4 h-4 bg-primary-500 rounded-full"></div>
        </div>
      </div>
    </div>
  );
};

export default LoadingSpinner;