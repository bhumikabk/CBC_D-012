import React, { useState } from 'react';
import { MapPin, Filter, Star, Coffee, Users, Utensils, Camera, ShoppingBag, Landmark, Tent } from 'lucide-react';

const HiddenGems: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeRegion, setActiveRegion] = useState<string>('all');
  
  // Mock data for categories
  const categories = [
    { id: 'all', name: 'All', icon: <Star size={18} /> },
    { id: 'food', name: 'Local Food', icon: <Utensils size={18} /> },
    { id: 'cafes', name: 'Cafés', icon: <Coffee size={18} /> },
    { id: 'culture', name: 'Cultural', icon: <Landmark size={18} /> },
    { id: 'photo', name: 'Photography', icon: <Camera size={18} /> },
    { id: 'shopping', name: 'Shopping', icon: <ShoppingBag size={18} /> },
    { id: 'outdoor', name: 'Outdoor', icon: <Tent size={18} /> },
  ];
  
  // Mock data for regions
  const regions = [
    { id: 'all', name: 'All Regions' },
    { id: 'europe', name: 'Europe' },
    { id: 'asia', name: 'Asia' },
    { id: 'northamerica', name: 'North America' },
    { id: 'southamerica', name: 'South America' },
    { id: 'africa', name: 'Africa' },
    { id: 'oceania', name: 'Oceania' },
  ];
  
  // Mock data for hidden gems
  const hiddenGems = [
    {
      id: 1,
      name: 'Koh Rong Samloem',
      location: 'Cambodia',
      category: 'outdoor',
      region: 'asia',
      image: 'https://images.pexels.com/photos/1450353/pexels-photo-1450353.jpeg',
      description: 'A serene island with pristine beaches and bioluminescent waters, far from the crowds of popular Southeast Asian destinations.',
      submittedBy: 'Alex Johnson',
      likes: 342,
    },
    {
      id: 2,
      name: 'Procida Island',
      location: 'Italy',
      category: 'photo',
      region: 'europe',
      image: 'https://images.pexels.com/photos/2972153/pexels-photo-2972153.jpeg',
      description: 'A colorful fishing village often overshadowed by nearby Capri and Ischia, featuring pastel-colored houses and authentic Italian charm.',
      submittedBy: 'Elena Romano',
      likes: 289,
    },
    {
      id: 3,
      name: 'La Boca del Infierno',
      location: 'Mexico',
      category: 'food',
      region: 'northamerica',
      image: 'https://images.pexels.com/photos/2092507/pexels-photo-2092507.jpeg',
      description: 'A hidden cenote with crystal-clear waters surrounded by local eateries serving authentic Yucatecan cuisine.',
      submittedBy: 'Carlos Mendez',
      likes: 267,
    },
    {
      id: 4,
      name: 'Hakone Open-Air Museum',
      location: 'Japan',
      category: 'culture',
      region: 'asia',
      image: 'https://images.pexels.com/photos/1738987/pexels-photo-1738987.jpeg',
      description: 'An art museum set in the mountains with spectacular sculptures scattered throughout natural settings.',
      submittedBy: 'Yuki Tanaka',
      likes: 251,
    },
    {
      id: 5,
      name: 'Château de Chambord',
      location: 'France',
      category: 'culture',
      region: 'europe',
      image: 'https://images.pexels.com/photos/338515/pexels-photo-338515.jpeg',
      description: 'A majestic 16th-century château in the Loire Valley, away from the typical Paris tourist track.',
      submittedBy: 'Marie Dupont',
      likes: 235,
    },
    {
      id: 6,
      name: 'Café Reggio',
      location: 'New York, USA',
      category: 'cafes',
      region: 'northamerica',
      image: 'https://images.pexels.com/photos/1855214/pexels-photo-1855214.jpeg',
      description: 'Historic café established in 1927 that introduced cappuccino to America, featuring vintage décor and great people-watching.',
      submittedBy: 'David Williams',
      likes: 218,
    },
    {
      id: 7,
      name: 'Arashiyama Bamboo Grove',
      location: 'Kyoto, Japan',
      category: 'photo',
      region: 'asia',
      image: 'https://images.pexels.com/photos/6535543/pexels-photo-6535543.jpeg',
      description: 'A mystical forest path lined with towering bamboo stalks that create a magical atmosphere, especially at dawn before the crowds arrive.',
      submittedBy: 'Haruka Nakamura',
      likes: 202,
    },
    {
      id: 8,
      name: 'Mercado de San Miguel',
      location: 'Madrid, Spain',
      category: 'shopping',
      region: 'europe',
      image: 'https://images.pexels.com/photos/375897/pexels-photo-375897.jpeg',
      description: 'A historic iron and glass market where locals shop for gourmet foods and wine, offering an authentic taste of Spanish cuisine.',
      submittedBy: 'Isabella García',
      likes: 196,
    },
    {
      id: 9,
      name: 'Paloquemao Market',
      location: 'Bogotá, Colombia',
      category: 'food',
      region: 'southamerica',
      image: 'https://images.pexels.com/photos/3873869/pexels-photo-3873869.jpeg',
      description: 'A vibrant local market where chefs and locals shop for fresh produce and authentic Colombian ingredients.',
      submittedBy: 'Santiago Herrera',
      likes: 187,
    },
  ];
  
  // Filter gems based on selected category and region
  const filteredGems = hiddenGems.filter(gem => 
    (activeCategory === 'all' || gem.category === activeCategory) &&
    (activeRegion === 'all' || gem.region === activeRegion)
  );
  
  return (
    <div className="bg-gray-100 min-h-screen py-12">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Discover Hidden Gems</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore lesser-known locations, local favorites, and off-the-beaten-path destinations around the world
          </p>
        </div>
        
        {/* Filters */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
            <h2 className="text-xl font-semibold flex items-center">
              <Filter size={20} className="mr-2 text-primary-500" />
              Filter Discoveries
            </h2>
            <div className="flex gap-2">
              <select
                value={activeRegion}
                onChange={(e) => setActiveRegion(e.target.value)}
                className="input py-1 px-3 text-sm"
              >
                {regions.map(region => (
                  <option key={region.id} value={region.id}>
                    {region.name}
                  </option>
                ))}
              </select>
              <select
                value="latest"
                className="input py-1 px-3 text-sm"
              >
                <option value="latest">Latest</option>
                <option value="popular">Most Popular</option>
                <option value="rated">Highly Rated</option>
              </select>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`flex items-center px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                  activeCategory === category.id
                    ? 'bg-primary-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <span className="mr-1.5">{category.icon}</span>
                {category.name}
              </button>
            ))}
          </div>
        </div>
        
        {/* Hidden Gems Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGems.map(gem => (
            <div key={gem.id} className="card group">
              <div className="relative h-56 overflow-hidden">
                <img 
                  src={gem.image} 
                  alt={gem.name} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-70 group-hover:opacity-80 transition-opacity"></div>
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <div className="flex items-center text-sm font-medium mb-1">
                    <MapPin size={14} className="mr-1" />
                    <span>{gem.location}</span>
                  </div>
                  <h3 className="font-bold text-xl">{gem.name}</h3>
                </div>
                
                <div className="absolute top-3 right-3">
                  {categories.find(cat => cat.id === gem.category) && (
                    <div className="bg-white/90 backdrop-blur-sm text-xs font-medium px-2 py-1 rounded-full flex items-center">
                      {categories.find(cat => cat.id === gem.category)?.icon}
                      <span className="ml-1 text-gray-800">
                        {categories.find(cat => cat.id === gem.category)?.name}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              <div className="p-5">
                <p className="text-gray-700 mb-4">{gem.description}</p>
                <div className="flex justify-between items-center">
                  <div className="flex items-center text-sm text-gray-500">
                    <Users size={16} className="mr-1" />
                    <span>{gem.submittedBy}</span>
                  </div>
                  <div className="flex items-center">
                    <button className="text-gray-400 hover:text-red-500 transition-colors">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                    </button>
                    <span className="ml-1 text-sm text-gray-500">{gem.likes}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Submit a Hidden Gem */}
        <div className="mt-16 bg-primary-50 rounded-xl overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="relative h-64 md:h-auto overflow-hidden">
              <img 
                src="https://images.pexels.com/photos/3278215/pexels-photo-3278215.jpeg" 
                alt="Hidden gem" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-primary-900/30"></div>
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center text-white">
                <h3 className="text-2xl font-bold mb-2">Share Your Discovery</h3>
                <p className="text-white/90">Help others discover amazing places</p>
              </div>
            </div>
            <div className="p-6 md:p-8">
              <h3 className="text-xl font-bold mb-4">Submit Your Hidden Gem</h3>
              <p className="text-gray-600 mb-6">
                Know a special place that deserves more attention? Share your discovery with fellow travelers.
              </p>
              <form className="space-y-4">
                <div>
                  <label htmlFor="place-name" className="label">Place Name</label>
                  <input type="text" id="place-name" className="input" placeholder="E.g., Secret Beach Cove" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="location" className="label">Location</label>
                    <input type="text" id="location" className="input" placeholder="City, Country" />
                  </div>
                  <div>
                    <label htmlFor="category" className="label">Category</label>
                    <select id="category" className="input">
                      {categories.filter(cat => cat.id !== 'all').map(category => (
                        <option key={category.id} value={category.id}>
                          {category.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label htmlFor="description" className="label">Description</label>
                  <textarea 
                    id="description" 
                    rows={3} 
                    className="input" 
                    placeholder="Tell us what makes this place special..."
                  ></textarea>
                </div>
                <div>
                  <label htmlFor="photo" className="label">Upload Photo (optional)</label>
                  <input 
                    type="file" 
                    id="photo" 
                    className="block w-full text-sm text-gray-500
                    file:mr-4 file:py-2 file:px-4
                    file:rounded-md file:border-0
                    file:text-sm file:font-medium
                    file:bg-primary-50 file:text-primary-700
                    hover:file:bg-primary-100"
                  />
                </div>
                <button type="submit" className="btn btn-primary w-full">
                  Submit Hidden Gem
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HiddenGems;