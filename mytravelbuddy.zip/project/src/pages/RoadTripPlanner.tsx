import React, { useState, useEffect } from 'react';
import { Car, Map as MapIcon, Zap, Coffee, MapPin, Navigation, Clock, Check, ChevronDown, ChevronRight, RotateCw } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix Leaflet icon issues
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const RoadTripPlanner: React.FC = () => {
  const [originInput, setOriginInput] = useState('San Francisco, CA');
  const [destinationInput, setDestinationInput] = useState('Los Angeles, CA');
  const [showStopsPanel, setShowStopsPanel] = useState(true);
  
  // Map state
  const [mapCenter, setMapCenter] = useState<[number, number]>([37.7749, -122.4194]); // San Francisco
  const [zoom, setZoom] = useState(7);
  
  // Mock road trip data
  const routePath: [number, number][] = [
    [37.7749, -122.4194], // San Francisco
    [37.3382, -121.8863], // San Jose
    [36.2704, -121.8081], // Big Sur
    [35.6585, -120.6565], // Paso Robles
    [34.9530, -120.4358], // Santa Maria
    [34.4208, -119.6982], // Santa Barbara
    [34.0522, -118.2437], // Los Angeles
  ];
  
  // Mock stop points
  const stops = [
    {
      id: 1,
      name: 'San Francisco',
      location: 'San Francisco, CA',
      coordinates: [37.7749, -122.4194] as [number, number],
      type: 'origin',
    },
    {
      id: 2,
      name: 'Palo Alto',
      location: 'Palo Alto, CA',
      coordinates: [37.4419, -122.1430] as [number, number],
      type: 'stop',
      icon: <Coffee size={16} />,
      duration: '1h',
      distance: '35 miles',
    },
    {
      id: 3,
      name: 'Monterey',
      location: 'Monterey, CA',
      coordinates: [36.6002, -121.8947] as [number, number],
      type: 'stop',
      icon: <MapPin size={16} />,
      duration: '1.5h',
      distance: '75 miles',
    },
    {
      id: 4,
      name: 'Big Sur',
      location: 'Big Sur, CA',
      coordinates: [36.2704, -121.8081] as [number, number],
      type: 'stop',
      icon: <MapPin size={16} />,
      duration: '45m',
      distance: '30 miles',
    },
    {
      id: 5,
      name: 'Santa Barbara',
      location: 'Santa Barbara, CA',
      coordinates: [34.4208, -119.6982] as [number, number],
      type: 'stop',
      icon: <Zap size={16} />,
      duration: '2.5h',
      distance: '130 miles',
    },
    {
      id: 6,
      name: 'Los Angeles',
      location: 'Los Angeles, CA',
      coordinates: [34.0522, -118.2437] as [number, number],
      type: 'destination',
    },
  ];
  
  // Mock gas stations
  const gasStations = [
    {
      name: 'Shell',
      location: 'Monterey, CA',
      coordinates: [36.5969, -121.8846] as [number, number],
      price: 4.25,
      distance: 'On route',
    },
    {
      name: 'Chevron',
      location: 'Cambria, CA',
      coordinates: [35.5641, -121.0807] as [number, number],
      price: 4.39,
      distance: 'On route',
    },
    {
      name: 'Arco',
      location: 'San Luis Obispo, CA',
      coordinates: [35.2828, -120.6596] as [number, number],
      price: 4.15,
      distance: '3 miles off route',
    },
  ];
  
  // Mock food stops
  const foodStops = [
    {
      name: 'Nepenthe',
      location: 'Big Sur, CA',
      coordinates: [36.2211, -121.7535] as [number, number],
      rating: 4.6,
      cuisine: 'American',
      priceRange: '$$',
    },
    {
      name: 'La Super-Rica Taqueria',
      location: 'Santa Barbara, CA',
      coordinates: [34.4268, -119.7079] as [number, number],
      rating: 4.7,
      cuisine: 'Mexican',
      priceRange: '$',
    },
    {
      name: 'Firestone Grill',
      location: 'San Luis Obispo, CA',
      coordinates: [35.2805, -120.6645] as [number, number],
      rating: 4.8,
      cuisine: 'BBQ',
      priceRange: '$$',
    },
  ];
  
  // Mock attractions
  const attractions = [
    {
      name: '17-Mile Drive',
      location: 'Pebble Beach, CA',
      coordinates: [36.5923, -121.9468] as [number, number],
      rating: 4.8,
      duration: '1-2 hours',
      type: 'Scenic Drive',
    },
    {
      name: 'Hearst Castle',
      location: 'San Simeon, CA',
      coordinates: [35.6852, -121.1666] as [number, number],
      rating: 4.7,
      duration: '2-3 hours',
      type: 'Historic Site',
    },
    {
      name: 'McWay Falls',
      location: 'Big Sur, CA',
      coordinates: [36.1572, -121.6722] as [number, number],
      rating: 4.9,
      duration: '30 minutes',
      type: 'Natural Attraction',
    },
  ];
  
  // Calculate total trip info
  const tripInfo = {
    totalDistance: '380 miles',
    totalDuration: '6h 30m',
    fuelCost: '$55',
    stops: stops.length - 2, // Exclude origin and destination
  };
  
  // Set map center to the middle of the route when component mounts
  useEffect(() => {
    if (routePath.length > 0) {
      const middleIndex = Math.floor(routePath.length / 2);
      setMapCenter(routePath[middleIndex]);
    }
  }, []);
  
  return (
    <div className="bg-gray-100 min-h-screen">
      <div className="container-custom py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Road Trip Planner</h1>
          <button className="btn bg-primary-600 text-white hover:bg-primary-700 flex items-center">
            <Car size={18} className="mr-2" />
            Plan a New Trip
          </button>
        </div>
        
        {/* Trip Details Bar */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 mr-3">
                  <MapIcon size={20} />
                </div>
                <div>
                  <div className="text-sm text-gray-500">California Coastal Trip</div>
                  <div className="font-bold">San Francisco to Los Angeles</div>
                </div>
              </div>
              
              <div className="flex items-center text-gray-600 text-sm">
                <span className="flex items-center mr-3">
                  <MapPin size={16} className="mr-1" />
                  {tripInfo.totalDistance}
                </span>
                <span className="flex items-center mr-3">
                  <Clock size={16} className="mr-1" />
                  {tripInfo.totalDuration}
                </span>
                <span className="flex items-center">
                  <Zap size={16} className="mr-1" />
                  {tripInfo.fuelCost}
                </span>
              </div>
            </div>
            
            <div className="flex gap-2">
              <button className="btn bg-gray-100 hover:bg-gray-200">
                Edit Trip
              </button>
              <button className="btn bg-gray-100 hover:bg-gray-200">
                Share
              </button>
              <button 
                className="btn bg-gray-100 hover:bg-gray-200"
                onClick={() => setShowStopsPanel(!showStopsPanel)}
              >
                {showStopsPanel ? 'Hide Stops' : 'Show Stops'}
              </button>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Stops Panel */}
          {showStopsPanel && (
            <div className="lg:col-span-1 bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4 border-b border-gray-200">
                <h2 className="font-bold">Trip Stops</h2>
              </div>
              
              <div className="p-4">
                <div className="relative">
                  {stops.map((stop, index) => (
                    <div key={stop.id} className={`flex mb-4 ${index < stops.length - 1 ? 'pb-4' : ''}`}>
                      {/* Stop Icon and Connector Line */}
                      <div className="mr-4 relative">
                        <div 
                          className={`
                            w-8 h-8 rounded-full flex items-center justify-center z-10 relative
                            ${stop.type === 'origin' 
                              ? 'bg-green-100 text-green-600' 
                              : stop.type === 'destination' 
                              ? 'bg-red-100 text-red-600' 
                              : 'bg-primary-100 text-primary-600'
                            }
                          `}
                        >
                          {stop.type === 'origin' ? (
                            <span className="font-bold">A</span>
                          ) : stop.type === 'destination' ? (
                            <span className="font-bold">B</span>
                          ) : (
                            <span>{index}</span>
                          )}
                        </div>
                        
                        {/* Connector line */}
                        {index < stops.length - 1 && (
                          <div className="absolute top-8 bottom-0 left-4 w-0.5 -ml-px bg-gray-300"></div>
                        )}
                      </div>
                      
                      {/* Stop Details */}
                      <div className="flex-1">
                        <div className="font-medium">{stop.name}</div>
                        <div className="text-sm text-gray-500">{stop.location}</div>
                        
                        {stop.type === 'stop' && (
                          <div className="mt-1 flex items-center text-xs text-gray-500">
                            {stop.icon}
                            <span className="ml-1 mr-2">{stop.duration} stay</span>
                            <span>•</span>
                            <Clock size={12} className="mx-1" />
                            <span>{stop.distance}</span>
                          </div>
                        )}
                      </div>
                      
                      {/* Actions */}
                      {stop.type === 'stop' && (
                        <button className="text-gray-400 hover:text-gray-600">
                          <ChevronDown size={18} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                
                <button className="w-full mt-2 text-primary-600 hover:text-primary-700 text-sm font-medium flex items-center justify-center">
                  <PlusCircle size={16} className="mr-1" />
                  Add Stop
                </button>
              </div>
              
              {/* Trip Details Section */}
              <div className="p-4 border-t border-gray-200">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium">Trip Details</h3>
                  <button className="text-primary-600 hover:text-primary-700 text-sm">
                    Edit
                  </button>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Start Date</span>
                    <span>June 15, 2023</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">End Date</span>
                    <span>June 18, 2023</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Vehicle</span>
                    <span>2021 Toyota RAV4</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Passengers</span>
                    <span>2 adults</span>
                  </div>
                </div>
              </div>
              
              {/* Preferences */}
              <div className="p-4 border-t border-gray-200">
                <h3 className="font-medium mb-2">Preferences</h3>
                <div className="space-y-2">
                  <label className="flex items-center text-sm">
                    <input type="checkbox" checked className="mr-2" />
                    Avoid highways
                  </label>
                  <label className="flex items-center text-sm">
                    <input type="checkbox" className="mr-2" />
                    Avoid tolls
                  </label>
                  <label className="flex items-center text-sm">
                    <input type="checkbox" checked className="mr-2" />
                    Prioritize scenic routes
                  </label>
                </div>
              </div>
            </div>
          )}
          
          {/* Map Section */}
          <div className={`${showStopsPanel ? 'lg:col-span-3' : 'lg:col-span-4'} bg-white rounded-lg shadow-md overflow-hidden`}>
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="font-bold">Route Map</h2>
              <div className="flex items-center gap-2">
                <button className="text-sm px-3 py-1.5 bg-gray-100 hover:bg-gray-200 rounded-md flex items-center">
                  <Navigation size={14} className="mr-1" />
                  Directions
                </button>
                <button className="text-sm px-3 py-1.5 bg-gray-100 hover:bg-gray-200 rounded-md flex items-center">
                  <RotateCw size={14} className="mr-1" />
                  Recalculate
                </button>
              </div>
            </div>
            
            <div className="h-[600px]">
              <MapContainer 
                center={mapCenter} 
                zoom={zoom} 
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                
                {/* Route Line */}
                <Polyline 
                  positions={routePath}
                  color="#3B82F6"
                  weight={4}
                  opacity={0.7}
                />
                
                {/* Stop Markers */}
                {stops.map((stop) => (
                  <Marker 
                    key={stop.id} 
                    position={stop.coordinates}
                  >
                    <Popup>
                      <div className="font-medium">{stop.name}</div>
                      <div className="text-sm">{stop.location}</div>
                      {stop.type === 'stop' && stop.duration && (
                        <div className="text-sm mt-1">
                          Stay: {stop.duration}
                        </div>
                      )}
                    </Popup>
                  </Marker>
                ))}
                
                {/* Gas Station Markers */}
                {gasStations.map((station, idx) => (
                  <Marker
                    key={`gas-${idx}`}
                    position={station.coordinates}
                    icon={new L.DivIcon({
                      className: 'custom-div-icon',
                      html: `<div style="background-color: rgba(251, 146, 60, 0.9); color: white; width: 24px; height: 24px; display: flex; justify-content: center; align-items: center; border-radius: 50%;">⛽</div>`,
                      iconSize: [24, 24],
                      iconAnchor: [12, 12],
                    })}
                  >
                    <Popup>
                      <div className="font-medium">{station.name}</div>
                      <div className="text-sm">{station.location}</div>
                      <div className="text-sm">
                        ${station.price}/gallon
                      </div>
                      <div className="text-sm">
                        {station.distance}
                      </div>
                    </Popup>
                  </Marker>
                ))}
                
                {/* Food Stop Markers */}
                {foodStops.map((food, idx) => (
                  <Marker
                    key={`food-${idx}`}
                    position={food.coordinates}
                    icon={new L.DivIcon({
                      className: 'custom-div-icon',
                      html: `<div style="background-color: rgba(234, 88, 12, 0.9); color: white; width: 24px; height: 24px; display: flex; justify-content: center; align-items: center; border-radius: 50%;">🍽️</div>`,
                      iconSize: [24, 24],
                      iconAnchor: [12, 12],
                    })}
                  >
                    <Popup>
                      <div className="font-medium">{food.name}</div>
                      <div className="text-sm">{food.location}</div>
                      <div className="text-sm">
                        {food.cuisine} • {food.priceRange}
                      </div>
                      <div className="text-sm">
                        Rating: {food.rating}/5
                      </div>
                    </Popup>
                  </Marker>
                ))}
                
                {/* Attraction Markers */}
                {attractions.map((attraction, idx) => (
                  <Marker
                    key={`attraction-${idx}`}
                    position={attraction.coordinates}
                    icon={new L.DivIcon({
                      className: 'custom-div-icon',
                      html: `<div style="background-color: rgba(79, 70, 229, 0.9); color: white; width: 24px; height: 24px; display: flex; justify-content: center; align-items: center; border-radius: 50%;">🏞️</div>`,
                      iconSize: [24, 24],
                      iconAnchor: [12, 12],
                    })}
                  >
                    <Popup>
                      <div className="font-medium">{attraction.name}</div>
                      <div className="text-sm">{attraction.location}</div>
                      <div className="text-sm">
                        {attraction.type} • {attraction.duration}
                      </div>
                      <div className="text-sm">
                        Rating: {attraction.rating}/5
                      </div>
                    </Popup>
                  </Marker>
                ))}
              </MapContainer>
            </div>
          </div>
        </div>
        
        {/* Additional Information Panels */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          {/* Gas Stations */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="font-bold">Gas Stations</h2>
              <button className="text-sm text-primary-600 hover:text-primary-700 flex items-center">
                View All
                <ChevronRight size={16} className="ml-1" />
              </button>
            </div>
            
            <div className="p-4">
              <div className="space-y-4">
                {gasStations.map((station, idx) => (
                  <div key={idx} className="flex items-start">
                    <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 mr-3 flex-shrink-0">
                      ⛽
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">{station.name}</div>
                      <div className="text-sm text-gray-500">{station.location}</div>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-sm text-gray-700">${station.price}/gallon</span>
                        <span className="text-xs text-gray-500">{station.distance}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Food & Restaurants */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="font-bold">Food & Restaurants</h2>
              <button className="text-sm text-primary-600 hover:text-primary-700 flex items-center">
                View All
                <ChevronRight size={16} className="ml-1" />
              </button>
            </div>
            
            <div className="p-4">
              <div className="space-y-4">
                {foodStops.map((food, idx) => (
                  <div key={idx} className="flex items-start">
                    <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center text-red-600 mr-3 flex-shrink-0">
                      🍽️
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">{food.name}</div>
                      <div className="text-sm text-gray-500">{food.location}</div>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-sm text-gray-700">{food.cuisine} • {food.priceRange}</span>
                        <div className="flex items-center">
                          <span className="text-yellow-500 mr-1">★</span>
                          <span className="text-sm">{food.rating}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Attractions */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="font-bold">Attractions</h2>
              <button className="text-sm text-primary-600 hover:text-primary-700 flex items-center">
                View All
                <ChevronRight size={16} className="ml-1" />
              </button>
            </div>
            
            <div className="p-4">
              <div className="space-y-4">
                {attractions.map((attraction, idx) => (
                  <div key={idx} className="flex items-start">
                    <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 mr-3 flex-shrink-0">
                      🏞️
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">{attraction.name}</div>
                      <div className="text-sm text-gray-500">{attraction.location}</div>
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-sm text-gray-700">{attraction.type} • {attraction.duration}</span>
                        <div className="flex items-center">
                          <span className="text-yellow-500 mr-1">★</span>
                          <span className="text-sm">{attraction.rating}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Trip Checklist */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden mt-6">
          <div className="p-4 border-b border-gray-200">
            <h2 className="font-bold">Pre-Trip Checklist</h2>
          </div>
          
          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="font-medium mb-2">Vehicle Preparation</h3>
                <ul className="space-y-2">
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                      <Check size={12} />
                    </span>
                    Check tire pressure and condition
                  </li>
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                      <Check size={12} />
                    </span>
                    Check oil level and other fluids
                  </li>
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 mr-2">
                      <Check size={12} />
                    </span>
                    Test air conditioning and heating
                  </li>
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 mr-2">
                      <Check size={12} />
                    </span>
                    Inspect wiper blades and fluid
                  </li>
                </ul>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="font-medium mb-2">Essentials to Pack</h3>
                <ul className="space-y-2">
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                      <Check size={12} />
                    </span>
                    Road trip playlist
                  </li>
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                      <Check size={12} />
                    </span>
                    Snacks and water bottles
                  </li>
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                      <Check size={12} />
                    </span>
                    Phone chargers
                  </li>
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 mr-2">
                      <Check size={12} />
                    </span>
                    First aid kit
                  </li>
                </ul>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-4">
                <h3 className="font-medium mb-2">Accommodations</h3>
                <ul className="space-y-2">
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                      <Check size={12} />
                    </span>
                    Book hotel in Monterey (June 15)
                  </li>
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center text-green-600 mr-2">
                      <Check size={12} />
                    </span>
                    Book hotel in Santa Barbara (June 16)
                  </li>
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 mr-2">
                      <Check size={12} />
                    </span>
                    Book hotel in Los Angeles (June 17)
                  </li>
                  <li className="flex items-center text-sm">
                    <span className="w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 mr-2">
                      <Check size={12} />
                    </span>
                    Confirm all reservations
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Function to create a PlusCircle icon
const PlusCircle = ({ size, className }: { size: number, className?: string }) => {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="16" />
      <line x1="8" y1="12" x2="16" y2="12" />
    </svg>
  );
};

export default RoadTripPlanner;