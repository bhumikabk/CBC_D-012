import React, { useState } from 'react';
import { Leaf, Award, BarChart3, Flower2, Recycle, ThermometerSnowflake, Cloud } from 'lucide-react';

const EcoTravelGuide: React.FC = () => {
  const [activeTab, setActiveTab] = useState('lodging');
  
  // Mock eco-friendly lodging data
  const ecoLodging = [
    {
      id: 1,
      name: 'Sunrise Eco Lodge',
      location: 'Bali, Indonesia',
      image: 'https://images.pexels.com/photos/6338454/pexels-photo-6338454.jpeg',
      description: 'Sustainable bamboo architecture with solar power, water recycling, and farm-to-table dining.',
      rating: 4.9,
      ecoScore: 96,
      badges: ['Carbon Neutral', 'Plastic Free', 'Local Materials'],
      features: [
        { name: 'Solar Power', icon: <Leaf size={16} /> },
        { name: 'Organic Garden', icon: <Flower2 size={16} /> },
        { name: 'Water Recycling', icon: <Recycle size={16} /> },
      ],
      price: '175'
    },
    {
      id: 2,
      name: 'Forest Canopy Retreat',
      location: 'Costa Rica',
      image: 'https://images.pexels.com/photos/9482123/pexels-photo-9482123.jpeg',
      description: 'Tree house accommodations in a protected rainforest with wildlife conservation programs.',
      rating: 4.8,
      ecoScore: 94,
      badges: ['Wildlife Protection', 'Rainforest Conservation', 'Energy Efficient'],
      features: [
        { name: 'Rainwater Harvesting', icon: <Cloud size={16} /> },
        { name: 'Conservation Fund', icon: <Award size={16} /> },
        { name: 'Limited Electricity', icon: <ThermometerSnowflake size={16} /> },
      ],
      price: '220'
    },
    {
      id: 3,
      name: 'Nordic Eco Cabins',
      location: 'Norway',
      image: 'https://images.pexels.com/photos/2662180/pexels-photo-2662180.jpeg',
      description: 'Off-grid eco cabins built with sustainable materials and minimal environmental impact.',
      rating: 4.7,
      ecoScore: 92,
      badges: ['Zero Waste', 'Renewable Energy', 'Low Impact'],
      features: [
        { name: 'Geothermal Heating', icon: <ThermometerSnowflake size={16} /> },
        { name: 'Sustainable Wood', icon: <Leaf size={16} /> },
        { name: 'Waste Composting', icon: <Recycle size={16} /> },
      ],
      price: '195'
    },
  ];
  
  // Mock eco-friendly nature parks data
  const natureParks = [
    {
      id: 1,
      name: 'Monteverde Cloud Forest Reserve',
      location: 'Costa Rica',
      image: 'https://images.pexels.com/photos/914128/pexels-photo-914128.jpeg',
      description: 'Protected cloud forest with remarkable biodiversity and conservation efforts.',
      activities: ['Hiking', 'Bird Watching', 'Guided Tours', 'Conservation Programs'],
      biodiversity: 'High',
      protection: 'National Park',
      ecoScore: 98
    },
    {
      id: 2,
      name: 'Torres del Paine National Park',
      location: 'Chile',
      image: 'https://images.pexels.com/photos/2444403/pexels-photo-2444403.jpeg',
      description: 'Stunning mountain and lake landscapes with strict sustainability regulations.',
      activities: ['Trekking', 'Wildlife Viewing', 'Camping', 'Photography'],
      biodiversity: 'Medium',
      protection: 'UNESCO Biosphere Reserve',
      ecoScore: 95
    },
    {
      id: 3,
      name: 'Banff National Park',
      location: 'Canada',
      image: 'https://images.pexels.com/photos/1486052/pexels-photo-1486052.jpeg',
      description: 'Canada\'s oldest national park with remarkable conservation efforts and natural beauty.',
      activities: ['Hiking', 'Skiing', 'Wildlife Viewing', 'Lake Activities'],
      biodiversity: 'High',
      protection: 'National Park',
      ecoScore: 94
    },
  ];
  
  // Mock eco-friendly travel tips
  const ecoTravelTips = [
    {
      id: 1,
      title: 'Choose Eco-Friendly Transportation',
      description: 'Opt for trains over planes for shorter distances, use public transportation, or rent hybrid/electric vehicles.',
      icon: <Leaf size={24} />,
      impact: 'High'
    },
    {
      id: 2,
      title: 'Pack Light and Right',
      description: 'Bring reusable items like water bottles, shopping bags, and toiletry containers to reduce waste.',
      icon: <Recycle size={24} />,
      impact: 'Medium'
    },
    {
      id: 3,
      title: 'Support Local Communities',
      description: 'Buy local products, eat at locally-owned restaurants, and participate in community-based tourism.',
      icon: <Award size={24} />,
      impact: 'High'
    },
    {
      id: 4,
      title: 'Conserve Water and Energy',
      description: 'Reuse towels, take shorter showers, and turn off lights and AC when leaving your accommodation.',
      icon: <ThermometerSnowflake size={24} />,
      impact: 'Medium'
    },
    {
      id: 5,
      title: 'Respect Wildlife and Nature',
      description: 'Observe animals from a distance, stay on designated trails, and never feed wildlife.',
      icon: <Flower2 size={24} />,
      impact: 'High'
    },
    {
      id: 6,
      title: 'Choose Certified Eco-Lodging',
      description: 'Look for accommodations with recognized eco-certifications and sustainability practices.',
      icon: <Award size={24} />,
      impact: 'High'
    },
  ];
  
  // Mock carbon footprint data for different transportation methods
  const carbonData = [
    { method: 'Flight (economy)', emissions: 255, unit: 'g CO₂/passenger/km' },
    { method: 'Car (average gasoline)', emissions: 192, unit: 'g CO₂/passenger/km' },
    { method: 'Bus', emissions: 105, unit: 'g CO₂/passenger/km' },
    { method: 'Train', emissions: 41, unit: 'g CO₂/passenger/km' },
    { method: 'Ferry', emissions: 120, unit: 'g CO₂/passenger/km' },
    { method: 'Electric Vehicle', emissions: 53, unit: 'g CO₂/passenger/km' },
  ];
  
  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container-custom">
        <div className="text-center mb-12">
          <span className="inline-block bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium mb-3">
            Sustainable Travel
          </span>
          <h1 className="text-4xl font-bold mb-4">Eco-Friendly Travel Guide</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover sustainable lodging, natural parks, and learn how to minimize your travel footprint
          </p>
        </div>
        
        {/* Hero Image */}
        <div className="relative h-80 md:h-96 rounded-xl overflow-hidden mb-12">
          <img 
            src="https://images.pexels.com/photos/1402850/pexels-photo-1402850.jpeg" 
            alt="Eco-friendly travel" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-green-900/70 to-transparent flex items-center">
            <div className="max-w-lg px-8 md:px-12">
              <h2 className="text-white text-3xl font-bold mb-4">Travel Responsibly,<br />Explore Sustainably</h2>
              <p className="text-white/90 mb-6">
                Make a positive impact on the places you visit while creating unforgettable memories.
              </p>
              <button className="bg-white text-green-700 hover:bg-green-50 px-6 py-3 rounded-lg font-medium transition-colors">
                Calculate Your Travel Footprint
              </button>
            </div>
          </div>
        </div>
        
        {/* Tabs */}
        <div className="bg-white shadow-md rounded-xl mb-12 overflow-hidden">
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('lodging')}
              className={`px-4 py-3 text-sm font-medium ${
                activeTab === 'lodging'
                  ? 'border-b-2 border-green-500 text-green-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Eco-Friendly Lodging
            </button>
            <button
              onClick={() => setActiveTab('parks')}
              className={`px-4 py-3 text-sm font-medium ${
                activeTab === 'parks'
                  ? 'border-b-2 border-green-500 text-green-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Nature Parks
            </button>
            <button
              onClick={() => setActiveTab('carbon')}
              className={`px-4 py-3 text-sm font-medium ${
                activeTab === 'carbon'
                  ? 'border-b-2 border-green-500 text-green-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Carbon Stats
            </button>
            <button
              onClick={() => setActiveTab('tips')}
              className={`px-4 py-3 text-sm font-medium ${
                activeTab === 'tips'
                  ? 'border-b-2 border-green-500 text-green-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Eco-Travel Tips
            </button>
          </div>
          
          {/* Tab Content */}
          <div className="p-6">
            {/* Eco-Friendly Lodging Tab */}
            {activeTab === 'lodging' && (
              <div>
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Sustainable Stays</h3>
                  <p className="text-gray-600">
                    Accommodations that minimize environmental impact while maximizing your experience.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {ecoLodging.map((lodge) => (
                    <div key={lodge.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                      <div className="relative h-48">
                        <img 
                          src={lodge.image} 
                          alt={lodge.name} 
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-0 right-0 bg-green-100 text-green-800 m-2 px-2 py-1 rounded text-xs font-medium flex items-center">
                          <Leaf size={12} className="mr-1" />
                          Eco Score: {lodge.ecoScore}
                        </div>
                      </div>
                      <div className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-bold text-lg">{lodge.name}</h4>
                          <div className="flex items-center text-sm">
                            <span className="font-medium text-yellow-500 mr-1">{lodge.rating}</span>
                            <svg className="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                          </div>
                        </div>
                        <p className="text-gray-500 text-sm mb-2">{lodge.location}</p>
                        <p className="text-gray-700 text-sm mb-3">{lodge.description}</p>
                        
                        <div className="flex flex-wrap gap-1 mb-3">
                          {lodge.badges.map((badge, index) => (
                            <span 
                              key={index} 
                              className="bg-green-50 text-green-700 text-xs px-2 py-1 rounded"
                            >
                              {badge}
                            </span>
                          ))}
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <div className="flex space-x-2">
                            {lodge.features.map((feature, index) => (
                              <div 
                                key={index} 
                                className="text-green-600 tooltip"
                                title={feature.name}
                              >
                                {feature.icon}
                              </div>
                            ))}
                          </div>
                          <div className="font-bold text-green-600">${lodge.price}<span className="text-gray-500 text-sm font-normal">/night</span></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* Nature Parks Tab */}
            {activeTab === 'parks' && (
              <div>
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Protected Natural Areas</h3>
                  <p className="text-gray-600">
                    Explore some of the world's most breathtaking ecosystems while supporting conservation.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {natureParks.map((park) => (
                    <div key={park.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                      <div className="relative h-48">
                        <img 
                          src={park.image} 
                          alt={park.name} 
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                          <h4 className="font-bold text-lg text-white">{park.name}</h4>
                          <p className="text-white/90 text-sm">{park.location}</p>
                        </div>
                      </div>
                      <div className="p-4">
                        <p className="text-gray-700 text-sm mb-3">{park.description}</p>
                        
                        <div className="border-t border-gray-100 pt-3">
                          <div className="grid grid-cols-2 gap-2 mb-3">
                            <div>
                              <p className="text-xs text-gray-500">Protection Status</p>
                              <p className="text-sm font-medium">{park.protection}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500">Biodiversity</p>
                              <p className="text-sm font-medium">{park.biodiversity}</p>
                            </div>
                          </div>
                          
                          <div className="mb-3">
                            <p className="text-xs text-gray-500 mb-1">Activities</p>
                            <div className="flex flex-wrap gap-1">
                              {park.activities.map((activity, index) => (
                                <span 
                                  key={index} 
                                  className="bg-green-50 text-green-700 text-xs px-2 py-0.5 rounded"
                                >
                                  {activity}
                                </span>
                              ))}
                            </div>
                          </div>
                          
                          <div className="flex items-center text-green-700">
                            <Award size={16} className="mr-1" />
                            <span className="text-sm font-medium">Eco Score: {park.ecoScore}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* Carbon Stats Tab */}
            {activeTab === 'carbon' && (
              <div>
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Carbon Footprint Information</h3>
                  <p className="text-gray-600">
                    Compare the environmental impact of different transportation methods to make informed choices.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <h4 className="font-bold mb-4 flex items-center">
                      <BarChart3 size={18} className="mr-2 text-green-600" />
                      Transport Emissions Comparison
                    </h4>
                    
                    <div className="space-y-3">
                      {carbonData.map((item, index) => (
                        <div key={index}>
                          <div className="flex justify-between text-sm mb-1">
                            <span>{item.method}</span>
                            <span className="font-medium">{item.emissions} {item.unit}</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div 
                              className={`h-2.5 rounded-full ${
                                item.emissions < 60 ? 'bg-green-500' :
                                item.emissions < 120 ? 'bg-yellow-500' : 
                                'bg-red-500'
                              }`}
                              style={{ width: `${(item.emissions / 255) * 100}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <p className="text-xs text-gray-500 mt-4">
                      Data source: European Environment Agency, 2021
                    </p>
                  </div>
                  
                  <div>
                    <div className="bg-white border border-gray-200 rounded-lg p-4 mb-4">
                      <h4 className="font-bold mb-3">Travel Footprint Calculator</h4>
                      <p className="text-sm text-gray-600 mb-4">
                        Estimate the carbon footprint of your trip to help offset your impact.
                      </p>
                      
                      <div className="space-y-3">
                        <div>
                          <label className="text-sm font-medium text-gray-700 block mb-1">Transportation Type</label>
                          <select className="input">
                            <option>Flight (economy)</option>
                            <option>Flight (business)</option>
                            <option>Car (gasoline)</option>
                            <option>Car (electric)</option>
                            <option>Train</option>
                            <option>Bus</option>
                            <option>Ferry</option>
                          </select>
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium text-gray-700 block mb-1">Distance (km)</label>
                          <input type="number" className="input" placeholder="e.g., 500" />
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium text-gray-700 block mb-1">Number of Passengers</label>
                          <input type="number" className="input" defaultValue="1" />
                        </div>
                        
                        <button className="btn bg-green-600 hover:bg-green-700 text-white w-full">
                          Calculate Carbon Footprint
                        </button>
                      </div>
                    </div>
                    
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <h4 className="font-bold text-green-800 mb-2">Carbon Offset Programs</h4>
                      <p className="text-sm text-green-700 mb-3">
                        Consider offsetting your travel emissions by supporting these certified projects:
                      </p>
                      <ul className="text-sm text-green-700 space-y-2">
                        <li className="flex items-start">
                          <span className="mr-2">•</span>
                          <span>Tropical Forest Conservation (Indonesia, Brazil)</span>
                        </li>
                        <li className="flex items-start">
                          <span className="mr-2">•</span>
                          <span>Wind Power Development (India, Mexico)</span>
                        </li>
                        <li className="flex items-start">
                          <span className="mr-2">•</span>
                          <span>Clean Cookstoves (Kenya, Ghana)</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Eco-Travel Tips Tab */}
            {activeTab === 'tips' && (
              <div>
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-2">Sustainable Travel Practices</h3>
                  <p className="text-gray-600">
                    Practical tips to minimize your environmental footprint while maximizing your positive impact.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {ecoTravelTips.map((tip) => (
                    <div key={tip.id} className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-sm transition-shadow">
                      <div className="flex items-start">
                        <div className="bg-green-100 p-2 rounded-lg mr-3">
                          {tip.icon}
                        </div>
                        <div>
                          <h4 className="font-bold mb-1">{tip.title}</h4>
                          <p className="text-sm text-gray-600 mb-2">{tip.description}</p>
                          <span 
                            className={`text-xs px-2 py-0.5 rounded ${
                              tip.impact === 'High' 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-yellow-100 text-yellow-800'
                            }`}
                          >
                            {tip.impact} Impact
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-8 bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-start">
                    <Award size={24} className="text-green-600 mr-3 mt-1" />
                    <div>
                      <h4 className="font-bold text-green-800 mb-1">Eco-Certification Guide</h4>
                      <p className="text-sm text-green-700 mb-2">
                        Look for these reliable eco-certifications when booking accommodations and tours:
                      </p>
                      <ul className="text-sm text-green-700 space-y-1 ml-4 list-disc">
                        <li>Global Sustainable Tourism Council (GSTC)</li>
                        <li>Leadership in Energy and Environmental Design (LEED)</li>
                        <li>Green Key</li>
                        <li>EarthCheck</li>
                        <li>Rainforest Alliance</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Pledge Section */}
        <div className="bg-green-600 text-white rounded-xl overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="p-8 flex items-center">
              <div>
                <h2 className="text-2xl font-bold mb-4">Take the Eco-Travel Pledge</h2>
                <p className="mb-6">
                  Join thousands of responsible travelers who have committed to sustainable travel practices. Together we can protect destinations for future generations.
                </p>
                <button className="bg-white text-green-700 hover:bg-green-50 px-6 py-3 rounded-lg font-medium transition-colors">
                  Sign the Pledge
                </button>
              </div>
            </div>
            <div className="relative h-64 md:h-auto overflow-hidden">
              <img 
                src="https://images.pexels.com/photos/3329292/pexels-photo-3329292.jpeg" 
                alt="Sustainable travel" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/20"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EcoTravelGuide;