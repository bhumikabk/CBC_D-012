import React, { useState } from 'react';
import { Eye, Globe, Map, MapPin, Calendar, Info, ChevronLeft, ChevronRight, Play } from 'lucide-react';

const VirtualTours: React.FC = () => {
  const [selectedTour, setSelectedTour] = useState<string | null>(null);
  
  // Mock data for virtual/AR tours
  const virtualTours = [
    {
      id: 'colosseum',
      name: 'Colosseum',
      location: 'Rome, Italy',
      image: 'https://images.pexels.com/photos/1797161/pexels-photo-1797161.jpeg',
      description: 'Step back in time and explore the ancient Roman Colosseum, the largest amphitheater ever built.',
      videoId: 'z63ZCgAliQs',
      duration: '15 minutes',
      rating: 4.8,
      reviews: 342,
      category: 'Historical'
    },
    {
      id: 'machu-picchu',
      name: 'Machu Picchu',
      location: 'Peru',
      image: 'https://images.pexels.com/photos/2929906/pexels-photo-2929906.jpeg',
      description: 'Discover the mysteries of this ancient Incan citadel set high in the Andes Mountains.',
      videoId: 'iWBQH7o5P0E',
      duration: '20 minutes',
      rating: 4.9,
      reviews: 518,
      category: 'Historical'
    },
    {
      id: 'taj-mahal',
      name: 'Taj Mahal',
      location: 'Agra, India',
      image: 'https://images.pexels.com/photos/1603650/pexels-photo-1603650.jpeg',
      description: 'Explore the iconic ivory-white marble mausoleum, one of the most recognizable structures in the world.',
      videoId: 'jFQoRbLr0cM',
      duration: '12 minutes',
      rating: 4.7,
      reviews: 275,
      category: 'Historical'
    },
    {
      id: 'great-barrier-reef',
      name: 'Great Barrier Reef',
      location: 'Queensland, Australia',
      image: 'https://images.pexels.com/photos/3329291/pexels-photo-3329291.jpeg',
      description: 'Dive into the world\'s largest coral reef system and explore its vibrant marine life.',
      videoId: 'U92Cp6439hA',
      duration: '25 minutes',
      rating: 4.8,
      reviews: 310,
      category: 'Natural'
    },
    {
      id: 'louvre-museum',
      name: 'Louvre Museum',
      location: 'Paris, France',
      image: 'https://images.pexels.com/photos/2363/france-landmark-lights-night.jpg',
      description: 'Explore the world\'s largest art museum and home to thousands of works including the Mona Lisa.',
      videoId: 'x7wIC_5QdLc',
      duration: '30 minutes',
      rating: 4.6,
      reviews: 402,
      category: 'Cultural'
    },
    {
      id: 'grand-canyon',
      name: 'Grand Canyon',
      location: 'Arizona, USA',
      image: 'https://images.pexels.com/photos/221148/pexels-photo-221148.jpeg',
      description: 'Experience the breathtaking views and immense scale of one of nature\'s greatest wonders.',
      videoId: 'ftPG0LeuDfw',
      duration: '18 minutes',
      rating: 4.9,
      reviews: 384,
      category: 'Natural'
    },
    {
      id: 'santorini',
      name: 'Santorini',
      location: 'Greece',
      image: 'https://images.pexels.com/photos/1010657/pexels-photo-1010657.jpeg',
      description: 'Wander through the picturesque white-washed buildings and blue domes of this stunning Greek island.',
      videoId: '5T8TgSBJpvI',
      duration: '15 minutes',
      rating: 4.7,
      reviews: 298,
      category: 'Cultural'
    },
    {
      id: 'petra',
      name: 'Petra',
      location: 'Jordan',
      image: 'https://images.pexels.com/photos/1631665/pexels-photo-1631665.jpeg',
      description: 'Discover the ancient city carved into rose-colored stone, one of the world\'s most famous archaeological sites.',
      videoId: 'NuXHLZP3HMQ',
      duration: '22 minutes',
      rating: 4.8,
      reviews: 256,
      category: 'Historical'
    },
  ];
  
  // Mock featured tour
  const featuredTour = {
    id: 'kyoto-temples',
    name: 'Kyoto Temples and Gardens',
    location: 'Kyoto, Japan',
    image: 'https://images.pexels.com/photos/402028/pexels-photo-402028.jpeg',
    description: 'Immerse yourself in the serene beauty of Kyoto\'s ancient temples, traditional gardens, and peaceful shrines in this 360° tour. Experience the changing seasons from cherry blossoms to autumn leaves in Japan\'s cultural heart.',
    videoId: 'VnFvySFjJ5c',
    highlightPoints: [
      'Fushimi Inari Shrine with thousands of vermilion torii gates',
      'Kinkaku-ji (Golden Pavilion) surrounded by reflective pond',
      'Arashiyama Bamboo Grove\'s towering stalks',
      'Gion district with traditional tea houses and geishas',
      'Philosopher\'s Path along a cherry tree-lined canal'
    ]
  };
  
  const handleTourClick = (tourId: string) => {
    setSelectedTour(tourId);
    
    // Scroll to the tour viewer
    const element = document.getElementById('tour-viewer');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };
  
  // Get the selected tour data
  const getSelectedTourData = () => {
    if (!selectedTour) return null;
    return virtualTours.find(tour => tour.id === selectedTour) || 
           (featuredTour.id === selectedTour ? featuredTour : null);
  };
  
  const selectedTourData = getSelectedTourData();
  
  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Virtual Heritage Tours</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore iconic landmarks and cultural sites around the world through immersive 360° experiences
          </p>
        </div>
        
        {/* Featured Virtual Tour */}
        <div className="bg-white rounded-xl overflow-hidden shadow-md mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="relative">
              <div className="aspect-w-16 aspect-h-9 lg:h-full">
                <img 
                  src={featuredTour.image} 
                  alt={featuredTour.name} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <div className="flex items-center mb-1">
                    <MapPin size={16} className="mr-1" />
                    <span className="text-sm">{featuredTour.location}</span>
                  </div>
                  <h2 className="text-2xl font-bold">{featuredTour.name}</h2>
                </div>
                <button 
                  className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white/20 backdrop-blur-sm rounded-full p-4 hover:bg-white/30 transition-colors"
                  onClick={() => handleTourClick(featuredTour.id)}
                >
                  <Play size={36} className="text-white" />
                </button>
              </div>
            </div>
            <div className="p-6 md:p-8">
              <div className="flex items-center text-gray-500 text-sm mb-4">
                <Eye className="mr-1" size={16} />
                <span>Featured Virtual Experience</span>
              </div>
              
              <h3 className="text-2xl font-bold mb-3">{featuredTour.name}</h3>
              <p className="text-gray-700 mb-4">{featuredTour.description}</p>
              
              <div className="mb-4">
                <h4 className="font-medium mb-2">Highlights:</h4>
                <ul className="space-y-1 text-gray-700 text-sm ml-4">
                  {featuredTour.highlightPoints.map((point, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-primary-500 mr-2">•</span>
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="flex justify-between items-center mt-6">
                <button 
                  onClick={() => handleTourClick(featuredTour.id)}
                  className="btn btn-primary flex items-center"
                >
                  <Eye size={18} className="mr-2" />
                  Start Virtual Tour
                </button>
                <button className="text-primary-600 hover:text-primary-700 font-medium text-sm flex items-center">
                  Learn more
                  <ChevronRight size={16} className="ml-1" />
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Tour Viewer (Show when a tour is selected) */}
        {selectedTourData && (
          <div id="tour-viewer" className="bg-white rounded-xl overflow-hidden shadow-md mb-12">
            <div className="aspect-w-16 aspect-h-9">
              <iframe
                src={`https://www.youtube.com/embed/${selectedTourData.videoId}?autoplay=1&rel=0`}
                title={`Virtual tour of ${selectedTourData.name}`}
                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full"
              ></iframe>
            </div>
            <div className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-2xl font-bold mb-1">{selectedTourData.name}</h3>
                  <div className="flex items-center text-gray-600 mb-3">
                    <MapPin size={16} className="mr-1" />
                    <span>{selectedTourData.location}</span>
                    {'category' in selectedTourData && (
                      <>
                        <span className="mx-2">•</span>
                        <span>{selectedTourData.category}</span>
                      </>
                    )}
                    {'duration' in selectedTourData && (
                      <>
                        <span className="mx-2">•</span>
                        <Calendar size={16} className="mr-1" />
                        <span>{selectedTourData.duration}</span>
                      </>
                    )}
                  </div>
                  <p className="text-gray-700">{selectedTourData.description}</p>
                </div>
                {'rating' in selectedTourData && (
                  <div className="bg-primary-50 text-primary-700 px-3 py-1 rounded-lg flex items-center">
                    <span className="font-bold mr-1">{selectedTourData.rating}</span>
                    <svg className="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                    <span className="text-xs ml-1">({selectedTourData.reviews})</span>
                  </div>
                )}
              </div>
              
              <div className="flex justify-between items-center mt-6">
                <button
                  onClick={() => setSelectedTour(null)}
                  className="flex items-center text-gray-600 hover:text-gray-900"
                >
                  <ChevronLeft size={16} className="mr-1" />
                  Back to all tours
                </button>
                <div className="flex space-x-3">
                  <button className="btn border border-gray-300 hover:bg-gray-50 flex items-center">
                    <Info size={16} className="mr-2" />
                    More Info
                  </button>
                  <button className="btn btn-primary flex items-center">
                    <Map size={16} className="mr-2" />
                    View on Map
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* All Virtual Tours */}
        <div>
          <div className="flex justify-between items-end mb-6">
            <div>
              <h2 className="text-2xl font-bold mb-2">Explore Virtual Tours</h2>
              <p className="text-gray-600">
                Immerse yourself in stunning 360° views of iconic destinations
              </p>
            </div>
            <div className="flex space-x-2">
              <button className="p-2 rounded-md border border-gray-300 hover:bg-gray-50">
                <ChevronLeft size={16} />
              </button>
              <button className="p-2 rounded-md border border-gray-300 hover:bg-gray-50">
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {virtualTours.map((tour) => (
              <div 
                key={tour.id} 
                className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => handleTourClick(tour.id)}
              >
                <div className="relative h-48">
                  <img 
                    src={tour.image} 
                    alt={tour.name} 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 hover:opacity-100 transition-opacity">
                    <button className="bg-white/20 backdrop-blur-sm rounded-full p-3 hover:bg-white/30 transition-colors">
                      <Play size={24} className="text-white" />
                    </button>
                  </div>
                  <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-sm text-white text-xs px-2 py-1 rounded">
                    {tour.duration}
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-center text-gray-500 text-xs mb-1">
                    <MapPin size={12} className="mr-1" />
                    <span>{tour.location}</span>
                    <span className="mx-1">•</span>
                    <span>{tour.category}</span>
                  </div>
                  <h3 className="font-bold mb-2">{tour.name}</h3>
                  <div className="flex items-center text-sm">
                    <span className="text-yellow-500 font-medium mr-1">{tour.rating}</span>
                    <svg className="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                    <span className="text-gray-500 text-xs ml-1">({tour.reviews})</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Virtual Reality Information */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-indigo-700 rounded-xl overflow-hidden text-white">
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="p-8 flex items-center">
              <div>
                <h2 className="text-2xl font-bold mb-4">Experience in Virtual Reality</h2>
                <p className="mb-6">
                  Take your virtual explorations to the next level with our VR-compatible tours. Use your VR headset for a fully immersive travel experience from the comfort of your home.
                </p>
                <div className="flex flex-col sm:flex-row gap-3">
                  <button className="btn bg-white text-blue-700 hover:bg-blue-50">
                    Learn About VR Mode
                  </button>
                  <button className="btn border border-white hover:bg-white/10">
                    Compatible Devices
                  </button>
                </div>
              </div>
            </div>
            <div className="relative h-64 md:h-auto">
              <img 
                src="https://images.pexels.com/photos/8069152/pexels-photo-8069152.jpeg" 
                alt="VR Headset" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/10"></div>
            </div>
          </div>
        </div>
        
        {/* Benefits Section */}
        <div className="mt-16 mb-8">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold mb-2">Why Choose Virtual Tours</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Explore the world's most amazing destinations without leaving your home
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-xl p-6 text-center shadow-sm">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe size={32} className="text-blue-600" />
              </div>
              <h3 className="text-lg font-bold mb-2">Explore Anywhere</h3>
              <p className="text-gray-600">
                Visit destinations that might be difficult to access in person, from ancient ruins to remote natural wonders.
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-6 text-center shadow-sm">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar size={32} className="text-green-600" />
              </div>
              <h3 className="text-lg font-bold mb-2">Plan Better Trips</h3>
              <p className="text-gray-600">
                Preview destinations before your actual visit to make informed decisions and create more effective itineraries.
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-6 text-center shadow-sm">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Info size={32} className="text-purple-600" />
              </div>
              <h3 className="text-lg font-bold mb-2">Expert Commentary</h3>
              <p className="text-gray-600">
                Learn historical and cultural insights from expert guides who share fascinating stories about each location.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VirtualTours;