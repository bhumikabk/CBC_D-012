import React, { useState } from 'react';
import { Phone, AlertTriangle, MapPin, Wifi, X, Heart, Briefcase, Shield, Info, ChevronDown, ChevronUp } from 'lucide-react';

const Emergency: React.FC = () => {
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [expandedFaqs, setExpandedFaqs] = useState<number[]>([]);
  
  // Mock user location data
  const userLocation = {
    city: 'Bangkok',
    country: 'Thailand',
    coordinates: {
      latitude: 13.7563,
      longitude: 100.5018
    }
  };
  
  // Mock emergency numbers for the current location
  const emergencyNumbers = {
    general: '191',
    police: '191',
    ambulance: '1669',
    fire: '199',
    touristPolice: '1155'
  };
  
  // Mock nearby emergency facilities
  const nearbyFacilities = [
    {
      id: 1,
      name: 'Bangkok Hospital',
      type: 'Hospital',
      address: '2 Soi Soonvijai 7, New Petchburi Rd',
      distance: '1.2 km',
      phone: '+66 2-310-3000',
      open: '24 hours',
      languages: ['English', 'Thai', 'Chinese'],
    },
    {
      id: 2,
      name: 'Tourist Police Station',
      type: 'Police',
      address: 'Pathum Wan, Bangkok 10330',
      distance: '1.8 km',
      phone: '1155',
      open: '24 hours',
      languages: ['English', 'Thai'],
    },
    {
      id: 3,
      name: 'U.S. Embassy',
      type: 'Embassy',
      address: '95 Wireless Road, Bangkok 10330',
      distance: '2.5 km',
      phone: '+66 2-205-4000',
      open: '8:00 AM - 4:30 PM (Mon-Fri)',
      languages: ['English', 'Thai'],
    },
    {
      id: 4,
      name: 'Siam Clinic',
      type: 'Medical',
      address: 'Siam Square, Pathum Wan, Bangkok 10330',
      distance: '0.9 km',
      phone: '+66 2-658-1234',
      open: '9:00 AM - 9:00 PM',
      languages: ['English', 'Thai'],
    },
  ];
  
  // Mock emergency tips
  const emergencyTips = [
    {
      id: 1,
      title: 'Medical Emergency',
      content: 'Call the local emergency number immediately. In Thailand, call 1669 for ambulance services. For non-urgent medical care, visit a local clinic or hospital. Many private hospitals in Bangkok have international departments with English-speaking staff.',
    },
    {
      id: 2,
      title: 'Lost Passport',
      content: 'Contact your embassy or consulate immediately. File a police report at the local police station or tourist police (1155 in Thailand). You\'ll need the police report to get a replacement passport.',
    },
    {
      id: 3,
      title: 'Natural Disaster',
      content: 'Follow instructions from local authorities. In case of flooding, move to higher ground. For earthquakes, drop, cover, and hold on. Stay indoors during thunderstorms. Monitor local news and your embassy\'s alerts.',
    },
    {
      id: 4,
      title: 'Theft or Robbery',
      content: 'Report to the local police or tourist police immediately. Cancel any stolen credit cards and notify your bank. Contact your embassy if your passport was stolen. Avoid carrying all your valuables together.',
    },
  ];
  
  // Toggle FAQ expansion
  const toggleFaq = (id: number) => {
    if (expandedFaqs.includes(id)) {
      setExpandedFaqs(expandedFaqs.filter(faqId => faqId !== id));
    } else {
      setExpandedFaqs([...expandedFaqs, id]);
    }
  };
  
  return (
    <div className="bg-gray-100 min-h-screen py-12">
      <div className="container-custom">
        <h1 className="text-3xl font-bold mb-8">Emergency Assistance</h1>
        
        {/* Emergency Action Card */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="bg-red-600 text-white p-6 md:p-8">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mr-4">
                  <AlertTriangle size={24} className="text-white" />
                </div>
                <h2 className="text-2xl font-bold">Emergency Help</h2>
              </div>
              
              <p className="mb-6 text-red-100">
                If you're experiencing an emergency situation, help is available. Use the SOS button for immediate assistance.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mr-3">
                    <MapPin size={20} className="text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-red-100">Your current location</div>
                    <div className="font-medium">{userLocation.city}, {userLocation.country}</div>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mr-3">
                    <Phone size={20} className="text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-red-100">Local emergency number</div>
                    <div className="font-medium">{emergencyNumbers.general}</div>
                  </div>
                </div>
              </div>
              
              <button 
                onClick={() => setShowEmergencyModal(true)}
                className="mt-8 w-full bg-white text-red-600 hover:bg-red-50 font-bold py-3 px-6 rounded-lg flex items-center justify-center"
              >
                <AlertTriangle size={20} className="mr-2" />
                SOS EMERGENCY
              </button>
            </div>
            
            <div className="p-6 md:p-8">
              <h3 className="font-bold text-lg mb-4">Emergency Contact Numbers</h3>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-gray-100 pb-2">
                  <div className="font-medium">Ambulance</div>
                  <a 
                    href={`tel:${emergencyNumbers.ambulance}`} 
                    className="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-red-200 transition-colors flex items-center"
                  >
                    <Phone size={14} className="mr-1" />
                    {emergencyNumbers.ambulance}
                  </a>
                </div>
                
                <div className="flex justify-between items-center border-b border-gray-100 pb-2">
                  <div className="font-medium">Police</div>
                  <a 
                    href={`tel:${emergencyNumbers.police}`} 
                    className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-blue-200 transition-colors flex items-center"
                  >
                    <Phone size={14} className="mr-1" />
                    {emergencyNumbers.police}
                  </a>
                </div>
                
                <div className="flex justify-between items-center border-b border-gray-100 pb-2">
                  <div className="font-medium">Fire Department</div>
                  <a 
                    href={`tel:${emergencyNumbers.fire}`} 
                    className="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-orange-200 transition-colors flex items-center"
                  >
                    <Phone size={14} className="mr-1" />
                    {emergencyNumbers.fire}
                  </a>
                </div>
                
                <div className="flex justify-between items-center">
                  <div className="font-medium">Tourist Police</div>
                  <a 
                    href={`tel:${emergencyNumbers.touristPolice}`} 
                    className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium hover:bg-purple-200 transition-colors flex items-center"
                  >
                    <Phone size={14} className="mr-1" />
                    {emergencyNumbers.touristPolice}
                  </a>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t border-gray-200">
                <h3 className="font-medium mb-2">Your Emergency Contacts</h3>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mr-3 text-gray-500">
                        JD
                      </div>
                      <div>
                        <div className="font-medium">John Doe</div>
                        <div className="text-sm text-gray-500">Family</div>
                      </div>
                    </div>
                    <a 
                      href="tel:+1234567890" 
                      className="text-primary-600 hover:text-primary-700"
                    >
                      <Phone size={18} />
                    </a>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center mr-3 text-gray-500">
                        JG
                      </div>
                      <div>
                        <div className="font-medium">Jane Green</div>
                        <div className="text-sm text-gray-500">Friend</div>
                      </div>
                    </div>
                    <a 
                      href="tel:+1987654321" 
                      className="text-primary-600 hover:text-primary-700"
                    >
                      <Phone size={18} />
                    </a>
                  </div>
                </div>
                
                <button className="mt-3 w-full text-primary-600 border border-primary-600 py-2 px-4 rounded-lg hover:bg-primary-50 font-medium">
                  Add Emergency Contact
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Nearby Emergency Services */}
        <h2 className="text-2xl font-bold mb-4">Nearby Emergency Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {nearbyFacilities.map((facility) => (
            <div 
              key={facility.id} 
              className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div 
                className={`h-2 ${
                  facility.type === 'Hospital' ? 'bg-red-500' :
                  facility.type === 'Police' ? 'bg-blue-500' :
                  facility.type === 'Embassy' ? 'bg-purple-500' :
                  'bg-green-500'
                }`}
              ></div>
              <div className="p-4">
                <div className="flex items-start mb-3">
                  <div 
                    className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 flex-shrink-0 ${
                      facility.type === 'Hospital' ? 'bg-red-100 text-red-600' :
                      facility.type === 'Police' ? 'bg-blue-100 text-blue-600' :
                      facility.type === 'Embassy' ? 'bg-purple-100 text-purple-600' :
                      'bg-green-100 text-green-600'
                    }`}
                  >
                    {facility.type === 'Hospital' ? <Heart size={18} /> :
                     facility.type === 'Police' ? <Shield size={18} /> :
                     facility.type === 'Embassy' ? <Briefcase size={18} /> :
                     <Briefcase size={18} />}
                  </div>
                  <div>
                    <h3 className="font-bold">{facility.name}</h3>
                    <div className="text-sm text-gray-500">{facility.type}</div>
                  </div>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex items-start">
                    <MapPin size={14} className="mt-1 mr-2 text-gray-400" />
                    <div>
                      <div>{facility.address}</div>
                      <div className="text-primary-600 font-medium">{facility.distance} away</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Phone size={14} className="mr-2 text-gray-400" />
                    <a 
                      href={`tel:${facility.phone}`} 
                      className="text-primary-600 hover:underline"
                    >
                      {facility.phone}
                    </a>
                  </div>
                  
                  <div className="flex items-center">
                    <Info size={14} className="mr-2 text-gray-400" />
                    <span>{facility.open}</span>
                  </div>
                  
                  <div className="pt-2 flex flex-wrap gap-1">
                    {facility.languages.map((language, idx) => (
                      <span 
                        key={idx} 
                        className="bg-gray-100 text-gray-700 px-2 py-0.5 rounded-full text-xs"
                      >
                        {language}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div className="mt-4 flex justify-between">
                  <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
                    View Details
                  </button>
                  <button className="bg-primary-600 text-white px-3 py-1 rounded-lg hover:bg-primary-700 text-sm font-medium">
                    Get Directions
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Emergency Tips */}
        <h2 className="text-2xl font-bold mb-4">Emergency Tips</h2>
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="p-4 sm:p-6">
            <div className="space-y-4">
              {emergencyTips.map((tip) => (
                <div 
                  key={tip.id} 
                  className="border border-gray-200 rounded-lg overflow-hidden"
                >
                  <button 
                    className="w-full flex justify-between items-center p-4 text-left font-medium"
                    onClick={() => toggleFaq(tip.id)}
                  >
                    {tip.title}
                    {expandedFaqs.includes(tip.id) ? 
                      <ChevronUp size={18} className="text-gray-500" /> : 
                      <ChevronDown size={18} className="text-gray-500" />
                    }
                  </button>
                  
                  {expandedFaqs.includes(tip.id) && (
                    <div className="p-4 pt-0 border-t border-gray-200 text-gray-600">
                      {tip.content}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Offline Access Info */}
        <div className="bg-primary-50 border border-primary-200 rounded-xl p-6 mb-8">
          <div className="flex items-start">
            <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
              <Wifi size={24} className="text-primary-600" />
            </div>
            <div>
              <h3 className="font-bold text-lg mb-2">Offline Emergency Access</h3>
              <p className="text-gray-700 mb-4">
                Download emergency information for your current location to access it even without an internet connection. This includes local emergency numbers, nearby facilities, and important phrases in the local language.
              </p>
              <button className="bg-primary-600 text-white py-2 px-4 rounded-lg hover:bg-primary-700 flex items-center">
                <svg className="mr-2 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Download Emergency Info for Thailand
              </button>
            </div>
          </div>
        </div>
        
        {/* Emergency Phrases */}
        <h2 className="text-2xl font-bold mb-4">Emergency Phrases in Thai</h2>
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="p-4 sm:p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border border-gray-200 rounded-lg p-3">
                <div className="text-sm text-gray-500 mb-1">Help!</div>
                <div className="font-medium mb-1">Chuay duay! (ช่วยด้วย!)</div>
                <button className="text-xs text-primary-600 hover:text-primary-700">
                  Play Audio
                </button>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-3">
                <div className="text-sm text-gray-500 mb-1">I need a doctor</div>
                <div className="font-medium mb-1">Chan tong karn moh (ฉันต้องการหมอ)</div>
                <button className="text-xs text-primary-600 hover:text-primary-700">
                  Play Audio
                </button>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-3">
                <div className="text-sm text-gray-500 mb-1">Call an ambulance</div>
                <div className="font-medium mb-1">Preh-arh rot paya-ban (เรียกรถพยาบาล)</div>
                <button className="text-xs text-primary-600 hover:text-primary-700">
                  Play Audio
                </button>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-3">
                <div className="text-sm text-gray-500 mb-1">I've been robbed</div>
                <div className="font-medium mb-1">Chan dohn plon (ฉันโดนปล้น)</div>
                <button className="text-xs text-primary-600 hover:text-primary-700">
                  Play Audio
                </button>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-3">
                <div className="text-sm text-gray-500 mb-1">I'm lost</div>
                <div className="font-medium mb-1">Chan long tang (ฉันหลงทาง)</div>
                <button className="text-xs text-primary-600 hover:text-primary-700">
                  Play Audio
                </button>
              </div>
              
              <div className="border border-gray-200 rounded-lg p-3">
                <div className="text-sm text-gray-500 mb-1">I'm allergic to</div>
                <div className="font-medium mb-1">Chan pae (ฉันแพ้...)</div>
                <button className="text-xs text-primary-600 hover:text-primary-700">
                  Play Audio
                </button>
              </div>
            </div>
            
            <button className="mt-4 text-primary-600 hover:text-primary-700 font-medium text-sm">
              View All Emergency Phrases
            </button>
          </div>
        </div>
      </div>
      
      {/* Emergency Modal */}
      {showEmergencyModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl max-w-md w-full overflow-hidden mx-4">
            <div className="bg-red-600 p-6 text-white relative">
              <button 
                onClick={() => setShowEmergencyModal(false)}
                className="absolute top-4 right-4 text-white hover:text-red-200"
              >
                <X size={24} />
              </button>
              
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mr-4">
                  <AlertTriangle size={24} className="text-white" />
                </div>
                <h2 className="text-2xl font-bold">Emergency Assistance</h2>
              </div>
              
              <p className="text-red-100">
                Select the type of emergency you're experiencing:
              </p>
            </div>
            
            <div className="p-6">
              <div className="space-y-3">
                <a 
                  href={`tel:${emergencyNumbers.ambulance}`} 
                  className="w-full flex items-center justify-between p-4 border border-red-200 rounded-lg bg-red-50 text-red-700 hover:bg-red-100"
                >
                  <div className="flex items-center">
                    <Heart size={20} className="mr-3" />
                    <span className="font-medium">Medical Emergency</span>
                  </div>
                  <Phone size={18} />
                </a>
                
                <a 
                  href={`tel:${emergencyNumbers.police}`} 
                  className="w-full flex items-center justify-between p-4 border border-blue-200 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100"
                >
                  <div className="flex items-center">
                    <Shield size={20} className="mr-3" />
                    <span className="font-medium">Police Assistance</span>
                  </div>
                  <Phone size={18} />
                </a>
                
                <a 
                  href={`tel:${emergencyNumbers.fire}`} 
                  className="w-full flex items-center justify-between p-4 border border-orange-200 rounded-lg bg-orange-50 text-orange-700 hover:bg-orange-100"
                >
                  <div className="flex items-center">
                    <AlertTriangle size={20} className="mr-3" />
                    <span className="font-medium">Fire Emergency</span>
                  </div>
                  <Phone size={18} />
                </a>
                
                <a 
                  href={`tel:${emergencyNumbers.touristPolice}`} 
                  className="w-full flex items-center justify-between p-4 border border-purple-200 rounded-lg bg-purple-50 text-purple-700 hover:bg-purple-100"
                >
                  <div className="flex items-center">
                    <Briefcase size={20} className="mr-3" />
                    <span className="font-medium">Tourist Police</span>
                  </div>
                  <Phone size={18} />
                </a>
              </div>
              
              <div className="mt-6 pt-6 border-t border-gray-200 text-center">
                <p className="text-gray-600 text-sm mb-2">Your current location</p>
                <p className="font-medium">{userLocation.city}, {userLocation.country}</p>
                <p className="text-gray-500 text-xs mt-1">
                  {userLocation.coordinates.latitude.toFixed(4)}, {userLocation.coordinates.longitude.toFixed(4)}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Emergency;