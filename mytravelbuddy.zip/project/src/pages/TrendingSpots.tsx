import React, { useState } from 'react';
import { Heart, Share2, Instagram, Facebook, MapPin, ExternalLink } from 'lucide-react';

const TrendingSpots: React.FC = () => {
  const [activeTab, setActiveTab] = useState('instagram');
  
  // Mock data for trending spots from social media
  const instagramTrending = [
    {
      id: 1,
      location: 'Santorini, Greece',
      image: 'https://images.pexels.com/photos/1010657/pexels-photo-1010657.jpeg',
      likes: 58742,
      posts: 2435,
      hashtags: ['#santoriniviews', '#greekislands', '#travelphotography'],
      description: 'Famous for its stunning sunsets, blue-domed churches, and whitewashed buildings perched on cliffs above the Aegean Sea.',
    },
    {
      id: 2,
      location: 'Bali, Indonesia',
      image: 'https://images.pexels.com/photos/2166559/pexels-photo-2166559.jpeg',
      likes: 45123,
      posts: 1897,
      hashtags: ['#balilife', '#islandvibes', '#tropicalparadise'],
      description: 'A tropical paradise known for its lush rice terraces, beautiful beaches, spiritual temples, and vibrant culture.',
    },
    {
      id: 3,
      location: 'Tulum, Mexico',
      image: 'https://images.pexels.com/photos/9482125/pexels-photo-9482125.jpeg',
      likes: 36589,
      posts: 1654,
      hashtags: ['#tulumbeach', '#mexicotravel', '#caribbeanvibes'],
      description: 'Bohemian beach town featuring ancient Mayan ruins overlooking turquoise waters and trendy eco-friendly resorts.',
    },
    {
      id: 4,
      location: 'Kyoto, Japan',
      image: 'https://images.pexels.com/photos/1440476/pexels-photo-1440476.jpeg',
      likes: 32456,
      posts: 1432,
      hashtags: ['#kyotojapan', '#cherryblossom', '#japanesearchitecture'],
      description: 'Historic city known for its classical Buddhist temples, gardens, imperial palaces, Shinto shrines and traditional wooden houses.',
    },
    {
      id: 5,
      location: 'Cappadocia, Turkey',
      image: 'https://images.pexels.com/photos/2563681/pexels-photo-2563681.jpeg',
      likes: 29875,
      posts: 1289,
      hashtags: ['#hotairballoon', '#cappadocia', '#turkeytravel'],
      description: 'Famous for its fairytale landscape with distinctive "fairy chimneys" and hot air balloon rides offering panoramic views.',
    },
    {
      id: 6,
      location: 'Amalfi Coast, Italy',
      image: 'https://images.pexels.com/photos/5822228/pexels-photo-5822228.jpeg',
      likes: 27651,
      posts: 1198,
      hashtags: ['#amalficoast', '#italiancoast', '#mediterraneanlife'],
      description: 'Dramatic coastline featuring steep cliffs, pastel-colored fishing villages, and terraced vineyards overlooking the Mediterranean.',
    },
  ];
  
  const facebookTrending = [
    {
      id: 1,
      location: 'Lisbon, Portugal',
      image: 'https://images.pexels.com/photos/1519088/pexels-photo-1519088.jpeg',
      likes: 42356,
      posts: 1876,
      hashtags: ['#lisbonlife', '#portugal', '#traveleurope'],
      description: 'Hilly coastal capital featuring ancient ruins, colorful buildings, and a vibrant food scene with traditional pastries.',
    },
    {
      id: 2,
      location: 'Marrakech, Morocco',
      image: 'https://images.pexels.com/photos/3689859/pexels-photo-3689859.jpeg',
      likes: 38921,
      posts: 1654,
      hashtags: ['#marrakech', '#moroccotravel', '#medina'],
      description: 'Ancient walled medina city with maze-like alleys, vibrant souks, and stunning palaces showcasing Islamic architecture.',
    },
    {
      id: 3,
      location: 'New Zealand',
      image: 'https://images.pexels.com/photos/724949/pexels-photo-724949.jpeg',
      likes: 36789,
      posts: 1583,
      hashtags: ['#newzealand', '#naturelovers', '#adventuretime'],
      description: 'Land of dramatic landscapes, from volcanic mountains to pristine beaches, offering endless outdoor adventure opportunities.',
    },
    {
      id: 4,
      location: 'Prague, Czech Republic',
      image: 'https://images.pexels.com/photos/1559699/pexels-photo-1559699.jpeg',
      likes: 34521,
      posts: 1499,
      hashtags: ['#prague', '#charlesbridge', '#czechrepublic'],
      description: 'Fairytale city featuring baroque buildings, Gothic churches, a medieval astronomical clock, and the iconic Charles Bridge.',
    },
    {
      id: 5,
      location: 'Kenya Safari',
      image: 'https://images.pexels.com/photos/1532771/pexels-photo-1532771.jpeg',
      likes: 31245,
      posts: 1367,
      hashtags: ['#kenyasafari', '#africawildlife', '#maasaimara'],
      description: 'Wildlife adventure featuring the Big Five animals, the Great Migration, and stunning savanna landscapes.',
    },
    {
      id: 6,
      location: 'Vancouver, Canada',
      image: 'https://images.pexels.com/photos/63332/science-world-false-creek-vancouver-british-columbia-63332.jpeg',
      likes: 28975,
      posts: 1265,
      hashtags: ['#vancouver', '#explorebc', '#canadatravel'],
      description: 'Coastal seaport city surrounded by mountains, offering a perfect blend of urban amenities and outdoor adventures.',
    },
  ];
  
  const getTrendingData = () => {
    return activeTab === 'instagram' ? instagramTrending : facebookTrending;
  };
  
  return (
    <div className="bg-gray-100 min-h-screen py-12">
      <div className="container-custom">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Trending Travel Destinations</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover the most popular destinations shared across social media platforms
          </p>
        </div>
        
        {/* Tabs */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex rounded-md shadow-sm">
            <button
              onClick={() => setActiveTab('instagram')}
              className={`flex items-center px-4 py-2 text-sm font-medium rounded-l-lg ${
                activeTab === 'instagram'
                  ? 'bg-primary-500 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Instagram size={18} className="mr-2" />
              Instagram
            </button>
            <button
              onClick={() => setActiveTab('facebook')}
              className={`flex items-center px-4 py-2 text-sm font-medium rounded-r-lg ${
                activeTab === 'facebook'
                  ? 'bg-primary-500 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Facebook size={18} className="mr-2" />
              Facebook
            </button>
          </div>
        </div>
        
        {/* Trending Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {getTrendingData().map((spot) => (
            <div key={spot.id} className="card overflow-hidden group">
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={spot.image} 
                  alt={spot.location} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center text-white mb-1">
                    <MapPin size={16} className="mr-1" />
                    <span className="font-medium">{spot.location}</span>
                  </div>
                  <div className="flex space-x-2">
                    {spot.hashtags.map((tag, idx) => (
                      <span 
                        key={idx} 
                        className="text-xs text-white/90 bg-black/30 backdrop-blur-sm px-2 py-1 rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="absolute top-4 right-4 flex space-x-2">
                  <button className="bg-white/20 backdrop-blur-sm p-2 rounded-full text-white hover:bg-white/30 transition-colors">
                    <Heart size={16} />
                  </button>
                  <button className="bg-white/20 backdrop-blur-sm p-2 rounded-full text-white hover:bg-white/30 transition-colors">
                    <Share2 size={16} />
                  </button>
                </div>
              </div>
              <div className="p-5">
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center text-gray-500 text-sm">
                    <span className="mr-3">
                      <Heart size={14} className="inline mr-1" />
                      {spot.likes.toLocaleString()}
                    </span>
                    <span>
                      <span className="inline mr-1">#</span>
                      {spot.posts.toLocaleString()} posts
                    </span>
                  </div>
                  <div>
                    <span className={`inline-block w-2 h-2 rounded-full mr-1 ${
                      activeTab === 'instagram' ? 'bg-gradient-to-tr from-purple-500 to-pink-500' : 'bg-blue-600'
                    }`}></span>
                    <span className="text-xs text-gray-500">via {activeTab}</span>
                  </div>
                </div>
                <p className="text-gray-700 mb-3">{spot.description}</p>
                <a 
                  href="#" 
                  className="inline-flex items-center text-sm font-medium text-primary-600 hover:text-primary-700"
                >
                  Explore destination 
                  <ExternalLink size={14} className="ml-1" />
                </a>
              </div>
            </div>
          ))}
        </div>
        
        {/* Insight Section */}
        <div className="mt-16 bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-6 md:p-8">
            <h2 className="text-2xl font-bold mb-4">Social Media Travel Trends</h2>
            <p className="text-gray-700 mb-6">
              Our data shows that travelers are increasingly seeking photogenic destinations that offer unique cultural experiences. Here are the key trends:
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-primary-600 mb-2">78%</div>
                <p className="text-gray-600">of travelers choose destinations based on social media influence</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-primary-600 mb-2">Top 3</div>
                <p className="text-gray-600">most-searched locations include Bali, Santorini, and Tulum</p>
              </div>
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-primary-600 mb-2">65%</div>
                <p className="text-gray-600">increase in travel to less-known destinations featured by influencers</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Call to Action */}
        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold mb-4">Ready to explore these trending destinations?</h2>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
            Let us help you plan the perfect trip to these incredible locations. Our personalized itineraries make travel planning simple and stress-free.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/itinerary-builder" className="btn btn-primary">
              Create Your Itinerary
            </a>
            <a href="/booking" className="btn border border-gray-300 hover:bg-gray-50">
              Browse Travel Packages
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrendingSpots;