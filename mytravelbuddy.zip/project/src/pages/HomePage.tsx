import React from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, TrendingUp, Map, Compass, Plane, Leaf, Camera, Users, Route } from 'lucide-react';

const HomePage: React.FC = () => {
  // Mock featured destinations data
  const featuredDestinations = [
    {
      id: 1,
      name: 'Bali, Indonesia',
      image: 'https://images.pexels.com/photos/2166553/pexels-photo-2166553.jpeg',
      description: 'Explore temples, beaches, and lush rice terraces',
      rating: 4.8,
      price: '$1,200'
    },
    {
      id: 2,
      name: 'Santorini, Greece',
      image: 'https://images.pexels.com/photos/1010657/pexels-photo-1010657.jpeg',
      description: 'White-washed buildings with stunning sea views',
      rating: 4.9,
      price: '$1,800'
    },
    {
      id: 3,
      name: 'Kyoto, Japan',
      image: 'https://images.pexels.com/photos/5169056/pexels-photo-5169056.jpeg',
      description: 'Ancient temples, gardens, and traditional culture',
      rating: 4.7,
      price: '$1,500'
    },
    {
      id: 4,
      name: 'Machu Picchu, Peru',
      image: 'https://images.pexels.com/photos/2929906/pexels-photo-2929906.jpeg',
      description: 'Inca ruins set against stunning mountain backdrops',
      rating: 4.9,
      price: '$1,700'
    }
  ];

  // Mock trending experiences
  const trendingExperiences = [
    {
      id: 1,
      title: 'Desert Safari Adventure',
      image: 'https://images.pexels.com/photos/1497585/pexels-photo-1497585.jpeg',
      location: 'Dubai, UAE',
      category: 'Adventure'
    },
    {
      id: 2,
      title: 'Cooking Class in Tuscany',
      image: 'https://images.pexels.com/photos/3298687/pexels-photo-3298687.jpeg',
      location: 'Florence, Italy',
      category: 'Culinary'
    },
    {
      id: 3,
      title: 'Northern Lights Tour',
      image: 'https://images.pexels.com/photos/624015/pexels-photo-624015.jpeg',
      location: 'Reykjavik, Iceland',
      category: 'Nature'
    }
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-gray-900 text-white">
        <div className="absolute inset-0 overflow-hidden">
          <img 
            src="https://images.pexels.com/photos/1268855/pexels-photo-1268855.jpeg" 
            alt="Travel destination" 
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-gray-900/80 to-transparent"></div>
        </div>
        
        <div className="container-custom relative z-10 py-24 md:py-32">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
              Your Perfect Trip Is Just A Few Clicks Away
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200">
              Personalized travel planning with AI-powered recommendations based on your preferences.
            </p>
            
            <div className="bg-white p-4 rounded-lg shadow-lg w-full">
              <div className="flex flex-col md:flex-row gap-3">
                <div className="flex-1 relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MapPin className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder="Where do you want to go?"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                  />
                </div>
                
                <div className="flex flex-col md:flex-row gap-3">
                  <input
                    type="date"
                    className="block w-full py-2 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                  />
                  <input
                    type="date"
                    className="block w-full py-2 px-3 border border-gray-300 rounded-md focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                  />
                </div>
                
                <button className="bg-primary-500 text-white py-2 px-6 rounded-md hover:bg-primary-600 transition-colors flex items-center justify-center">
                  <Search className="h-5 w-5 mr-1" />
                  <span>Search</span>
                </button>
              </div>
            </div>
            
            <div className="mt-8 flex flex-wrap gap-4">
              <Link to="/itinerary-builder" className="bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white py-2 px-4 rounded-full transition-colors flex items-center">
                <Map className="h-4 w-4 mr-2" />
                <span>Itinerary Builder</span>
              </Link>
              <Link to="/trending" className="bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white py-2 px-4 rounded-full transition-colors flex items-center">
                <TrendingUp className="h-4 w-4 mr-2" />
                <span>Trending Destinations</span>
              </Link>
              <Link to="/hidden-gems" className="bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white py-2 px-4 rounded-full transition-colors flex items-center">
                <Compass className="h-4 w-4 mr-2" />
                <span>Hidden Gems</span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Reimagine How You Travel</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our AI-powered platform personalizes your travel experience with smart features designed for modern explorers.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Feature 1 */}
            <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mb-4">
                <Map className="h-6 w-6 text-primary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Personalized Itineraries</h3>
              <p className="text-gray-600">
                Custom travel plans based on your preferences, budget, and travel style.
              </p>
            </div>
            
            {/* Feature 2 */}
            <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-secondary-100 rounded-full flex items-center justify-center mb-4">
                <Compass className="h-6 w-6 text-secondary-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Hidden Gems</h3>
              <p className="text-gray-600">
                Discover off-the-beaten-path locations that most tourists never find.
              </p>
            </div>
            
            {/* Feature 3 */}
            <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-accent-100 rounded-full flex items-center justify-center mb-4">
                <Plane className="h-6 w-6 text-accent-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Smart Booking</h3>
              <p className="text-gray-600">
                Book flights, hotels, and activities in one place with smart recommendations.
              </p>
            </div>
            
            {/* Feature 4 */}
            <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <Leaf className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Eco-Friendly Options</h3>
              <p className="text-gray-600">
                Sustainable travel choices for environmentally conscious travelers.
              </p>
            </div>
          </div>
          
          <div className="mt-12 text-center">
            <Link to="/itinerary-builder" className="btn btn-primary inline-flex items-center">
              <Map className="mr-2 h-5 w-5" />
              Start Planning Your Trip
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Destinations */}
      <section className="py-16">
        <div className="container-custom">
          <div className="flex justify-between items-end mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-2">Featured Destinations</h2>
              <p className="text-gray-600">Popular places loved by our community</p>
            </div>
            <Link to="/trending" className="text-primary-600 hover:text-primary-700 font-medium flex items-center">
              View all
              <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredDestinations.map((destination) => (
              <div key={destination.id} className="card group">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={destination.image} 
                    alt={destination.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-0 left-0 m-3">
                    <div className="bg-white/90 backdrop-blur-sm text-sm font-medium px-2 py-1 rounded flex items-center">
                      <svg className="w-4 h-4 text-yellow-400 mr-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                      {destination.rating}
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-1">{destination.name}</h3>
                  <p className="text-gray-600 text-sm mb-3">{destination.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-primary-600 font-bold">{destination.price}</span>
                    <Link 
                      to="/booking" 
                      className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center"
                    >
                      Explore
                      <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trending Experiences */}
      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="flex justify-between items-end mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-2">Trending Experiences</h2>
              <p className="text-gray-600">Popular activities at top destinations</p>
            </div>
            <Link to="/trending" className="text-primary-600 hover:text-primary-700 font-medium flex items-center">
              View all
              <svg className="ml-2 w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {trendingExperiences.map((experience) => (
              <div key={experience.id} className="card group">
                <div className="relative h-64 overflow-hidden">
                  <img 
                    src={experience.image} 
                    alt={experience.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-0 right-0 m-3">
                    <div className="bg-accent-500 text-white text-xs font-medium px-2 py-1 rounded">
                      {experience.category}
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-center text-gray-500 text-sm mb-2">
                    <MapPin size={14} className="mr-1" />
                    {experience.location}
                  </div>
                  <h3 className="font-bold text-lg mb-3">{experience.title}</h3>
                  <Link 
                    to="/booking" 
                    className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center"
                  >
                    Book this experience
                    <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-primary-600 text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to start your adventure?</h2>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto text-primary-100">
            Join thousands of travelers who plan better trips with MyTravelBuddy
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/itinerary-builder" className="btn bg-white text-primary-600 hover:bg-primary-50">
              Create Your Itinerary
            </Link>
            <Link to="/community" className="btn border border-white hover:bg-white/10">
              Join Our Community
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;