import React, { useState } from 'react';
import { MessageSquare, Heart, Bookmark, Share2, Search, Users, Filter, ChevronDown, PlusCircle, User, Calendar, MapPin, SortDesc, Star } from 'lucide-react';

const Community: React.FC = () => {
  const [activeTab, setActiveTab] = useState('discussions');
  const [showNewPostForm, setShowNewPostForm] = useState(false);
  
  // Mock user data
  const currentUser = {
    name: 'Sarah Johnson',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
    location: 'San Francisco, CA'
  };
  
  // Mock forum discussions data
  const discussions = [
    {
      id: 1,
      user: {
        name: 'Michael Chen',
        avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg',
        location: 'Tokyo, Japan'
      },
      title: 'Best time to visit Japan for cherry blossoms?',
      content: 'I\'m planning a trip to Japan specifically to see the cherry blossoms. What\'s the optimal time to visit, and which cities/areas would you recommend? Any tips for avoiding the biggest crowds?',
      tags: ['Japan', 'Cherry Blossoms', 'Spring Travel'],
      likes: 42,
      comments: 18,
      time: '2 hours ago'
    },
    {
      id: 2,
      user: {
        name: 'Emma Rodriguez',
        avatar: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg',
        location: 'Barcelona, Spain'
      },
      title: 'Solo female traveler safety tips for South America',
      content: 'I\'m planning my first solo trip to South America (Peru, Bolivia, and Chile) and would love some safety advice from other women who have traveled there alone. Any particular cities or areas to avoid? Tips for staying safe while still having an amazing adventure?',
      tags: ['Solo Travel', 'Safety', 'South America', 'Female Travelers'],
      likes: 97,
      comments: 36,
      time: '5 hours ago'
    },
    {
      id: 3,
      user: {
        name: 'David Wilson',
        avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
        location: 'Sydney, Australia'
      },
      title: 'Camera equipment for wildlife photography in Africa',
      content: 'I\'m going on a safari in Tanzania and Kenya next month. What camera gear would you recommend for wildlife photography? I currently have a Canon 80D with a 70-200mm lens, but wondering if I need something with more reach.',
      tags: ['Photography', 'Safari', 'Africa', 'Wildlife'],
      likes: 53,
      comments: 24,
      time: '1 day ago'
    },
    {
      id: 4,
      user: {
        name: 'Priya Patel',
        avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg',
        location: 'New Delhi, India'
      },
      title: 'Traveling with dietary restrictions in Southeast Asia',
      content: 'I\'m a vegetarian with a gluten allergy planning a 3-week trip to Thailand, Vietnam, and Cambodia. I\'m worried about finding suitable food options. Has anyone traveled there with similar dietary restrictions? Any recommendations for communicating my needs or particular restaurants that were accommodating?',
      tags: ['Food', 'Dietary Restrictions', 'Southeast Asia', 'Vegetarian'],
      likes: 38,
      comments: 29,
      time: '2 days ago'
    },
  ];
  
  // Mock community reviews data
  const reviews = [
    {
      id: 1,
      user: {
        name: 'James Mitchell',
        avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg',
        location: 'London, UK'
      },
      place: 'Riad Yasmine',
      location: 'Marrakech, Morocco',
      rating: 4.8,
      date: 'June 15, 2023',
      content: 'This hidden gem in the heart of the Marrakech medina exceeded all expectations. The iconic green pool is even more beautiful in person, and the rooftop terrace offers stunning views of the city. The staff went above and beyond to make our stay memorable, arranging local guides and suggesting authentic restaurants away from the tourist traps.',
      images: [
        'https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg',
        'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg'
      ],
      likes: 64,
      comments: 12
    },
    {
      id: 2,
      user: {
        name: 'Olivia Kim',
        avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
        location: 'Seoul, South Korea'
      },
      place: 'Halong Bay Overnight Cruise',
      location: 'Halong Bay, Vietnam',
      rating: 4.5,
      date: 'May 23, 2023',
      content: 'The overnight cruise in Halong Bay was the highlight of our Vietnam trip. Waking up surrounded by the limestone karsts shrouded in morning mist was magical. The kayaking excursion to hidden caves and beaches was well organized. Food onboard was excellent with plenty of seafood options. My only complaint is that some areas of the bay were quite crowded with other tourist boats.',
      images: [
        'https://images.pexels.com/photos/2406428/pexels-photo-2406428.jpeg'
      ],
      likes: 48,
      comments: 9
    },
    {
      id: 3,
      user: {
        name: 'Carlos Mendez',
        avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg',
        location: 'Mexico City, Mexico'
      },
      place: 'Cenote Dos Ojos',
      location: 'Tulum, Mexico',
      rating: 5.0,
      date: 'April 10, 2023',
      content: 'One of the most incredible natural swimming spots I\'ve ever experienced! The crystal clear water is refreshingly cool and perfect for escaping the Yucatan heat. If you\'re a strong swimmer, don\'t miss exploring the cave system with a guide. Arrive early (around 9am) to beat the tour groups. Facilities are basic but clean, with changing rooms and storage lockers available.',
      images: [
        'https://images.pexels.com/photos/3037145/pexels-photo-3037145.jpeg',
        'https://images.pexels.com/photos/5116686/pexels-photo-5116686.jpeg'
      ],
      likes: 93,
      comments: 21
    },
  ];
  
  // Mock shared photos data
  const photos = [
    {
      id: 1,
      user: {
        name: 'Thomas Wright',
        avatar: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg'
      },
      image: 'https://images.pexels.com/photos/3225529/pexels-photo-3225529.jpeg',
      location: 'Santorini, Greece',
      likes: 278,
      comments: 24
    },
    {
      id: 2,
      user: {
        name: 'Sophia Lee',
        avatar: 'https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg'
      },
      image: 'https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg',
      location: 'Bali, Indonesia',
      likes: 345,
      comments: 31
    },
    {
      id: 3,
      user: {
        name: 'Mohammed Al-Fayed',
        avatar: 'https://images.pexels.com/photos/1080213/pexels-photo-1080213.jpeg'
      },
      image: 'https://images.pexels.com/photos/1591373/pexels-photo-1591373.jpeg',
      location: 'Wadi Rum, Jordan',
      likes: 189,
      comments: 17
    },
    {
      id: 4,
      user: {
        name: 'Isabella Rossi',
        avatar: 'https://images.pexels.com/photos/1197132/pexels-photo-1197132.jpeg'
      },
      image: 'https://images.pexels.com/photos/2835562/pexels-photo-2835562.jpeg',
      location: 'Cinque Terre, Italy',
      likes: 412,
      comments: 39
    },
    {
      id: 5,
      user: {
        name: 'Jackson Taylor',
        avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg'
      },
      image: 'https://images.pexels.com/photos/3217911/pexels-photo-3217911.jpeg',
      location: 'Grand Canyon, USA',
      likes: 267,
      comments: 22
    },
    {
      id: 6,
      user: {
        name: 'Elena Petrova',
        avatar: 'https://images.pexels.com/photos/712513/pexels-photo-712513.jpeg'
      },
      image: 'https://images.pexels.com/photos/2253611/pexels-photo-2253611.jpeg',
      location: 'St. Petersburg, Russia',
      likes: 201,
      comments: 19
    },
    {
      id: 7,
      user: {
        name: 'Raj Singh',
        avatar: 'https://images.pexels.com/photos/91227/pexels-photo-91227.jpeg'
      },
      image: 'https://images.pexels.com/photos/3581368/pexels-photo-3581368.jpeg',
      location: 'Taj Mahal, India',
      likes: 354,
      comments: 28
    },
    {
      id: 8,
      user: {
        name: 'Chloe Williams',
        avatar: 'https://images.pexels.com/photos/1542085/pexels-photo-1542085.jpeg'
      },
      image: 'https://images.pexels.com/photos/3155666/pexels-photo-3155666.jpeg',
      location: 'Northern Lights, Iceland',
      likes: 429,
      comments: 41
    },
  ];
  
  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="container-custom">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold mb-4">Travel Community</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Connect with fellow travelers, share experiences, and get inspired for your next adventure
          </p>
        </div>
        
        {/* Community Dashboard */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4">
            <div className="p-6 flex flex-col items-center justify-center bg-primary-50 text-primary-700">
              <Users size={36} className="mb-2" />
              <div className="text-2xl font-bold">24,578</div>
              <div className="text-sm">Community Members</div>
            </div>
            <div className="p-6 flex flex-col items-center justify-center">
              <MessageSquare size={36} className="mb-2 text-blue-500" />
              <div className="text-2xl font-bold">8,942</div>
              <div className="text-sm">Discussions</div>
            </div>
            <div className="p-6 flex flex-col items-center justify-center">
              <Star size={36} className="mb-2 text-yellow-500" />
              <div className="text-2xl font-bold">15,320</div>
              <div className="text-sm">Reviews</div>
            </div>
            <div className="p-6 flex flex-col items-center justify-center">
              <MapPin size={36} className="mb-2 text-red-500" />
              <div className="text-2xl font-bold">192</div>
              <div className="text-sm">Countries Covered</div>
            </div>
          </div>
        </div>
        
        {/* Community Content */}
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Content */}
          <div className="w-full lg:w-3/4">
            {/* Tabs and Controls */}
            <div className="bg-white rounded-xl shadow-md mb-6">
              <div className="border-b border-gray-200">
                <div className="flex flex-wrap">
                  <button
                    onClick={() => setActiveTab('discussions')}
                    className={`px-4 py-3 font-medium text-sm ${
                      activeTab === 'discussions'
                        ? 'border-b-2 border-primary-500 text-primary-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Discussions
                  </button>
                  <button
                    onClick={() => setActiveTab('reviews')}
                    className={`px-4 py-3 font-medium text-sm ${
                      activeTab === 'reviews'
                        ? 'border-b-2 border-primary-500 text-primary-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Travel Reviews
                  </button>
                  <button
                    onClick={() => setActiveTab('photos')}
                    className={`px-4 py-3 font-medium text-sm ${
                      activeTab === 'photos'
                        ? 'border-b-2 border-primary-500 text-primary-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    Photos
                  </button>
                </div>
              </div>
              
              <div className="p-4 flex justify-between items-center">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search size={16} className="text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder={`Search in ${activeTab}...`}
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  />
                </div>
                
                <div className="flex space-x-3">
                  <button className="flex items-center space-x-1 text-sm text-gray-600 px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <Filter size={16} />
                    <span>Filter</span>
                  </button>
                  <button className="flex items-center space-x-1 text-sm text-gray-600 px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <SortDesc size={16} />
                    <span>Sort</span>
                    <ChevronDown size={16} />
                  </button>
                  <button 
                    onClick={() => setShowNewPostForm(!showNewPostForm)}
                    className="flex items-center space-x-1 text-sm text-white px-3 py-2 bg-primary-600 rounded-lg hover:bg-primary-700"
                  >
                    <PlusCircle size={16} />
                    <span>New Post</span>
                  </button>
                </div>
              </div>
            </div>
            
            {/* New Post Form */}
            {showNewPostForm && (
              <div className="bg-white rounded-xl shadow-md mb-6 p-6">
                <div className="flex items-center mb-4">
                  <img 
                    src={currentUser.avatar} 
                    alt={currentUser.name} 
                    className="w-10 h-10 rounded-full mr-3"
                  />
                  <div>
                    <div className="font-medium">{currentUser.name}</div>
                    <div className="text-gray-500 text-sm">{currentUser.location}</div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <input
                    type="text"
                    placeholder="Title"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  />
                  
                  <textarea
                    placeholder="Share your travel experiences, ask questions, or start a discussion..."
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  ></textarea>
                  
                  <div className="flex items-center space-x-2 text-gray-600 text-sm">
                    <button className="flex items-center space-x-1 px-3 py-1 border border-gray-300 rounded-md hover:bg-gray-50">
                      <MapPin size={16} />
                      <span>Add Location</span>
                    </button>
                    <button className="flex items-center space-x-1 px-3 py-1 border border-gray-300 rounded-md hover:bg-gray-50">
                      <span>Add Photo</span>
                    </button>
                    <button className="flex items-center space-x-1 px-3 py-1 border border-gray-300 rounded-md hover:bg-gray-50">
                      <span>Add Tags</span>
                    </button>
                  </div>
                  
                  <div className="flex justify-end space-x-3">
                    <button 
                      onClick={() => setShowNewPostForm(false)}
                      className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                    >
                      Cancel
                    </button>
                    <button className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700">
                      Post
                    </button>
                  </div>
                </div>
              </div>
            )}
            
            {/* Discussions Tab Content */}
            {activeTab === 'discussions' && (
              <div className="space-y-6">
                {discussions.map((discussion) => (
                  <div key={discussion.id} className="bg-white rounded-xl shadow-md overflow-hidden">
                    <div className="p-6">
                      <div className="flex items-start">
                        <img 
                          src={discussion.user.avatar} 
                          alt={discussion.user.name} 
                          className="w-10 h-10 rounded-full mr-4"
                        />
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <div className="font-medium">{discussion.user.name}</div>
                              <div className="text-gray-500 text-sm flex items-center">
                                <MapPin size={12} className="mr-1" />
                                {discussion.user.location} • {discussion.time}
                              </div>
                            </div>
                          </div>
                          
                          <h3 className="font-bold text-lg mt-3 mb-2">{discussion.title}</h3>
                          <p className="text-gray-700 mb-4">{discussion.content}</p>
                          
                          <div className="flex flex-wrap gap-2 mb-4">
                            {discussion.tags.map((tag, idx) => (
                              <span 
                                key={idx} 
                                className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs font-medium"
                              >
                                #{tag}
                              </span>
                            ))}
                          </div>
                          
                          <div className="flex items-center justify-between text-gray-500 text-sm">
                            <div className="flex items-center space-x-4">
                              <button className="flex items-center hover:text-red-500">
                                <Heart size={16} className="mr-1" />
                                <span>{discussion.likes}</span>
                              </button>
                              <button className="flex items-center hover:text-primary-500">
                                <MessageSquare size={16} className="mr-1" />
                                <span>{discussion.comments}</span>
                              </button>
                            </div>
                            <div className="flex items-center space-x-3">
                              <button className="hover:text-primary-500">
                                <Bookmark size={16} />
                              </button>
                              <button className="hover:text-primary-500">
                                <Share2 size={16} />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Reviews Tab Content */}
            {activeTab === 'reviews' && (
              <div className="space-y-6">
                {reviews.map((review) => (
                  <div key={review.id} className="bg-white rounded-xl shadow-md overflow-hidden">
                    <div className="p-6">
                      <div className="flex items-start">
                        <img 
                          src={review.user.avatar} 
                          alt={review.user.name} 
                          className="w-10 h-10 rounded-full mr-4"
                        />
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <div className="font-medium">{review.user.name}</div>
                              <div className="text-gray-500 text-sm flex items-center">
                                <MapPin size={12} className="mr-1" />
                                {review.user.location} • 
                                <Calendar size={12} className="mx-1" />
                                {review.date}
                              </div>
                            </div>
                            <div className="flex items-center bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-sm">
                              <Star size={14} className="mr-1 text-yellow-500" fill="currentColor" />
                              <span className="font-medium">{review.rating}</span>
                            </div>
                          </div>
                          
                          <div className="mt-3 mb-2">
                            <h3 className="font-bold text-lg">{review.place}</h3>
                            <div className="text-gray-500 text-sm flex items-center">
                              <MapPin size={14} className="mr-1" />
                              {review.location}
                            </div>
                          </div>
                          
                          <p className="text-gray-700 mb-4">{review.content}</p>
                          
                          {review.images.length > 0 && (
                            <div className="flex space-x-2 mb-4">
                              {review.images.map((image, idx) => (
                                <div key={idx} className="w-24 h-24 rounded-lg overflow-hidden">
                                  <img 
                                    src={image} 
                                    alt={`Review ${idx + 1}`} 
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                              ))}
                            </div>
                          )}
                          
                          <div className="flex items-center justify-between text-gray-500 text-sm">
                            <div className="flex items-center space-x-4">
                              <button className="flex items-center hover:text-red-500">
                                <Heart size={16} className="mr-1" />
                                <span>{review.likes}</span>
                              </button>
                              <button className="flex items-center hover:text-primary-500">
                                <MessageSquare size={16} className="mr-1" />
                                <span>{review.comments}</span>
                              </button>
                            </div>
                            <div className="flex items-center space-x-3">
                              <button className="hover:text-primary-500">
                                <Bookmark size={16} />
                              </button>
                              <button className="hover:text-primary-500">
                                <Share2 size={16} />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Photos Tab Content */}
            {activeTab === 'photos' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {photos.map((photo) => (
                  <div key={photo.id} className="bg-white rounded-xl shadow-md overflow-hidden">
                    <div className="relative">
                      <img 
                        src={photo.image} 
                        alt={`Photo of ${photo.location}`} 
                        className="w-full h-64 object-cover"
                      />
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                        <div className="flex items-center text-white">
                          <MapPin size={14} className="mr-1" />
                          <span className="text-sm font-medium">{photo.location}</span>
                        </div>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center mb-3">
                        <img 
                          src={photo.user.avatar} 
                          alt={photo.user.name} 
                          className="w-8 h-8 rounded-full mr-2"
                        />
                        <div className="text-sm font-medium">{photo.user.name}</div>
                      </div>
                      
                      <div className="flex justify-between text-gray-500 text-sm">
                        <div className="flex items-center space-x-4">
                          <button className="flex items-center hover:text-red-500">
                            <Heart size={16} className="mr-1" />
                            <span>{photo.likes}</span>
                          </button>
                          <button className="flex items-center hover:text-primary-500">
                            <MessageSquare size={16} className="mr-1" />
                            <span>{photo.comments}</span>
                          </button>
                        </div>
                        <button className="hover:text-primary-500">
                          <Share2 size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Sidebar */}
          <div className="w-full lg:w-1/4 space-y-6">
            {/* User Profile Card */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="p-6 text-center">
                <div className="mb-4">
                  <img 
                    src={currentUser.avatar} 
                    alt={currentUser.name} 
                    className="w-20 h-20 rounded-full mx-auto"
                  />
                </div>
                <h3 className="font-bold text-lg">{currentUser.name}</h3>
                <div className="text-gray-500 text-sm mb-4 flex items-center justify-center">
                  <MapPin size={14} className="mr-1" />
                  {currentUser.location}
                </div>
                
                <div className="flex justify-center divide-x divide-gray-200 mb-4">
                  <div className="px-4">
                    <div className="font-bold">24</div>
                    <div className="text-xs text-gray-500">Posts</div>
                  </div>
                  <div className="px-4">
                    <div className="font-bold">142</div>
                    <div className="text-xs text-gray-500">Followers</div>
                  </div>
                  <div className="px-4">
                    <div className="font-bold">86</div>
                    <div className="text-xs text-gray-500">Following</div>
                  </div>
                </div>
                
                <button className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <User size={16} className="mr-2" />
                  <span>View Profile</span>
                </button>
              </div>
            </div>
            
            {/* Trending Topics */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="p-4 border-b border-gray-200">
                <h3 className="font-bold">Trending Topics</h3>
              </div>
              <div className="p-4">
                <ul className="space-y-3">
                  <li>
                    <a href="#" className="flex items-center text-primary-600 hover:text-primary-700">
                      <span className="mr-2 font-bold">#</span>
                      <span>SummerTravel2023</span>
                      <span className="ml-auto text-xs text-gray-500">2.4k posts</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" className="flex items-center text-primary-600 hover:text-primary-700">
                      <span className="mr-2 font-bold">#</span>
                      <span>SoloTravel</span>
                      <span className="ml-auto text-xs text-gray-500">1.8k posts</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" className="flex items-center text-primary-600 hover:text-primary-700">
                      <span className="mr-2 font-bold">#</span>
                      <span>BudgetTravel</span>
                      <span className="ml-auto text-xs text-gray-500">1.5k posts</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" className="flex items-center text-primary-600 hover:text-primary-700">
                      <span className="mr-2 font-bold">#</span>
                      <span>EuropeTravel</span>
                      <span className="ml-auto text-xs text-gray-500">1.2k posts</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" className="flex items-center text-primary-600 hover:text-primary-700">
                      <span className="mr-2 font-bold">#</span>
                      <span>FoodieTravel</span>
                      <span className="ml-auto text-xs text-gray-500">980 posts</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            
            {/* Popular Groups */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="p-4 border-b border-gray-200">
                <h3 className="font-bold">Popular Travel Groups</h3>
              </div>
              <div className="p-4">
                <ul className="space-y-4">
                  <li className="flex items-center">
                    <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 font-bold mr-3">
                      FT
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">Female Travelers</div>
                      <div className="text-xs text-gray-500">12.4k members</div>
                    </div>
                    <button className="text-xs font-medium text-primary-600 hover:text-primary-700">
                      Join
                    </button>
                  </li>
                  <li className="flex items-center">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-bold mr-3">
                      ET
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">Eco Travelers</div>
                      <div className="text-xs text-gray-500">8.7k members</div>
                    </div>
                    <button className="text-xs font-medium text-primary-600 hover:text-primary-700">
                      Join
                    </button>
                  </li>
                  <li className="flex items-center">
                    <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600 font-bold mr-3">
                      BP
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">Budget Packers</div>
                      <div className="text-xs text-gray-500">9.3k members</div>
                    </div>
                    <button className="text-xs font-medium text-primary-600 hover:text-primary-700">
                      Join
                    </button>
                  </li>
                  <li className="flex items-center">
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 font-bold mr-3">
                      DP
                    </div>
                    <div className="flex-1">
                      <div className="font-medium">Digital Nomads</div>
                      <div className="text-xs text-gray-500">15.2k members</div>
                    </div>
                    <button className="text-xs font-medium text-primary-600 hover:text-primary-700">
                      Join
                    </button>
                  </li>
                </ul>
                <button className="w-full text-center text-primary-600 hover:text-primary-700 mt-4 text-sm font-medium">
                  View All Groups
                </button>
              </div>
            </div>
            
            {/* Upcoming Events */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="p-4 border-b border-gray-200">
                <h3 className="font-bold">Travel Meetups</h3>
              </div>
              <div className="p-4">
                <ul className="space-y-4">
                  <li>
                    <div className="flex items-start">
                      <div className="bg-primary-100 text-primary-800 rounded-lg p-2 text-center mr-3 flex-shrink-0">
                        <div className="text-sm font-bold">JUN</div>
                        <div className="text-lg font-bold">24</div>
                      </div>
                      <div>
                        <div className="font-medium">European Travelers Meetup</div>
                        <div className="text-sm text-gray-500">Barcelona, Spain</div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="flex items-start">
                      <div className="bg-primary-100 text-primary-800 rounded-lg p-2 text-center mr-3 flex-shrink-0">
                        <div className="text-sm font-bold">JUL</div>
                        <div className="text-lg font-bold">12</div>
                      </div>
                      <div>
                        <div className="font-medium">Southeast Asia Travel Workshop</div>
                        <div className="text-sm text-gray-500">Singapore</div>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="flex items-start">
                      <div className="bg-primary-100 text-primary-800 rounded-lg p-2 text-center mr-3 flex-shrink-0">
                        <div className="text-sm font-bold">AUG</div>
                        <div className="text-lg font-bold">05</div>
                      </div>
                      <div>
                        <div className="font-medium">Travel Photography Exhibition</div>
                        <div className="text-sm text-gray-500">New York, USA</div>
                      </div>
                    </div>
                  </li>
                </ul>
                <button className="w-full text-center text-primary-600 hover:text-primary-700 mt-4 text-sm font-medium">
                  View All Events
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Community;