import React, { useState } from 'react';
import { Award, Gift, Zap, Tag, ArrowUpRight, ChevronRight, Calendar, Check } from 'lucide-react';

const RewardSystem: React.FC = () => {
  const [showRedeemModal, setShowRedeemModal] = useState(false);
  const [selectedOffer, setSelectedOffer] = useState<any>(null);
  
  // Mock user rewards data
  const userRewards = {
    points: 3850,
    level: 'Silver Explorer',
    progress: 70, // percentage to next level
    tripsTaken: 12,
    reviewsWritten: 8,
    nextLevel: 'Gold Explorer',
    pointsToNextLevel: 1150,
  };
  
  // Mock badges data
  const badges = [
    {
      id: 1,
      name: 'Globetrotter',
      icon: <Globe />,
      description: 'Visited 10+ countries',
      earned: true,
      date: 'Earned on May 15, 2023',
    },
    {
      id: 2,
      name: 'Review Pro',
      icon: <Star />,
      description: 'Wrote 5+ helpful reviews',
      earned: true,
      date: 'Earned on Jun 3, 2023',
    },
    {
      id: 3,
      name: 'Photo Expert',
      icon: <Camera />,
      description: 'Shared 20+ quality photos',
      earned: false,
      progress: 60, // percentage complete
    },
    {
      id: 4,
      name: 'Road Warrior',
      icon: <Car />,
      description: 'Completed 3+ road trips',
      earned: true,
      date: 'Earned on Apr 22, 2023',
    },
    {
      id: 5,
      name: 'Adventure Seeker',
      icon: <Compass />,
      description: 'Tried 5+ adventure activities',
      earned: false,
      progress: 40, // percentage complete
    },
    {
      id: 6,
      name: 'Beach Lover',
      icon: <Sunset />,
      description: 'Visited 5+ beach destinations',
      earned: true,
      date: 'Earned on Jul 10, 2023',
    },
  ];
  
  // Mock redemption offers
  const redemptionOffers = [
    {
      id: 1,
      name: 'Amazon Gift Card',
      value: '$25',
      points: 2500,
      image: 'https://images.pexels.com/photos/5076511/pexels-photo-5076511.jpeg',
      provider: 'Amazon',
      expiry: 'No expiration',
      description: 'Redeem your points for an Amazon gift card to use on millions of items.',
    },
    {
      id: 2,
      name: 'Hotel Discount',
      value: '15% off',
      points: 1800,
      image: 'https://images.pexels.com/photos/271619/pexels-photo-271619.jpeg',
      provider: 'Hotels.com',
      expiry: 'Valid for 6 months',
      description: 'Get 15% off your next hotel booking on Hotels.com.',
    },
    {
      id: 3,
      name: 'Airport Lounge Pass',
      value: 'One-time access',
      points: 3000,
      image: 'https://images.pexels.com/photos/2610756/pexels-photo-2610756.jpeg',
      provider: 'Priority Pass',
      expiry: 'Valid for 12 months',
      description: 'Enjoy a relaxing pre-flight experience with access to over 1,300 airport lounges worldwide.',
    },
    {
      id: 4,
      name: 'Uber Ride Credit',
      value: '$10',
      points: 1000,
      image: 'https://images.pexels.com/photos/1178545/pexels-photo-1178545.jpeg',
      provider: 'Uber',
      expiry: 'Valid for 3 months',
      description: 'Get $10 credit for your next Uber ride.',
    },
    {
      id: 5,
      name: 'Swiggy Food Voucher',
      value: '$15',
      points: 1500,
      image: 'https://images.pexels.com/photos/1640770/pexels-photo-1640770.jpeg',
      provider: 'Swiggy',
      expiry: 'Valid for 45 days',
      description: 'Enjoy $15 off your next food order on Swiggy.',
    },
    {
      id: 6,
      name: 'Premium Subscription',
      value: '3 months',
      points: 3500,
      image: 'https://images.pexels.com/photos/1983037/pexels-photo-1983037.jpeg',
      provider: 'MyTravelBuddy',
      expiry: 'No expiration',
      description: 'Upgrade to Premium for 3 months and enjoy exclusive features like ad-free experience, offline maps, and premium travel guides.',
    },
  ];
  
  // Mock points history
  const pointsHistory = [
    {
      id: 1,
      action: 'Trip completed',
      points: '+500',
      date: 'Jul 15, 2023',
      details: 'Tokyo, Japan',
    },
    {
      id: 2,
      action: 'Review submitted',
      points: '+100',
      date: 'Jul 10, 2023',
      details: 'Park Hyatt Tokyo',
    },
    {
      id: 3,
      action: 'Photos shared',
      points: '+50',
      date: 'Jul 10, 2023',
      details: '5 photos from Tokyo',
    },
    {
      id: 4,
      action: 'Amazon Gift Card',
      points: '-2500',
      date: 'Jun 28, 2023',
      details: 'Redemption',
      type: 'redemption',
    },
    {
      id: 5,
      action: 'Trip completed',
      points: '+450',
      date: 'Jun 20, 2023',
      details: 'Barcelona, Spain',
    },
    {
      id: 6,
      action: 'Referral bonus',
      points: '+200',
      date: 'Jun 12, 2023',
      details: 'Friend signup: Michael K.',
    },
  ];
  
  const handleRedeemClick = (offer: any) => {
    setSelectedOffer(offer);
    setShowRedeemModal(true);
  };
  
  return (
    <div className="bg-gray-100 min-h-screen py-12">
      <div className="container-custom">
        <h1 className="text-3xl font-bold mb-8">Travel Rewards</h1>
        
        {/* User Rewards Summary */}
        <div className="bg-gradient-to-r from-primary-600 to-primary-800 rounded-xl text-white p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                  <Award size={32} className="text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">{userRewards.level}</h2>
                  <p className="text-primary-100">
                    {userRewards.pointsToNextLevel} points away from {userRewards.nextLevel}
                  </p>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="flex justify-between text-sm mb-1">
                  <span>Level Progress</span>
                  <span>{userRewards.progress}%</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-2.5">
                  <div 
                    className="bg-white h-2.5 rounded-full"
                    style={{ width: `${userRewards.progress}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 md:gap-6">
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                  <div className="text-3xl font-bold">{userRewards.points}</div>
                  <div className="text-primary-100">Available Points</div>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                  <div className="text-3xl font-bold">{userRewards.tripsTaken}</div>
                  <div className="text-primary-100">Trips Taken</div>
                </div>
              </div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h3 className="font-bold mb-4">Earn More Points</h3>
              <ul className="space-y-3">
                <li className="flex items-center text-sm">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center mr-3">
                    <Zap size={16} className="text-white" />
                  </div>
                  <div>
                    <div className="font-medium">Complete your profile</div>
                    <div className="text-primary-100">+100 points</div>
                  </div>
                </li>
                <li className="flex items-center text-sm">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center mr-3">
                    <Star size={16} className="text-white" />
                  </div>
                  <div>
                    <div className="font-medium">Write a review</div>
                    <div className="text-primary-100">+100 points per review</div>
                  </div>
                </li>
                <li className="flex items-center text-sm">
                  <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center mr-3">
                    <Users size={16} className="text-white" />
                  </div>
                  <div>
                    <div className="font-medium">Refer a friend</div>
                    <div className="text-primary-100">+200 points per referral</div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {/* Offers & Redemption */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden mb-8">
              <div className="p-4 sm:p-6 border-b border-gray-200">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold">Redeem Your Points</h2>
                  <button className="text-primary-600 text-sm font-medium flex items-center">
                    View All
                    <ChevronRight size={16} className="ml-1" />
                  </button>
                </div>
              </div>
              
              <div className="p-4 sm:p-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {redemptionOffers.slice(0, 6).map((offer) => (
                    <div 
                      key={offer.id} 
                      className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow"
                    >
                      <div className="h-32 overflow-hidden">
                        <img 
                          src={offer.image} 
                          alt={offer.name} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-bold">{offer.name}</h3>
                            <div className="text-sm text-gray-500">{offer.provider}</div>
                          </div>
                          <div className="bg-primary-50 text-primary-700 text-xs font-medium px-2 py-1 rounded">
                            {offer.value}
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center mt-3">
                          <div className="flex items-center text-gray-700 font-medium">
                            <Gift size={16} className="mr-1" />
                            <span>{offer.points} pts</span>
                          </div>
                          <button 
                            onClick={() => handleRedeemClick(offer)}
                            className={`text-sm font-medium px-3 py-1 rounded ${
                              userRewards.points >= offer.points
                                ? 'bg-primary-600 text-white hover:bg-primary-700'
                                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            }`}
                            disabled={userRewards.points < offer.points}
                          >
                            Redeem
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Points History */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-gray-200">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold">Points History</h2>
                  <button className="text-primary-600 text-sm font-medium flex items-center">
                    Full History
                    <ChevronRight size={16} className="ml-1" />
                  </button>
                </div>
              </div>
              
              <div className="p-4 sm:p-6">
                <div className="space-y-4">
                  {pointsHistory.map((item) => (
                    <div 
                      key={item.id} 
                      className="flex items-center justify-between py-2"
                    >
                      <div className="flex items-center">
                        <div 
                          className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 ${
                            item.type === 'redemption' 
                              ? 'bg-red-100 text-red-600' 
                              : item.points.startsWith('+') 
                              ? 'bg-green-100 text-green-600'
                              : 'bg-gray-100 text-gray-600'
                          }`}
                        >
                          {item.type === 'redemption' ? (
                            <Gift size={20} />
                          ) : item.points.startsWith('+') ? (
                            <Zap size={20} />
                          ) : (
                            <Tag size={20} />
                          )}
                        </div>
                        <div>
                          <div className="font-medium">{item.action}</div>
                          <div className="text-sm text-gray-500">{item.details}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div 
                          className={`font-bold ${
                            item.points.startsWith('+') 
                              ? 'text-green-600' 
                              : 'text-red-600'
                          }`}
                        >
                          {item.points}
                        </div>
                        <div className="text-sm text-gray-500">{item.date}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          <div className="space-y-8">
            {/* Membership Benefits */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-gray-200">
                <h2 className="text-xl font-bold">Membership Benefits</h2>
              </div>
              
              <div className="p-4 sm:p-6">
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 mr-3 flex-shrink-0">
                      <Check size={20} />
                    </div>
                    <div>
                      <h3 className="font-medium">Priority Customer Support</h3>
                      <p className="text-sm text-gray-600">
                        Get faster responses from our support team as a Silver member.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 mr-3 flex-shrink-0">
                      <Check size={20} />
                    </div>
                    <div>
                      <h3 className="font-medium">Special Offers</h3>
                      <p className="text-sm text-gray-600">
                        Access to member-only deals and discounts on travel bookings.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 mr-3 flex-shrink-0">
                      <Check size={20} />
                    </div>
                    <div>
                      <h3 className="font-medium">Point Bonuses</h3>
                      <p className="text-sm text-gray-600">
                        Earn 10% extra points on all activities as a Silver member.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start opacity-50">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 mr-3 flex-shrink-0">
                      <Lock size={20} />
                    </div>
                    <div>
                      <h3 className="font-medium flex items-center">
                        Premium Travel Guides
                        <span className="ml-2 text-xs bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded">
                          Gold+
                        </span>
                      </h3>
                      <p className="text-sm text-gray-600">
                        Unlock exclusive travel guides and insider tips.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start opacity-50">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 mr-3 flex-shrink-0">
                      <Lock size={20} />
                    </div>
                    <div>
                      <h3 className="font-medium flex items-center">
                        Hotel Upgrades
                        <span className="ml-2 text-xs bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded">
                          Gold+
                        </span>
                      </h3>
                      <p className="text-sm text-gray-600">
                        Complimentary room upgrades when available.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 pt-4 border-t border-gray-200">
                  <div className="text-center">
                    <button className="text-primary-600 hover:text-primary-700 font-medium text-sm flex items-center mx-auto">
                      View All Benefits
                      <ArrowUpRight size={14} className="ml-1" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Badges */}
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-gray-200">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold">Your Badges</h2>
                  <button className="text-primary-600 text-sm font-medium flex items-center">
                    View All
                    <ChevronRight size={16} className="ml-1" />
                  </button>
                </div>
              </div>
              
              <div className="p-4 sm:p-6">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {badges.map((badge) => (
                    <div 
                      key={badge.id} 
                      className={`border border-gray-200 rounded-lg p-4 text-center ${
                        badge.earned ? '' : 'opacity-60'
                      }`}
                    >
                      <div className="mx-auto w-12 h-12 flex items-center justify-center mb-2">
                        {badge.icon}
                      </div>
                      <h3 className="font-medium text-sm mb-1">{badge.name}</h3>
                      <p className="text-xs text-gray-500 mb-2">{badge.description}</p>
                      
                      {badge.earned ? (
                        <div className="text-xs text-green-600 flex items-center justify-center">
                          <Check size={12} className="mr-1" />
                          <span>{badge.date}</span>
                        </div>
                      ) : (
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div 
                            className="bg-primary-600 h-1.5 rounded-full"
                            style={{ width: `${badge.progress}%` }}
                          ></div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Redemption Modal */}
      {showRedeemModal && selectedOffer && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl max-w-md w-full m-4 overflow-hidden">
            <div className="bg-primary-600 text-white p-6">
              <h3 className="text-xl font-bold mb-1">Confirm Redemption</h3>
              <p className="text-primary-100">
                You're about to redeem points for a reward
              </p>
            </div>
            
            <div className="p-6">
              <div className="flex items-center mb-4">
                <div className="w-16 h-16 flex-shrink-0 overflow-hidden rounded-md">
                  <img 
                    src={selectedOffer.image} 
                    alt={selectedOffer.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="ml-4">
                  <h4 className="font-bold">{selectedOffer.name}</h4>
                  <div className="text-sm text-gray-500">{selectedOffer.provider}</div>
                  <div className="text-sm text-gray-700 mt-1">{selectedOffer.value}</div>
                </div>
              </div>
              
              <div className="border-t border-b border-gray-200 py-4 my-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-600">Points required:</span>
                  <span className="font-bold">{selectedOffer.points} pts</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Your balance after redemption:</span>
                  <span className="font-bold">{userRewards.points - selectedOffer.points} pts</span>
                </div>
              </div>
              
              <div className="text-sm text-gray-600 mb-6">
                <div className="flex items-center mb-1">
                  <Calendar size={14} className="mr-1" />
                  <span>Expiry: {selectedOffer.expiry}</span>
                </div>
                <p>{selectedOffer.description}</p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3">
                <button 
                  className="btn border border-gray-300 hover:bg-gray-50 flex-1"
                  onClick={() => setShowRedeemModal(false)}
                >
                  Cancel
                </button>
                <button 
                  className="btn bg-primary-600 text-white hover:bg-primary-700 flex-1"
                  onClick={() => {
                    // Here would be the redemption logic
                    alert('Redemption successful!');
                    setShowRedeemModal(false);
                  }}
                >
                  Confirm Redemption
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Icon components
const Globe = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500">
    <circle cx="12" cy="12" r="10"></circle>
    <line x1="2" y1="12" x2="22" y2="12"></line>
    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
  </svg>
);

const Star = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-500">
    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
  </svg>
);

const Camera = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-500">
    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
    <circle cx="12" cy="13" r="4"></circle>
  </svg>
);

const Car = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500">
    <path d="M14 16H9m10 0h3v-3.15a1 1 0 0 0-.84-.99L16 11l-2.7-3.6a1 1 0 0 0-.8-.4H5.24a2 2 0 0 0-1.8 1.1l-.8 1.63A6 6 0 0 0 2 12.42V16h2"></path>
    <circle cx="6.5" cy="16.5" r="2.5"></circle>
    <circle cx="16.5" cy="16.5" r="2.5"></circle>
  </svg>
);

const Compass = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-500">
    <circle cx="12" cy="12" r="10"></circle>
    <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"></polygon>
  </svg>
);

const Sunset = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-500">
    <path d="M17 18a5 5 0 0 0-10 0"></path>
    <line x1="12" y1="9" x2="12" y2="2"></line>
    <line x1="4.22" y1="10.22" x2="5.64" y2="11.64"></line>
    <line x1="1" y1="18" x2="3" y2="18"></line>
    <line x1="21" y1="18" x2="23" y2="18"></line>
    <line x1="18.36" y1="11.64" x2="19.78" y2="10.22"></line>
    <line x1="23" y1="22" x2="1" y2="22"></line>
    <polyline points="8 6 12 2 16 6"></polyline>
  </svg>
);

const Lock = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
  </svg>
);

export default RewardSystem;