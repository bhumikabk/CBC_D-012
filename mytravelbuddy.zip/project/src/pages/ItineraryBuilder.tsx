import React, { useState } from 'react';
import { Calendar, Clock, DollarSign, Map, MapPin, Compass, Plane, Hotel, Utensils, Camera } from 'lucide-react';

const ItineraryBuilder: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    destination: '',
    startDate: '',
    endDate: '',
    budget: 'medium',
    travelers: 1,
    interests: [],
    pastTrips: '',
  });
  
  const [showItinerary, setShowItinerary] = useState(false);
  
  // Mock interests data
  const interests = [
    { id: 'adventure', label: 'Adventure', icon: <Compass size={18} /> },
    { id: 'culture', label: 'Culture & History', icon: <Map size={18} /> },
    { id: 'food', label: 'Food & Dining', icon: <Utensils size={18} /> },
    { id: 'relaxation', label: 'Relaxation', icon: <Hotel size={18} /> },
    { id: 'photography', label: 'Photography', icon: <Camera size={18} /> },
    { id: 'nightlife', label: 'Nightlife', icon: <Clock size={18} /> },
  ];
  
  // Handle form input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  // Handle interest selections
  const toggleInterest = (interestId: string) => {
    setFormData(prev => {
      const updatedInterests = prev.interests.includes(interestId)
        ? prev.interests.filter(id => id !== interestId)
        : [...prev.interests, interestId];
      return { ...prev, interests: updatedInterests };
    });
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowItinerary(true);
  };
  
  // Generate a mock itinerary based on form data
  const generateItinerary = () => {
    // For demonstration, we'll return a mock itinerary
    const days = getDaysBetweenDates(formData.startDate, formData.endDate);
    
    return Array.from({ length: days }, (_, i) => ({
      day: i + 1,
      date: new Date(new Date(formData.startDate).getTime() + i * 24 * 60 * 60 * 1000).toLocaleDateString(),
      activities: generateDailyActivities(i + 1),
    }));
  };
  
  // Helper function to generate mock daily activities
  const generateDailyActivities = (day: number) => {
    const activities = [
      {
        time: '09:00 AM',
        title: day === 1 ? 'Arrival and Check-in' : `Visit to ${day % 2 === 0 ? 'Local Museum' : 'Historic Site'}`,
        description: day === 1 
          ? 'Arrive at your hotel and settle in.' 
          : `Explore the ${day % 2 === 0 ? 'fascinating exhibits at the local museum' : 'historic landmarks and monuments'}`,
        type: day === 1 ? 'logistics' : 'culture',
      },
      {
        time: '12:00 PM',
        title: `Lunch at ${day % 3 === 0 ? 'Local Café' : 'Traditional Restaurant'}`,
        description: `Enjoy ${day % 3 === 0 ? 'a casual lunch with local specialties' : 'authentic local cuisine at a highly rated restaurant'}`,
        type: 'food',
      },
      {
        time: '02:00 PM',
        title: day % 4 === 0 
          ? 'Outdoor Adventure' 
          : day % 3 === 0 
          ? 'Shopping District' 
          : 'Cultural Experience',
        description: day % 4 === 0 
          ? 'Hiking, kayaking, or adventure activities based on location.' 
          : day % 3 === 0 
          ? 'Explore local markets and boutiques for unique souvenirs.' 
          : 'Participate in a local workshop or cultural activity.',
        type: day % 4 === 0 ? 'adventure' : day % 3 === 0 ? 'shopping' : 'culture',
      },
      {
        time: '06:00 PM',
        title: 'Dinner',
        description: day % 2 === 0 
          ? 'Fine dining experience at a top-rated restaurant.' 
          : 'Casual dinner at a local favorite spot.',
        type: 'food',
      },
      {
        time: '08:00 PM',
        title: day % 3 === 0 
          ? 'Evening Entertainment' 
          : 'Leisurely Stroll',
        description: day % 3 === 0 
          ? 'Attend a local show, concert, or cultural performance.' 
          : 'Take a relaxing walk to see the city lights or beachfront.',
        type: day % 3 === 0 ? 'entertainment' : 'relaxation',
      },
    ];
    
    return activities;
  };
  
  // Helper function to calculate days between dates
  const getDaysBetweenDates = (startDateStr: string, endDateStr: string) => {
    if (!startDateStr || !endDateStr) return 3; // Default to 3 days if dates not provided
    
    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);
    const diffTime = Math.abs(endDate.getTime() - startDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays + 1; // Include both start and end days
  };

  // Render the itinerary once form is submitted
  if (showItinerary) {
    const itinerary = generateItinerary();
    
    return (
      <div className="bg-gray-100 min-h-screen py-12">
        <div className="container-custom">
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="bg-primary-600 text-white p-6">
              <div className="flex justify-between items-center">
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold mb-2">Your Personalized Itinerary</h1>
                  <p className="text-primary-100">
                    {formData.destination} • {formData.startDate} to {formData.endDate} • {formData.travelers} Traveler(s)
                  </p>
                </div>
                <button 
                  onClick={() => setShowItinerary(false)}
                  className="btn bg-white text-primary-600 hover:bg-primary-50"
                >
                  Edit Itinerary
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <div className="flex flex-wrap gap-2 mb-6">
                {formData.interests.map(interest => {
                  const interestObj = interests.find(i => i.id === interest);
                  return interestObj ? (
                    <div key={interest} className="bg-primary-50 text-primary-700 px-3 py-1 rounded-full text-sm font-medium flex items-center">
                      {interestObj.icon}
                      <span className="ml-1">{interestObj.label}</span>
                    </div>
                  ) : null;
                })}
              </div>
              
              <div className="space-y-8">
                {itinerary.map((day) => (
                  <div key={day.day} className="border-b border-gray-200 pb-8 last:border-b-0">
                    <h2 className="text-xl font-bold mb-4">Day {day.day}: {day.date}</h2>
                    <div className="space-y-4">
                      {day.activities.map((activity, index) => (
                        <div key={index} className="flex">
                          <div className="mr-4 text-right w-20 flex-shrink-0">
                            <div className="font-medium text-gray-700">{activity.time}</div>
                          </div>
                          <div className="relative border-l-2 border-primary-200 pl-4 pb-4">
                            <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-primary-500"></div>
                            <div>
                              <h3 className="font-semibold text-lg">{activity.title}</h3>
                              <p className="text-gray-600">{activity.description}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-8 space-y-4">
                <h2 className="text-xl font-bold">Recommendations</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-lg mb-2">Where to Stay</h3>
                    <p className="text-gray-600 mb-4">Based on your preferences, we recommend these accommodations:</p>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <Hotel size={18} className="text-primary-500 mr-2 mt-1" />
                        <div>
                          <span className="font-medium">Grand Hotel & Spa</span>
                          <p className="text-sm text-gray-500">Luxury accommodation with amenities that match your interests</p>
                        </div>
                      </li>
                      <li className="flex items-start">
                        <Hotel size={18} className="text-primary-500 mr-2 mt-1" />
                        <div>
                          <span className="font-medium">Riverside Boutique Inn</span>
                          <p className="text-sm text-gray-500">Charming boutique hotel in a central location</p>
                        </div>
                      </li>
                    </ul>
                  </div>
                  
                  <div className="border border-gray-200 rounded-lg p-4">
                    <h3 className="font-semibold text-lg mb-2">Transportation</h3>
                    <p className="text-gray-600 mb-4">Suggested transportation options:</p>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <Plane size={18} className="text-primary-500 mr-2 mt-1" />
                        <div>
                          <span className="font-medium">Airport Transfer</span>
                          <p className="text-sm text-gray-500">Private car service from airport to hotel</p>
                        </div>
                      </li>
                      <li className="flex items-start">
                        <Map size={18} className="text-primary-500 mr-2 mt-1" />
                        <div>
                          <span className="font-medium">Daily Transportation</span>
                          <p className="text-sm text-gray-500">Public transit passes or rental car depending on location</p>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <button className="btn btn-primary flex-1">
                  Save Itinerary
                </button>
                <button className="btn border border-gray-300 hover:bg-gray-50 flex-1">
                  Share
                </button>
                <button className="btn border border-gray-300 hover:bg-gray-50 flex-1">
                  Download PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-100 min-h-screen py-12">
      <div className="container-custom">
        <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-md overflow-hidden">
          <div className="bg-primary-600 text-white p-6">
            <h1 className="text-2xl md:text-3xl font-bold mb-2">Build Your Perfect Itinerary</h1>
            <p className="text-primary-100">
              Tell us about your travel preferences and let our AI create a personalized itinerary just for you
            </p>
          </div>
          
          <div className="p-6">
            <div className="mb-8">
              <div className="flex justify-between items-center">
                {[1, 2, 3].map((step) => (
                  <div key={step} className="flex flex-col items-center">
                    <div 
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        currentStep === step 
                          ? 'bg-primary-600 text-white' 
                          : currentStep > step 
                          ? 'bg-primary-100 text-primary-600' 
                          : 'bg-gray-200 text-gray-500'
                      }`}
                    >
                      {step}
                    </div>
                    <div className="text-xs mt-2 text-gray-500 text-center">
                      {step === 1 ? 'Basics' : step === 2 ? 'Preferences' : 'Personalization'}
                    </div>
                  </div>
                ))}
              </div>
              <div className="relative mt-2">
                <div className="absolute top-0 inset-x-0 h-1 bg-gray-200"></div>
                <div 
                  className="absolute top-0 left-0 h-1 bg-primary-500 transition-all duration-300" 
                  style={{ width: `${((currentStep - 1) / 2) * 100}%` }}
                ></div>
              </div>
            </div>
            
            <form onSubmit={handleSubmit}>
              {/* Step 1: Basic Information */}
              {currentStep === 1 && (
                <div className="space-y-6">
                  <div>
                    <label htmlFor="destination" className="label">Where do you want to go?</label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <MapPin size={18} className="text-gray-400" />
                      </div>
                      <input
                        type="text"
                        id="destination"
                        name="destination"
                        required
                        value={formData.destination}
                        onChange={handleChange}
                        placeholder="City, Country or Region"
                        className="input pl-10"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="startDate" className="label">Start Date</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Calendar size={18} className="text-gray-400" />
                        </div>
                        <input
                          type="date"
                          id="startDate"
                          name="startDate"
                          required
                          value={formData.startDate}
                          onChange={handleChange}
                          className="input pl-10"
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="endDate" className="label">End Date</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <Calendar size={18} className="text-gray-400" />
                        </div>
                        <input
                          type="date"
                          id="endDate"
                          name="endDate"
                          required
                          value={formData.endDate}
                          onChange={handleChange}
                          className="input pl-10"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="budget" className="label">What's your budget?</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <DollarSign size={18} className="text-gray-400" />
                        </div>
                        <select
                          id="budget"
                          name="budget"
                          value={formData.budget}
                          onChange={handleChange}
                          className="input pl-10"
                        >
                          <option value="budget">Budget</option>
                          <option value="medium">Medium</option>
                          <option value="luxury">Luxury</option>
                        </select>
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="travelers" className="label">Number of Travelers</label>
                      <input
                        type="number"
                        id="travelers"
                        name="travelers"
                        min="1"
                        max="20"
                        value={formData.travelers}
                        onChange={handleChange}
                        className="input"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end mt-8">
                    <button
                      type="button"
                      onClick={() => setCurrentStep(2)}
                      className="btn btn-primary"
                    >
                      Next
                    </button>
                  </div>
                </div>
              )}
              
              {/* Step 2: Travel Preferences */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <div>
                    <label className="label">What are you interested in? (Select all that apply)</label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 mt-2">
                      {interests.map((interest) => (
                        <button
                          key={interest.id}
                          type="button"
                          onClick={() => toggleInterest(interest.id)}
                          className={`p-3 border rounded-lg text-left flex items-center transition-colors ${
                            formData.interests.includes(interest.id)
                              ? 'border-primary-500 bg-primary-50 text-primary-700'
                              : 'border-gray-300 hover:border-primary-300'
                          }`}
                        >
                          <div className={`mr-3 ${
                            formData.interests.includes(interest.id)
                              ? 'text-primary-500'
                              : 'text-gray-400'
                          }`}>
                            {interest.icon}
                          </div>
                          <span>{interest.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex justify-between mt-8">
                    <button
                      type="button"
                      onClick={() => setCurrentStep(1)}
                      className="btn border border-gray-300 hover:bg-gray-50"
                    >
                      Back
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrentStep(3)}
                      className="btn btn-primary"
                    >
                      Next
                    </button>
                  </div>
                </div>
              )}
              
              {/* Step 3: Past Travel Experience */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div>
                    <label htmlFor="pastTrips" className="label">Tell us about your past trips (optional)</label>
                    <p className="text-sm text-gray-500 mb-2">
                      This helps us understand your travel style and preferences better.
                    </p>
                    <textarea
                      id="pastTrips"
                      name="pastTrips"
                      rows={5}
                      value={formData.pastTrips}
                      onChange={handleChange}
                      placeholder="I enjoyed my trip to Japan last year where I visited historical sites and tried local cuisine..."
                      className="input"
                    ></textarea>
                  </div>
                  
                  <div className="flex justify-between mt-8">
                    <button
                      type="button"
                      onClick={() => setCurrentStep(2)}
                      className="btn border border-gray-300 hover:bg-gray-50"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      className="btn btn-primary"
                    >
                      Create My Itinerary
                    </button>
                  </div>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ItineraryBuilder;