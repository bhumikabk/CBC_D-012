import React, { useState } from 'react';
import { 
  Plane, Hotel, Car, CalendarDays, Users, Map, CreditCard, Clock, Check, 
  ArrowRight, ChevronRight, ChevronLeft, Star, Shield
} from 'lucide-react';

const BookingAssistant: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [bookingType, setBookingType] = useState<string>('');
  
  // Mock booking form data
  const [formData, setFormData] = useState({
    destination: '',
    checkIn: '',
    checkOut: '',
    travelers: 2,
    rooms: 1,
    flightType: 'roundtrip',
    departureCity: '',
    departureDate: '',
    returnDate: '',
    carPickup: '',
    carDropoff: '',
    pickupDate: '',
    dropoffDate: '',
  });
  
  // Handle form input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  // Navigate between steps
  const nextStep = () => {
    setCurrentStep(prev => Math.min(prev + 1, 4));
  };
  
  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };
  
  const selectBookingType = (type: string) => {
    setBookingType(type);
    nextStep();
  };
  
  // Mock data for hotels
  const hotels = [
    {
      id: 1,
      name: 'Grand Luxury Resort & Spa',
      image: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg',
      price: 249,
      rating: 4.8,
      reviews: 324,
      amenities: ['Free WiFi', 'Pool', 'Spa', 'Restaurant', 'Fitness Center'],
      location: 'Downtown area, 2.5 miles from city center'
    },
    {
      id: 2,
      name: 'Seaside Boutique Hotel',
      image: 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg',
      price: 189,
      rating: 4.6,
      reviews: 256,
      amenities: ['Free WiFi', 'Beach Access', 'Restaurant', 'Bar'],
      location: 'Beachfront, 4 miles from city center'
    },
    {
      id: 3,
      name: 'Urban Modern Suites',
      image: 'https://images.pexels.com/photos/1579253/pexels-photo-1579253.jpeg',
      price: 159,
      rating: 4.4,
      reviews: 187,
      amenities: ['Free WiFi', 'Kitchenette', 'Fitness Center', 'Business Center'],
      location: 'City center, walking distance to attractions'
    },
  ];
  
  // Mock data for flights
  const flights = [
    {
      id: 1,
      airline: 'SkyRoute Airlines',
      logo: 'https://via.placeholder.com/40',
      departureTime: '08:45',
      arrivalTime: '11:30',
      duration: '2h 45m',
      price: 349,
      stops: 'Nonstop',
      departureAirport: 'JFK',
      arrivalAirport: 'LAX'
    },
    {
      id: 2,
      airline: 'Global Airways',
      logo: 'https://via.placeholder.com/40',
      departureTime: '10:15',
      arrivalTime: '13:45',
      duration: '3h 30m',
      price: 289,
      stops: '1 stop (DFW)',
      departureAirport: 'JFK',
      arrivalAirport: 'LAX'
    },
    {
      id: 3,
      airline: 'Continental Express',
      logo: 'https://via.placeholder.com/40',
      departureTime: '14:30',
      arrivalTime: '17:15',
      duration: '2h 45m',
      price: 309,
      stops: 'Nonstop',
      departureAirport: 'JFK',
      arrivalAirport: 'LAX'
    },
  ];
  
  // Mock data for cars
  const cars = [
    {
      id: 1,
      type: 'Economy',
      name: 'Toyota Corolla or similar',
      image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg',
      price: 45,
      features: ['5 seats', 'Automatic', '35 mpg', 'A/C', '2 bags'],
      company: 'Hertz'
    },
    {
      id: 2,
      type: 'SUV',
      name: 'Toyota RAV4 or similar',
      image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg',
      price: 65,
      features: ['5 seats', 'Automatic', '28 mpg', 'A/C', '4 bags'],
      company: 'Enterprise'
    },
    {
      id: 3,
      type: 'Luxury',
      name: 'Mercedes C-Class or similar',
      image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg',
      price: 95,
      features: ['5 seats', 'Automatic', '30 mpg', 'A/C', 'Leather seats', '3 bags'],
      company: 'Avis'
    },
  ];
  
  return (
    <div className="bg-gray-100 min-h-screen py-12">
      <div className="container-custom">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="bg-primary-600 text-white p-6">
              <h1 className="text-2xl md:text-3xl font-bold mb-2">Smart Booking Assistant</h1>
              <p className="text-primary-100">
                Find and book the perfect accommodations, flights, and rentals in one place
              </p>
              
              {/* Progress Steps */}
              <div className="mt-6 relative">
                <div className="flex justify-between items-center">
                  {[1, 2, 3, 4].map((step) => (
                    <div key={step} className="flex flex-col items-center z-10">
                      <div 
                        className={`w-8 h-8 rounded-full flex items-center justify-center font-medium ${
                          currentStep >= step 
                            ? 'bg-white text-primary-600' 
                            : 'bg-primary-400 text-white'
                        }`}
                      >
                        {step}
                      </div>
                      <div className="text-xs mt-1 text-white text-center">
                        {step === 1 ? 'Type' : step === 2 ? 'Details' : step === 3 ? 'Options' : 'Confirm'}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="absolute top-4 h-0.5 bg-primary-400 w-full"></div>
                <div 
                  className="absolute top-4 h-0.5 bg-white transition-all duration-300" 
                  style={{ width: `${((currentStep - 1) / 3) * 100}%` }}
                ></div>
              </div>
            </div>
            
            <div className="p-6">
              {/* Step 1: Select Booking Type */}
              {currentStep === 1 && (
                <div>
                  <h2 className="text-xl font-bold mb-6 text-center">What would you like to book?</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Hotel Card */}
                    <div 
                      onClick={() => selectBookingType('hotel')}
                      className="border border-gray-200 rounded-lg p-6 text-center hover:border-primary-500 hover:shadow-md cursor-pointer transition-all"
                    >
                      <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Hotel className="h-8 w-8 text-primary-500" />
                      </div>
                      <h3 className="font-bold text-lg mb-2">Hotels & Lodging</h3>
                      <p className="text-gray-600 text-sm">Find perfect accommodations for your stay</p>
                    </div>
                    
                    {/* Flight Card */}
                    <div 
                      onClick={() => selectBookingType('flight')}
                      className="border border-gray-200 rounded-lg p-6 text-center hover:border-primary-500 hover:shadow-md cursor-pointer transition-all"
                    >
                      <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Plane className="h-8 w-8 text-primary-500" />
                      </div>
                      <h3 className="font-bold text-lg mb-2">Flights</h3>
                      <p className="text-gray-600 text-sm">Search for the best airfare deals</p>
                    </div>
                    
                    {/* Car Rental Card */}
                    <div 
                      onClick={() => selectBookingType('car')}
                      className="border border-gray-200 rounded-lg p-6 text-center hover:border-primary-500 hover:shadow-md cursor-pointer transition-all"
                    >
                      <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Car className="h-8 w-8 text-primary-500" />
                      </div>
                      <h3 className="font-bold text-lg mb-2">Car Rentals</h3>
                      <p className="text-gray-600 text-sm">Rent vehicles for your travel needs</p>
                    </div>
                  </div>
                  
                  <div className="text-center mt-10">
                    <p className="text-sm text-gray-500 mb-4">Looking for a complete package?</p>
                    <button 
                      onClick={() => selectBookingType('package')}
                      className="btn border border-primary-500 text-primary-600 hover:bg-primary-50"
                    >
                      Create a Custom Travel Package
                    </button>
                  </div>
                </div>
              )}
              
              {/* Step 2: Enter Details */}
              {currentStep === 2 && (
                <div>
                  <h2 className="text-xl font-bold mb-6">
                    {bookingType === 'hotel' && 'Find Your Perfect Stay'}
                    {bookingType === 'flight' && 'Search for Flights'}
                    {bookingType === 'car' && 'Rent a Vehicle'}
                    {bookingType === 'package' && 'Create Your Travel Package'}
                  </h2>
                  
                  {/* Hotel Booking Form */}
                  {bookingType === 'hotel' && (
                    <div className="space-y-4">
                      <div>
                        <label htmlFor="destination" className="label">Destination</label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Map size={18} className="text-gray-400" />
                          </div>
                          <input
                            type="text"
                            id="destination"
                            name="destination"
                            value={formData.destination}
                            onChange={handleChange}
                            placeholder="City, region, or specific hotel"
                            className="input pl-10"
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="checkIn" className="label">Check-in Date</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <CalendarDays size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="date"
                              id="checkIn"
                              name="checkIn"
                              value={formData.checkIn}
                              onChange={handleChange}
                              className="input pl-10"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label htmlFor="checkOut" className="label">Check-out Date</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <CalendarDays size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="date"
                              id="checkOut"
                              name="checkOut"
                              value={formData.checkOut}
                              onChange={handleChange}
                              className="input pl-10"
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="travelers" className="label">Travelers</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <Users size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="number"
                              id="travelers"
                              name="travelers"
                              min="1"
                              max="10"
                              value={formData.travelers}
                              onChange={handleChange}
                              className="input pl-10"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label htmlFor="rooms" className="label">Rooms</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <Hotel size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="number"
                              id="rooms"
                              name="rooms"
                              min="1"
                              max="5"
                              value={formData.rooms}
                              onChange={handleChange}
                              className="input pl-10"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Flight Booking Form */}
                  {bookingType === 'flight' && (
                    <div className="space-y-4">
                      <div>
                        <div className="flex space-x-4 mb-4">
                          <label className="flex items-center">
                            <input
                              type="radio"
                              name="flightType"
                              value="roundtrip"
                              checked={formData.flightType === 'roundtrip'}
                              onChange={handleChange}
                              className="mr-2"
                            />
                            Round Trip
                          </label>
                          <label className="flex items-center">
                            <input
                              type="radio"
                              name="flightType"
                              value="oneway"
                              checked={formData.flightType === 'oneway'}
                              onChange={handleChange}
                              className="mr-2"
                            />
                            One Way
                          </label>
                          <label className="flex items-center">
                            <input
                              type="radio"
                              name="flightType"
                              value="multicity"
                              checked={formData.flightType === 'multicity'}
                              onChange={handleChange}
                              className="mr-2"
                            />
                            Multi-City
                          </label>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="departureCity" className="label">From</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <Plane size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="text"
                              id="departureCity"
                              name="departureCity"
                              value={formData.departureCity}
                              onChange={handleChange}
                              placeholder="City or airport"
                              className="input pl-10"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label htmlFor="destination" className="label">To</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <Plane size={18} className="text-gray-400 transform rotate-90" />
                            </div>
                            <input
                              type="text"
                              id="destination"
                              name="destination"
                              value={formData.destination}
                              onChange={handleChange}
                              placeholder="City or airport"
                              className="input pl-10"
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="departureDate" className="label">Departure Date</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <CalendarDays size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="date"
                              id="departureDate"
                              name="departureDate"
                              value={formData.departureDate}
                              onChange={handleChange}
                              className="input pl-10"
                            />
                          </div>
                        </div>
                        
                        {formData.flightType === 'roundtrip' && (
                          <div>
                            <label htmlFor="returnDate" className="label">Return Date</label>
                            <div className="relative">
                              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <CalendarDays size={18} className="text-gray-400" />
                              </div>
                              <input
                                type="date"
                                id="returnDate"
                                name="returnDate"
                                value={formData.returnDate}
                                onChange={handleChange}
                                className="input pl-10"
                              />
                            </div>
                          </div>
                        )}
                      </div>
                      
                      <div>
                        <label htmlFor="travelers" className="label">Passengers</label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Users size={18} className="text-gray-400" />
                          </div>
                          <input
                            type="number"
                            id="travelers"
                            name="travelers"
                            min="1"
                            max="10"
                            value={formData.travelers}
                            onChange={handleChange}
                            className="input pl-10"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Car Rental Form */}
                  {bookingType === 'car' && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="carPickup" className="label">Pick-up Location</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <Map size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="text"
                              id="carPickup"
                              name="carPickup"
                              value={formData.carPickup}
                              onChange={handleChange}
                              placeholder="City or airport"
                              className="input pl-10"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label htmlFor="carDropoff" className="label">Drop-off Location</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <Map size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="text"
                              id="carDropoff"
                              name="carDropoff"
                              value={formData.carDropoff}
                              onChange={handleChange}
                              placeholder="Same as pick-up"
                              className="input pl-10"
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="pickupDate" className="label">Pick-up Date & Time</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <CalendarDays size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="date"
                              id="pickupDate"
                              name="pickupDate"
                              value={formData.pickupDate}
                              onChange={handleChange}
                              className="input pl-10"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label htmlFor="dropoffDate" className="label">Drop-off Date & Time</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <CalendarDays size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="date"
                              id="dropoffDate"
                              name="dropoffDate"
                              value={formData.dropoffDate}
                              onChange={handleChange}
                              className="input pl-10"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Package Booking Form */}
                  {bookingType === 'package' && (
                    <div className="space-y-4">
                      <div>
                        <label htmlFor="destination" className="label">Destination</label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Map size={18} className="text-gray-400" />
                          </div>
                          <input
                            type="text"
                            id="destination"
                            name="destination"
                            value={formData.destination}
                            onChange={handleChange}
                            placeholder="City, country, or region"
                            className="input pl-10"
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="departureCity" className="label">Departure From</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <Plane size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="text"
                              id="departureCity"
                              name="departureCity"
                              value={formData.departureCity}
                              onChange={handleChange}
                              placeholder="City or airport"
                              className="input pl-10"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label htmlFor="travelers" className="label">Number of Travelers</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <Users size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="number"
                              id="travelers"
                              name="travelers"
                              min="1"
                              max="10"
                              value={formData.travelers}
                              onChange={handleChange}
                              className="input pl-10"
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="departureDate" className="label">Departure Date</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <CalendarDays size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="date"
                              id="departureDate"
                              name="departureDate"
                              value={formData.departureDate}
                              onChange={handleChange}
                              className="input pl-10"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label htmlFor="returnDate" className="label">Return Date</label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <CalendarDays size={18} className="text-gray-400" />
                            </div>
                            <input
                              type="date"
                              id="returnDate"
                              name="returnDate"
                              value={formData.returnDate}
                              onChange={handleChange}
                              className="input pl-10"
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="label">Package Includes:</p>
                        <div className="flex flex-wrap gap-2">
                          <div className="flex items-center space-x-2 border border-gray-200 rounded-md px-3 py-2">
                            <input 
                              type="checkbox" 
                              id="includeFlights" 
                              checked 
                              readOnly
                              className="text-primary-600 focus:ring-primary-500"
                            />
                            <label htmlFor="includeFlights" className="text-sm">Flights</label>
                          </div>
                          <div className="flex items-center space-x-2 border border-gray-200 rounded-md px-3 py-2">
                            <input 
                              type="checkbox" 
                              id="includeHotel" 
                              checked 
                              readOnly
                              className="text-primary-600 focus:ring-primary-500"
                            />
                            <label htmlFor="includeHotel" className="text-sm">Hotel</label>
                          </div>
                          <div className="flex items-center space-x-2 border border-gray-200 rounded-md px-3 py-2">
                            <input 
                              type="checkbox" 
                              id="includeCar" 
                              className="text-primary-600 focus:ring-primary-500"
                            />
                            <label htmlFor="includeCar" className="text-sm">Car Rental</label>
                          </div>
                          <div className="flex items-center space-x-2 border border-gray-200 rounded-md px-3 py-2">
                            <input 
                              type="checkbox" 
                              id="includeActivities" 
                              className="text-primary-600 focus:ring-primary-500"
                            />
                            <label htmlFor="includeActivities" className="text-sm">Activities</label>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex justify-between mt-8">
                    <button
                      onClick={prevStep}
                      className="btn border border-gray-300 hover:bg-gray-50"
                    >
                      Back
                    </button>
                    <button
                      onClick={nextStep}
                      className="btn btn-primary"
                    >
                      Search Options
                    </button>
                  </div>
                </div>
              )}
              
              {/* Step 3: Display Options */}
              {currentStep === 3 && (
                <div>
                  <h2 className="text-xl font-bold mb-6">
                    {bookingType === 'hotel' && 'Choose Your Accommodation'}
                    {bookingType === 'flight' && 'Select Your Flight'}
                    {bookingType === 'car' && 'Select Your Rental Vehicle'}
                    {bookingType === 'package' && 'Choose Your Package Components'}
                  </h2>
                  
                  {/* Hotel Options */}
                  {bookingType === 'hotel' && (
                    <div className="space-y-6">
                      {hotels.map((hotel) => (
                        <div 
                          key={hotel.id} 
                          className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow"
                        >
                          <div className="flex flex-col md:flex-row">
                            <div className="w-full md:w-1/3 h-48 md:h-auto relative">
                              <img 
                                src={hotel.image}
                                alt={hotel.name}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="p-4 md:p-6 flex-1">
                              <div className="flex justify-between items-start">
                                <div>
                                  <h3 className="font-bold text-lg">{hotel.name}</h3>
                                  <div className="flex items-center text-sm text-gray-600 mt-1">
                                    <MapPin size={14} className="mr-1" />
                                    <span>{hotel.location}</span>
                                  </div>
                                </div>
                                <div className="flex items-center bg-primary-50 text-primary-700 px-2 py-1 rounded">
                                  <Star size={14} className="mr-1 text-yellow-500" />
                                  <span className="font-medium">{hotel.rating}</span>
                                  <span className="text-xs text-gray-500 ml-1">({hotel.reviews})</span>
                                </div>
                              </div>
                              
                              <div className="mt-4">
                                <div className="flex flex-wrap gap-2 mb-4">
                                  {hotel.amenities.map((amenity, index) => (
                                    <span
                                      key={index}
                                      className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded"
                                    >
                                      {amenity}
                                    </span>
                                  ))}
                                </div>
                                
                                <div className="flex justify-between items-end mt-4">
                                  <div>
                                    <span className="text-2xl font-bold text-primary-600">${hotel.price}</span>
                                    <span className="text-gray-500 ml-1">per night</span>
                                  </div>
                                  <button
                                    onClick={nextStep}
                                    className="btn btn-primary"
                                  >
                                    Select
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {/* Flight Options */}
                  {bookingType === 'flight' && (
                    <div className="space-y-4">
                      {flights.map((flight) => (
                        <div 
                          key={flight.id} 
                          className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                        >
                          <div className="flex flex-col md:flex-row items-center">
                            <div className="flex items-center space-x-4 w-full md:w-1/4 mb-4 md:mb-0">
                              <div className="w-10 h-10 flex-shrink-0">
                                <img
                                  src={flight.logo}
                                  alt={flight.airline}
                                  className="w-full h-full object-contain"
                                />
                              </div>
                              <div>
                                <div className="font-medium">{flight.airline}</div>
                                <div className="text-sm text-gray-500">{flight.stops}</div>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-4 w-full md:w-2/4 mb-4 md:mb-0">
                              <div className="text-center">
                                <div className="text-lg font-bold">{flight.departureTime}</div>
                                <div className="text-sm text-gray-500">{flight.departureAirport}</div>
                              </div>
                              
                              <div className="flex-1 px-4">
                                <div className="relative">
                                  <div className="border-t-2 border-gray-300 border-dashed w-full absolute top-1/2 transform -translate-y-1/2"></div>
                                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white px-2">
                                    <Clock size={14} className="text-gray-400" />
                                  </div>
                                </div>
                                <div className="text-xs text-center text-gray-500 mt-2">{flight.duration}</div>
                              </div>
                              
                              <div className="text-center">
                                <div className="text-lg font-bold">{flight.arrivalTime}</div>
                                <div className="text-sm text-gray-500">{flight.arrivalAirport}</div>
                              </div>
                            </div>
                            
                            <div className="flex justify-between items-center w-full md:w-1/4">
                              <div className="text-2xl font-bold text-primary-600">${flight.price}</div>
                              <button
                                onClick={nextStep}
                                className="btn btn-primary"
                              >
                                Select
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {/* Car Rental Options */}
                  {bookingType === 'car' && (
                    <div className="space-y-6">
                      {cars.map((car) => (
                        <div 
                          key={car.id} 
                          className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow"
                        >
                          <div className="flex flex-col md:flex-row">
                            <div className="w-full md:w-1/3 h-48 md:h-auto relative">
                              <img 
                                src={car.image}
                                alt={car.name}
                                className="w-full h-full object-cover"
                              />
                              <div className="absolute top-0 left-0 bg-primary-600 text-white px-2 py-1 text-sm">
                                {car.type}
                              </div>
                            </div>
                            <div className="p-4 md:p-6 flex-1">
                              <div>
                                <h3 className="font-bold text-lg">{car.name}</h3>
                                <div className="text-sm text-gray-600 mt-1">
                                  Provided by <span className="font-medium">{car.company}</span>
                                </div>
                              </div>
                              
                              <div className="mt-4">
                                <div className="flex flex-wrap gap-x-4 gap-y-2 mb-4">
                                  {car.features.map((feature, index) => (
                                    <span
                                      key={index}
                                      className="flex items-center text-sm text-gray-600"
                                    >
                                      <Check size={14} className="mr-1 text-primary-500" />
                                      {feature}
                                    </span>
                                  ))}
                                </div>
                                
                                <div className="flex justify-between items-end mt-4">
                                  <div>
                                    <span className="text-2xl font-bold text-primary-600">${car.price}</span>
                                    <span className="text-gray-500 ml-1">per day</span>
                                  </div>
                                  <button
                                    onClick={nextStep}
                                    className="btn btn-primary"
                                  >
                                    Select
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {/* Package Options */}
                  {bookingType === 'package' && (
                    <div className="space-y-6">
                      <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                        <h3 className="font-bold text-lg mb-4">Your Custom Package</h3>
                        
                        <div className="space-y-4">
                          <div className="border-b border-gray-200 pb-3">
                            <h4 className="font-medium flex items-center">
                              <Plane size={18} className="mr-2 text-primary-500" />
                              Flight
                            </h4>
                            <div className="mt-2 pl-6">
                              <div className="flex items-center justify-between">
                                <div>
                                  <div className="font-medium">SkyRoute Airlines</div>
                                  <div className="text-sm text-gray-600">
                                    {formData.departureCity} → {formData.destination}
                                  </div>
                                  <div className="text-sm text-gray-500">
                                    {formData.departureDate} - {formData.returnDate}
                                  </div>
                                </div>
                                <div className="text-primary-600 font-bold">$349</div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="border-b border-gray-200 pb-3">
                            <h4 className="font-medium flex items-center">
                              <Hotel size={18} className="mr-2 text-primary-500" />
                              Accommodation
                            </h4>
                            <div className="mt-2 pl-6">
                              <div className="flex items-center justify-between">
                                <div>
                                  <div className="font-medium">Grand Luxury Resort & Spa</div>
                                  <div className="text-sm text-gray-600">
                                    {formData.checkIn || formData.departureDate} - {formData.checkOut || formData.returnDate}
                                  </div>
                                  <div className="text-sm text-gray-500">
                                    {formData.rooms || 1} room, {formData.travelers} guests
                                  </div>
                                </div>
                                <div className="text-primary-600 font-bold">$498</div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="border-b border-gray-200 pb-3">
                            <h4 className="font-medium flex items-center">
                              <Car size={18} className="mr-2 text-primary-500" />
                              Car Rental (Optional)
                            </h4>
                            <div className="mt-2 pl-6">
                              <div className="flex items-center justify-between">
                                <div>
                                  <div className="font-medium">Economy Car</div>
                                  <div className="text-sm text-gray-600">
                                    Toyota Corolla or similar
                                  </div>
                                  <div className="text-sm text-gray-500">
                                    {formData.pickupDate || formData.departureDate} - {formData.dropoffDate || formData.returnDate}
                                  </div>
                                </div>
                                <div className="text-primary-600 font-bold">$180</div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-6 pt-4 border-t border-gray-200">
                          <div className="flex justify-between items-center">
                            <div>
                              <div className="text-lg font-bold">Total Package Price</div>
                              <div className="text-sm text-gray-500">Includes all taxes and fees</div>
                            </div>
                            <div className="text-2xl font-bold text-primary-600">$1,027</div>
                          </div>
                          
                          <button
                            onClick={nextStep}
                            className="btn btn-primary w-full mt-4"
                          >
                            Select This Package
                          </button>
                        </div>
                      </div>
                      
                      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                        <div className="flex items-start">
                          <Shield className="text-green-500 mr-3 mt-1 flex-shrink-0" />
                          <div>
                            <h4 className="font-medium text-green-800">Travel Protection</h4>
                            <p className="text-sm text-green-700 mt-1">
                              Our packages include free cancellation up to 48 hours before departure and basic travel insurance.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex justify-between mt-8">
                    <button
                      onClick={prevStep}
                      className="btn border border-gray-300 hover:bg-gray-50"
                    >
                      Back
                    </button>
                  </div>
                </div>
              )}
              
              {/* Step 4: Confirmation and Payment */}
              {currentStep === 4 && (
                <div>
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Check className="h-8 w-8 text-green-500" />
                    </div>
                    <h2 className="text-xl font-bold">Complete Your Booking</h2>
                    <p className="text-gray-600 mt-1">
                      Just a few more details to confirm your reservation
                    </p>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-4 mb-6">
                    <h3 className="font-medium mb-2">Booking Summary</h3>
                    <div className="space-y-1 text-sm">
                      {bookingType === 'hotel' && (
                        <>
                          <div className="flex justify-between">
                            <span>Accommodation:</span>
                            <span className="font-medium">Grand Luxury Resort & Spa</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Dates:</span>
                            <span>{formData.checkIn} - {formData.checkOut}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Guests:</span>
                            <span>{formData.travelers} traveler(s)</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Rooms:</span>
                            <span>{formData.rooms}</span>
                          </div>
                        </>
                      )}
                      
                      {bookingType === 'flight' && (
                        <>
                          <div className="flex justify-between">
                            <span>Flight:</span>
                            <span className="font-medium">SkyRoute Airlines</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Route:</span>
                            <span>{formData.departureCity} → {formData.destination}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Date:</span>
                            <span>{formData.departureDate}</span>
                          </div>
                          {formData.flightType === 'roundtrip' && (
                            <div className="flex justify-between">
                              <span>Return:</span>
                              <span>{formData.returnDate}</span>
                            </div>
                          )}
                          <div className="flex justify-between">
                            <span>Passengers:</span>
                            <span>{formData.travelers}</span>
                          </div>
                        </>
                      )}
                      
                      {bookingType === 'car' && (
                        <>
                          <div className="flex justify-between">
                            <span>Vehicle:</span>
                            <span className="font-medium">Toyota Corolla or similar</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Pick-up:</span>
                            <span>{formData.carPickup}, {formData.pickupDate}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Drop-off:</span>
                            <span>{formData.carDropoff || formData.carPickup}, {formData.dropoffDate}</span>
                          </div>
                        </>
                      )}
                      
                      {bookingType === 'package' && (
                        <>
                          <div className="flex justify-between">
                            <span>Package:</span>
                            <span className="font-medium">Custom Travel Package</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Destination:</span>
                            <span>{formData.destination}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Dates:</span>
                            <span>{formData.departureDate} - {formData.returnDate}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Travelers:</span>
                            <span>{formData.travelers}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Includes:</span>
                            <span>Flight, Hotel, Car Rental</span>
                          </div>
                        </>
                      )}
                      
                      <div className="border-t border-gray-200 my-2 pt-2">
                        <div className="flex justify-between font-bold">
                          <span>Total Price:</span>
                          <span className="text-primary-600">
                            {bookingType === 'hotel' && '$498'}
                            {bookingType === 'flight' && '$349'}
                            {bookingType === 'car' && '$180'}
                            {bookingType === 'package' && '$1,027'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mb-6">
                    <h3 className="font-medium">Payment Details</h3>
                    <div>
                      <label htmlFor="card-name" className="label">Name on Card</label>
                      <input type="text" id="card-name" className="input" />
                    </div>
                    
                    <div>
                      <label htmlFor="card-number" className="label">Card Number</label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <CreditCard size={18} className="text-gray-400" />
                        </div>
                        <input
                          type="text"
                          id="card-number"
                          placeholder="**** **** **** ****"
                          className="input pl-10"
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="expiry" className="label">Expiry Date</label>
                        <input
                          type="text"
                          id="expiry"
                          placeholder="MM/YY"
                          className="input"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="cvv" className="label">CVV</label>
                        <input
                          type="text"
                          id="cvv"
                          placeholder="***"
                          className="input"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center mb-6">
                    <input
                      type="checkbox"
                      id="terms"
                      className="mr-2"
                    />
                    <label htmlFor="terms" className="text-sm text-gray-600">
                      I agree to the <a href="#" className="text-primary-600 hover:underline">Terms & Conditions</a> and <a href="#" className="text-primary-600 hover:underline">Privacy Policy</a>
                    </label>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row justify-between gap-4">
                    <button
                      onClick={prevStep}
                      className="btn border border-gray-300 hover:bg-gray-50"
                    >
                      Back
                    </button>
                    <button
                      className="btn bg-primary-600 text-white hover:bg-primary-700 flex items-center justify-center"
                    >
                      <span>Complete Booking</span>
                      <ArrowRight size={16} className="ml-2" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingAssistant;