import React, { useState } from 'react';
import { Heart, MessageSquare, Share2, ArrowRight, ChevronDown, Search, MapPin, User, Bookmark, Tag } from 'lucide-react';

const TravelStories: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [expandedStory, setExpandedStory] = useState<number | null>(null);
  
  // Mock categories
  const categories = [
    { id: 'all', name: 'All Stories' },
    { id: 'adventure', name: 'Adventure' },
    { id: 'culture', name: 'Culture & History' },
    { id: 'food', name: 'Food & Cuisine' },
    { id: 'nature', name: 'Nature & Wildlife' },
    { id: 'city', name: 'City Breaks' },
    { id: 'budget', name: 'Budget Travel' },
  ];
  
  // Mock featured story data
  const featuredStory = {
    id: 1,
    title: 'Three Weeks in Japan: Cherry Blossoms and Ancient Temples',
    excerpt: 'My journey through Japan during cherry blossom season, exploring Tokyo\'s modern wonders and Kyoto\'s serene temples. A perfect blend of tradition and innovation.',
    content: 'It was a dream come true when I finally boarded my flight to Tokyo in early April. After years of planning and saving, I was about to experience Japan during its most magical season: cherry blossom time.\n\nMy journey began in Tokyo, a city that somehow manages to be both chaotically energetic and perfectly organized. The first few days were a blur of neon lights, crowded crossings, and incredible food experiences. I stayed in a small ryokan in Asakusa, which gave me easy access to the historic Senso-ji Temple and the Tokyo Skytree.\n\nThe highlight of Tokyo was undoubtedly Ueno Park during peak sakura (cherry blossom) season. Hundreds of cherry trees created pink canopies over the pathways, while locals and tourists alike participated in hanami (flower viewing) picnics beneath the blossoms. The transient beauty of the sakura, lasting only about two weeks each year, embodies the Japanese concept of mono no aware – the wistful awareness of impermanence.\n\nFrom Tokyo, I took the Shinkansen (bullet train) to Kyoto, Japan\'s ancient capital. The contrast between Tokyo\'s modernity and Kyoto\'s traditionalism was striking. In Kyoto, I visited numerous temples and shrines, each more beautiful than the last. Kinkaku-ji (the Golden Pavilion) shimmered in the sunlight, reflecting perfectly in the surrounding pond. Fushimi Inari Shrine\'s thousands of vermilion torii gates created a mesmerizing tunnel-like path up the sacred mountain.\n\nThe Philosopher\'s Path, lined with cherry trees in full bloom, provided a contemplative walking route between temples. I spent an entire afternoon slowly strolling along this canal, stopping occasionally for matcha tea and wagashi (traditional Japanese sweets).\n\nMy journey continued to Hiroshima, where the Peace Memorial Park and Museum offered a somber but essential historical perspective. Despite its tragic history, modern Hiroshima is vibrant and forward-looking. I also took a day trip to nearby Miyajima Island to see the famous "floating" torii gate and feed the friendly deer that roam freely.\n\nThe final stop was Osaka, known for its incredible food scene. I indulged in takoyaki (octopus balls), okonomiyaki (savory pancakes), and the freshest sushi I\'ve ever tasted. The vibrant Dotonbori district with its giant mechanical crab and glowing billboards provided the perfect energetic finale to my Japanese adventure.',
    author: {
      name: 'Emily Johnson',
      avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg',
      location: 'San Francisco, CA'
    },
    date: 'May 15, 2023',
    readTime: '8 min read',
    location: 'Japan',
    likes: 342,
    comments: 56,
    saves: 89,
    category: 'culture',
    tags: ['Japan', 'Cherry Blossoms', 'Temples', 'Culture', 'Tokyo', 'Kyoto'],
    coverImage: 'https://images.pexels.com/photos/402028/pexels-photo-402028.jpeg',
    images: [
      'https://images.pexels.com/photos/1440476/pexels-photo-1440476.jpeg',
      'https://images.pexels.com/photos/590478/pexels-photo-590478.jpeg',
      'https://images.pexels.com/photos/5137664/pexels-photo-5137664.jpeg'
    ]
  };
  
  // Mock travel stories data
  const travelStories = [
    {
      id: 2,
      title: 'Road Tripping Through the American Southwest',
      excerpt: 'A two-week journey through red rock formations, vast canyons, and starlit desert skies in Utah, Arizona, and New Mexico.',
      content: 'Our road trip through the American Southwest was a journey of awe-inspiring landscapes and unexpected discoveries...',
      author: {
        name: 'Michael Chen',
        avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg',
        location: 'Boston, MA'
      },
      date: 'June 3, 2023',
      readTime: '6 min read',
      location: 'Utah, Arizona, New Mexico',
      likes: 275,
      comments: 42,
      saves: 63,
      category: 'adventure',
      tags: ['Road Trip', 'National Parks', 'Hiking', 'Desert', 'Canyon'],
      coverImage: 'https://images.pexels.com/photos/33041/antelope-canyon-lower-canyon-arizona.jpg'
    },
    {
      id: 3,
      title: 'A Culinary Tour of Thailand\'s Street Food',
      excerpt: 'Exploring the vibrant flavors of Thai cuisine from Bangkok\'s bustling markets to Chiang Mai\'s tranquil food stalls.',
      content: 'The first bite of authentic Pad Thai on a humid Bangkok evening was the moment I fell in love with Thai cuisine...',
      author: {
        name: 'Sarah Wong',
        avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
        location: 'Chicago, IL'
      },
      date: 'April 22, 2023',
      readTime: '5 min read',
      location: 'Thailand',
      likes: 318,
      comments: 47,
      saves: 92,
      category: 'food',
      tags: ['Thailand', 'Street Food', 'Cuisine', 'Bangkok', 'Chiang Mai'],
      coverImage: 'https://images.pexels.com/photos/2347383/pexels-photo-2347383.jpeg'
    },
    {
      id: 4,
      title: 'Safari Adventures in Tanzania',
      excerpt: 'Witnessing the great migration in Serengeti National Park and encountering the Big Five in their natural habitat.',
      content: 'The sound of a lion\'s roar echoing across the savanna at dawn is something that stays with you forever...',
      author: {
        name: 'David Okafor',
        avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg',
        location: 'London, UK'
      },
      date: 'March 15, 2023',
      readTime: '7 min read',
      location: 'Tanzania',
      likes: 402,
      comments: 61,
      saves: 123,
      category: 'nature',
      tags: ['Safari', 'Wildlife', 'Africa', 'Serengeti', 'Photography'],
      coverImage: 'https://images.pexels.com/photos/7750825/pexels-photo-7750825.jpeg'
    },
    {
      id: 5,
      title: 'Backpacking South America on $30 a Day',
      excerpt: 'How I traveled through six countries in South America for four months on a tight budget.',
      content: 'When I decided to backpack through South America, I set myself a challenging budget: just $30 per day...',
      author: {
        name: 'Maria Gonzalez',
        avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
        location: 'Madrid, Spain'
      },
      date: 'February 28, 2023',
      readTime: '9 min read',
      location: 'South America',
      likes: 289,
      comments: 38,
      saves: 77,
      category: 'budget',
      tags: ['Budget Travel', 'Backpacking', 'South America', 'Hostels', 'Solo Travel'],
      coverImage: 'https://images.pexels.com/photos/2166553/pexels-photo-2166553.jpeg'
    },
    {
      id: 6,
      title: 'Winter Weekend in Paris',
      excerpt: 'Discovering the City of Light during its most magical season, when tourists are few and locals reclaim their city.',
      content: 'Paris in winter holds a special kind of magic – the summer crowds have dispersed, and the city reveals its authentic self...',
      author: {
        name: 'James Mitchell',
        avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg',
        location: 'New York, NY'
      },
      date: 'January 12, 2023',
      readTime: '4 min read',
      location: 'Paris, France',
      likes: 213,
      comments: 29,
      saves: 48,
      category: 'city',
      tags: ['Paris', 'Weekend Trip', 'Winter Travel', 'City Break', 'Europe'],
      coverImage: 'https://images.pexels.com/photos/705764/pexels-photo-705764.jpeg'
    },
  ];
  
  // Filter stories by category
  const filteredStories = activeCategory === 'all' 
    ? travelStories 
    : travelStories.filter(story => story.category === activeCategory);
  
  // Toggle expanded story
  const toggleExpandedStory = (id: number) => {
    setExpandedStory(expandedStory === id ? null : id);
  };
  
  return (
    <div className="bg-gray-100 min-h-screen py-12">
      <div className="container-custom">
        <h1 className="text-3xl font-bold mb-4">Travel Stories</h1>
        <p className="text-gray-600 mb-8">Share and discover authentic travel experiences from our community</p>
        
        {/* Search and Category Filter */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search travel stories"
              className="pl-10 pr-4 py-2 w-full lg:w-64 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                  activeCategory === category.id
                    ? 'bg-primary-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
          
          <button className="btn btn-primary flex items-center">
            <svg className="mr-2 h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
            Create Story
          </button>
        </div>
        
        {/* Featured Story */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden mb-10">
          <div className="grid grid-cols-1 lg:grid-cols-5">
            <div className="lg:col-span-3 h-64 lg:h-auto relative">
              <img 
                src={featuredStory.coverImage} 
                alt={featuredStory.title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4 bg-primary-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                Featured Story
              </div>
            </div>
            
            <div className="lg:col-span-2 p-6">
              <div className="flex items-center text-sm mb-3">
                <span className="inline-block w-2 h-2 rounded-full bg-primary-500 mr-2"></span>
                <span className="text-primary-600 font-medium">{categories.find(c => c.id === featuredStory.category)?.name}</span>
                <span className="mx-2">•</span>
                <MapPin size={14} className="mr-1 text-gray-400" />
                <span className="text-gray-600">{featuredStory.location}</span>
              </div>
              
              <h2 className="text-2xl font-bold mb-3">{featuredStory.title}</h2>
              <p className="text-gray-600 mb-4">{featuredStory.excerpt}</p>
              
              <div className="flex items-center mb-4">
                <img 
                  src={featuredStory.author.avatar} 
                  alt={featuredStory.author.name} 
                  className="w-10 h-10 rounded-full mr-3"
                />
                <div>
                  <div className="font-medium">{featuredStory.author.name}</div>
                  <div className="text-sm text-gray-500 flex items-center">
                    <span>{featuredStory.date}</span>
                    <span className="mx-1">•</span>
                    <span>{featuredStory.readTime}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-4">
                {featuredStory.tags.slice(0, 3).map((tag, idx) => (
                  <span key={idx} className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs">
                    #{tag}
                  </span>
                ))}
                {featuredStory.tags.length > 3 && (
                  <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs">
                    +{featuredStory.tags.length - 3} more
                  </span>
                )}
              </div>
              
              <div className="flex justify-between items-center mt-auto">
                <div className="flex items-center space-x-4 text-gray-500">
                  <button className="flex items-center hover:text-red-500 transition-colors">
                    <Heart size={18} className="mr-1" />
                    <span>{featuredStory.likes}</span>
                  </button>
                  <button className="flex items-center hover:text-primary-500 transition-colors">
                    <MessageSquare size={18} className="mr-1" />
                    <span>{featuredStory.comments}</span>
                  </button>
                  <button className="flex items-center hover:text-primary-500 transition-colors">
                    <Bookmark size={18} />
                  </button>
                </div>
                
                <button className="text-primary-600 hover:text-primary-700 font-medium flex items-center">
                  Read Full Story
                  <ArrowRight size={16} className="ml-1" />
                </button>
              </div>
            </div>
          </div>
          
          {/* Expanded Story Content */}
          {expandedStory === featuredStory.id && (
            <div className="p-6 border-t border-gray-200">
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                <div className="lg:col-span-3">
                  <div className="prose max-w-none">
                    {featuredStory.content.split('\n\n').map((paragraph, idx) => (
                      <p key={idx}>{paragraph}</p>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-2">Photos from this trip</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {featuredStory.images.map((image, idx) => (
                        <div key={idx} className="rounded-lg overflow-hidden">
                          <img 
                            src={image} 
                            alt={`Travel photo ${idx + 1}`} 
                            className="w-full h-32 object-cover"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-2">About the Author</h3>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center mb-3">
                        <img 
                          src={featuredStory.author.avatar} 
                          alt={featuredStory.author.name} 
                          className="w-12 h-12 rounded-full mr-3"
                        />
                        <div>
                          <div className="font-medium">{featuredStory.author.name}</div>
                          <div className="text-sm text-gray-500">
                            {featuredStory.author.location}
                          </div>
                        </div>
                      </div>
                      <p className="text-sm text-gray-600">
                        Emily is a travel writer and photographer who has visited over 30 countries. She specializes in cultural experiences and off-the-beaten-path adventures.
                      </p>
                      <button className="mt-2 text-primary-600 hover:text-primary-700 text-sm font-medium">
                        View Profile
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Toggle Button */}
          <button 
            onClick={() => toggleExpandedStory(featuredStory.id)}
            className="w-full py-3 border-t border-gray-200 text-gray-700 hover:bg-gray-50 font-medium flex items-center justify-center"
          >
            {expandedStory === featuredStory.id ? (
              <>Show Less <ChevronDown className="ml-1 transform rotate-180" size={16} /></>
            ) : (
              <>Read More <ChevronDown className="ml-1" size={16} /></>
            )}
          </button>
        </div>
        
        {/* More Stories */}
        <h2 className="text-2xl font-bold mb-4">Explore More Stories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {filteredStories.map((story) => (
            <div 
              key={story.id} 
              className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="relative h-48">
                <img 
                  src={story.coverImage} 
                  alt={story.title} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-0 left-0 m-3">
                  <div className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full text-xs font-medium text-gray-700 flex items-center">
                    <span>{categories.find(c => c.id === story.category)?.name}</span>
                  </div>
                </div>
                <div className="absolute bottom-0 left-0 m-3">
                  <div className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full text-xs font-medium text-gray-700 flex items-center">
                    <MapPin size={12} className="mr-1" />
                    <span>{story.location}</span>
                  </div>
                </div>
              </div>
              
              <div className="p-4">
                <h3 className="font-bold text-lg mb-2 line-clamp-2">{story.title}</h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">{story.excerpt}</p>
                
                <div className="flex justify-between items-end">
                  <div className="flex items-center">
                    <img 
                      src={story.author.avatar} 
                      alt={story.author.name} 
                      className="w-8 h-8 rounded-full mr-2"
                    />
                    <div>
                      <div className="text-sm font-medium">{story.author.name}</div>
                      <div className="text-xs text-gray-500">{story.date}</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 text-gray-500">
                    <button className="hover:text-red-500 transition-colors">
                      <Heart size={16} />
                    </button>
                    <button className="hover:text-primary-500 transition-colors">
                      <Bookmark size={16} />
                    </button>
                    <button className="hover:text-primary-500 transition-colors">
                      <Share2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-200">
                <button 
                  className="w-full py-2 text-primary-600 hover:text-primary-700 font-medium flex items-center justify-center"
                  onClick={() => toggleExpandedStory(story.id)}
                >
                  {expandedStory === story.id ? 'Show Less' : 'Read More'}
                </button>
              </div>
              
              {/* Expanded Story Content */}
              {expandedStory === story.id && (
                <div className="p-4 border-t border-gray-200">
                  <div className="prose prose-sm max-w-none">
                    <p>{story.content}</p>
                    <p className="text-primary-600 font-medium">
                      This story preview continues...
                    </p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
        
        {/* Create Your Own Story CTA */}
        <div className="bg-gradient-to-r from-primary-600 to-primary-800 rounded-xl overflow-hidden text-white">
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="p-6 md:p-8 flex items-center">
              <div>
                <h2 className="text-2xl font-bold mb-2">Share Your Travel Adventure</h2>
                <p className="mb-6 text-primary-100">
                  Everyone has a unique travel story. Document your journey, share your photos, and connect with fellow travelers.
                </p>
                <button className="bg-white text-primary-700 py-2 px-6 rounded-lg hover:bg-primary-50 font-medium transition-colors flex items-center">
                  <User size={18} className="mr-2" />
                  Create Your Story
                </button>
              </div>
            </div>
            <div className="relative h-64 md:h-auto">
              <img 
                src="https://images.pexels.com/photos/2325446/pexels-photo-2325446.jpeg" 
                alt="Travel photography" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-l from-black/20 to-transparent"></div>
            </div>
          </div>
        </div>
        
        {/* Popular Tags */}
        <div className="mt-10">
          <h2 className="text-2xl font-bold mb-4">Popular Tags</h2>
          <div className="flex flex-wrap gap-3">
            <a href="#" className="group flex items-center px-3 py-2 bg-white rounded-full shadow-sm hover:shadow transition-all">
              <Tag size={16} className="mr-2 text-primary-500 group-hover:text-primary-600" />
              <span className="font-medium text-gray-700 group-hover:text-gray-900">#Adventure</span>
              <span className="ml-2 text-xs text-gray-500">3,245 stories</span>
            </a>
            <a href="#" className="group flex items-center px-3 py-2 bg-white rounded-full shadow-sm hover:shadow transition-all">
              <Tag size={16} className="mr-2 text-primary-500 group-hover:text-primary-600" />
              <span className="font-medium text-gray-700 group-hover:text-gray-900">#SoloTravel</span>
              <span className="ml-2 text-xs text-gray-500">2,817 stories</span>
            </a>
            <a href="#" className="group flex items-center px-3 py-2 bg-white rounded-full shadow-sm hover:shadow transition-all">
              <Tag size={16} className="mr-2 text-primary-500 group-hover:text-primary-600" />
              <span className="font-medium text-gray-700 group-hover:text-gray-900">#Foodie</span>
              <span className="ml-2 text-xs text-gray-500">2,512 stories</span>
            </a>
            <a href="#" className="group flex items-center px-3 py-2 bg-white rounded-full shadow-sm hover:shadow transition-all">
              <Tag size={16} className="mr-2 text-primary-500 group-hover:text-primary-600" />
              <span className="font-medium text-gray-700 group-hover:text-gray-900">#Photography</span>
              <span className="ml-2 text-xs text-gray-500">2,103 stories</span>
            </a>
            <a href="#" className="group flex items-center px-3 py-2 bg-white rounded-full shadow-sm hover:shadow transition-all">
              <Tag size={16} className="mr-2 text-primary-500 group-hover:text-primary-600" />
              <span className="font-medium text-gray-700 group-hover:text-gray-900">#Europe</span>
              <span className="ml-2 text-xs text-gray-500">1,895 stories</span>
            </a>
            <a href="#" className="group flex items-center px-3 py-2 bg-white rounded-full shadow-sm hover:shadow transition-all">
              <Tag size={16} className="mr-2 text-primary-500 group-hover:text-primary-600" />
              <span className="font-medium text-gray-700 group-hover:text-gray-900">#BudgetTravel</span>
              <span className="ml-2 text-xs text-gray-500">1,742 stories</span>
            </a>
            <a href="#" className="group flex items-center px-3 py-2 bg-white rounded-full shadow-sm hover:shadow transition-all">
              <Tag size={16} className="mr-2 text-primary-500 group-hover:text-primary-600" />
              <span className="font-medium text-gray-700 group-hover:text-gray-900">#Backpacking</span>
              <span className="ml-2 text-xs text-gray-500">1,568 stories</span>
            </a>
            <a href="#" className="group flex items-center px-3 py-2 bg-white rounded-full shadow-sm hover:shadow transition-all">
              <Tag size={16} className="mr-2 text-primary-500 group-hover:text-primary-600" />
              <span className="font-medium text-gray-700 group-hover:text-gray-900">#Asia</span>
              <span className="ml-2 text-xs text-gray-500">1,489 stories</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TravelStories;