import React, { lazy, Suspense } from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import LoadingSpinner from './components/ui/LoadingSpinner';

// Lazy loaded pages to improve initial load performance
const ItineraryBuilder = lazy(() => import('./pages/ItineraryBuilder'));
const TrendingSpots = lazy(() => import('./pages/TrendingSpots'));
const HiddenGems = lazy(() => import('./pages/HiddenGems'));
const BookingAssistant = lazy(() => import('./pages/BookingAssistant'));
const EcoTravelGuide = lazy(() => import('./pages/EcoTravelGuide'));
const VirtualTours = lazy(() => import('./pages/VirtualTours'));
const Community = lazy(() => import('./pages/Community'));
const RoadTripPlanner = lazy(() => import('./pages/RoadTripPlanner'));
const RewardSystem = lazy(() => import('./pages/RewardSystem'));
const Emergency = lazy(() => import('./pages/Emergency'));
const TravelStories = lazy(() => import('./pages/TravelStories'));

function App() {
  return (
    <Layout>
      <Suspense fallback={<LoadingSpinner />}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/itinerary-builder" element={<ItineraryBuilder />} />
          <Route path="/trending" element={<TrendingSpots />} />
          <Route path="/hidden-gems" element={<HiddenGems />} />
          <Route path="/booking" element={<BookingAssistant />} />
          <Route path="/eco-travel" element={<EcoTravelGuide />} />
          <Route path="/virtual-tours" element={<VirtualTours />} />
          <Route path="/community" element={<Community />} />
          <Route path="/road-trip" element={<RoadTripPlanner />} />
          <Route path="/rewards" element={<RewardSystem />} />
          <Route path="/emergency" element={<Emergency />} />
          <Route path="/travel-stories" element={<TravelStories />} />
        </Routes>
      </Suspense>
    </Layout>
  );
}

export default App;